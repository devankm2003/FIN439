# FIN 43900 — Lab 19: Legend Panel (Buffett, Graham, Burry)

**Student:** Devank Mahajan  
**Date:** November 5, 2026  
**Category:** Thursday Merit Checkout (25 / 25 Merit Points)  

---

## 📁 Package Manifest

| File | Description |
| :--- | :--- |
| [`checkout.md`](./checkout.md) | **Primary Submission Report:** Detailed walkthrough of all 5 merit anchors, the core question, 10-K provenance, COST & MSFT verification, Graham probe, code explanation, bull/bear cases, and decision. |
| [`panel_metrics.py`](./panel_metrics.py) | **Core Python Engine:** Fetches 10-K facts keyless from SEC EDGAR, computes 5-year flows and balances, evaluates quantitative checks for Buffett, Graham, and Burry, and prints the audit-ready panel. |
| [`app.py`](./app.py) | **Streamlit Application:** Multi-investor interactive dashboard featuring panel verdicts, 5-year financials and ratios, multi-investor charts, side-by-side editable memos, dynamic Graham threshold toggle (2.0 vs 1.0), and a real-time number hallucination auditor across all memos. |
| [`test_panel.py`](./test_panel.py) | **Automated Merit Verification Suite:** Verifies all 5 rubric anchors (Known answer on COST, 0 unprinted numbers in memos, honest gaps on JPM, fund company run on MSFT, and threshold probe decision). |
| [`COST_buffett_memo.md`](./COST_buffett_memo.md) | Warren Buffett evaluation memo for Costco (`COST`), verdict: `Own the business`. |
| [`COST_graham_memo.md`](./COST_graham_memo.md) | Benjamin Graham evaluation memo for Costco (`COST`), verdict: `Reject / Pass` (Classical) with one-line probe threshold rationale. |
| [`COST_burry_memo.md`](./COST_burry_memo.md) | Michael Burry evaluation memo for Costco (`COST`), verdict: `High Conviction Long`. |
| [`MSFT_buffett_memo.md`](./MSFT_buffett_memo.md) | Warren Buffett evaluation memo for Microsoft (`MSFT`), verdict: `Own the business`. |
| [`MSFT_graham_memo.md`](./MSFT_graham_memo.md) | Benjamin Graham evaluation memo for Microsoft (`MSFT`), verdict: `Reject / Pass` (Classical). |
| [`MSFT_burry_memo.md`](./MSFT_burry_memo.md) | Michael Burry evaluation memo for Microsoft (`MSFT`), verdict: `High Conviction Long`. |
| [`skills/`](./skills/) | Folder containing the 3 AI skills: `buffett-investor`, `graham-investor`, and `burry-investor`. |
| [`.cache/`](./.cache/) | Offline cached 10-K JSON facts from SEC EDGAR for `COST`, `MSFT`, `AAPL`, `JPM`, and `company_tickers.json`. |

---

## 🚀 How to Run

```bash
# 1. Run the Python Extraction & Checks Engine:
python3 panel_metrics.py COST
python3 panel_metrics.py MSFT

# 2. Run the 25/25 Merit Verification Suite:
python3 test_panel.py

# 3. Launch the Streamlit Interactive Panel:
streamlit run app.py
```

