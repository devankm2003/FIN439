# Benjamin Graham Memo: Costco Wholesale Corp (COST)

**Verdict:** Reject / Pass (Classical) · Defensive watch (Adjusted)

### 1. Balance Sheet Safety & Margin of Safety
Under classical security analysis, an enterprise must maintain substantial current liquidity to withstand severe credit contractions and inventory liquidations. Our primary test requires current assets to exceed current liabilities by a factor of 2 or more.

### 2. Quantitative Evaluation from Audited 10-K Filings
Evaluating the 5 fiscal years from 2022 to 2026:
- **Current Ratio (Hurdle >= 2.0):** In the latest year (2026), current assets were 46,582 against current liabilities of 43,952, yielding a current ratio of 1.06. Across the prior four years, current ratios were 1.02 in 2022, 1.07 in 2023, 0.97 in 2024, and 1.03 in 2025. Costco fails the classical 2.0 defensive hurdle in 2026 (1.06).
- **Earnings Stability (Positive Net Income):** Net income was positive in each of the 5 years: 5,844 in 2022, 6,292 in 2023, 7,367 in 2024, 8,099 in 2025, and 9,226 in 2026.
- **Earnings Growth:** Net income increased from 5,844 in the first year to 9,226 in the last year, satisfying our earnings expansion requirement.

### 3. Conclusion & Threshold Probe
Costco fails Graham's classical 2.0 defensive liquidity hurdle, producing a panel result of 2 of 3 checks passed.

Threshold kept: 1.0; Costco's negative working capital cycle and rapid inventory turnover (selling goods and collecting cash before paying suppliers) mean a 2.0 current ratio is an inappropriate industrial hurdle that penalizes superior retail operational efficiency.
