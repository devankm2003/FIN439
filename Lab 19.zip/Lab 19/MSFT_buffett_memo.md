# Warren Buffett Memo: Microsoft Corp (MSFT)

**Verdict:** Own the business

### 1. Circle of Competence & Enterprise Moat
Microsoft possesses enterprise moats across cloud computing, productivity software, and enterprise infrastructure. The high switching costs of its enterprise software ecosystem generate high-margin recurring revenues and pricing power.

### 2. Quantitative Evaluation from Audited 10-K Filings
Across the 5 fiscal years from 2022 to 2026:
- **Return on Equity (ROE >= 15%):** Net income divided by year-end stockholders' equity was 43.7% in 2022, 35.1% in 2023, 32.8% in 2024, 29.6% in 2025, and 30.2% in 2026. Microsoft exceeded our 15% ROE hurdle in all 5 years.
- **Owner Earnings Positive:** Owner earnings (operating cash flow minus capital expenditures) was 65,149 in 2022, 59,475 in 2023, 74,071 in 2024, 71,611 in 2025, and 66,987 in 2026. Cash generation was positive in every single year.
- **Owner Earnings Growth:** Owner earnings expanded from 65,149 in 2022 to 66,987 in 2026, passing our growth requirement despite heavy capital expenditures in 2026 of 115,948.

### 3. Conclusion
Microsoft satisfies all 3 of Buffett's checks (3 of 3), demonstrating high capital efficiency and resilient cash compounding.

