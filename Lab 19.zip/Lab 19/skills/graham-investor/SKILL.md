---
name: graham-investor
description: Benjamin Graham legend investor skill. Downloads SEC EDGAR 10-K facts keyless, extracts 5 fiscal years of balance sheet and income data, evaluates Graham's 3 defensive checks in code (Current ratio >= 2.0, Net income positive every year, Net income growth), and writes a margin-of-safety investment memo using only code-computed numbers.
---

# Benjamin Graham Legend Investor Skill

This skill operationalizes Benjamin Graham's classical defensive value-investing philosophy from *Security Analysis* and *The Intelligent Investor*.
It enforces strict separation between computation and judgment:
- **Code computes every number** directly from official SEC EDGAR 10-K filings.
- **The model only judges** balance sheet safety, margin of safety, and operational resilience using strictly the printed numbers.

## Data Rules & Integrity Guardrails

1. **Filings**: 10-K only; exactly the last 5 fiscal years, labeled by fiscal-year-end date.
2. **Balance Sheet & Flow Tags**:
   - Assets Current: `AssetsCurrent`
   - Liabilities Current: `LiabilitiesCurrent`
   - Net Income: `NetIncomeLoss`
   - Stockholders' Equity: `StockholdersEquity`
3. **Formulas**:
   - Current Ratio = Current Assets ÷ Current Liabilities.
   - Any check with a missing input evaluates to `"not known"`.
   - Never fabricate or substitute outside estimates.

## Graham's Three Core Checks in Code

1. **Current ratio of 2 or more, latest year** (`pass` / `fail (<ratio>)` / `not known`)
   - Standard defensive hurdle: Current assets must be at least twice current liabilities to guarantee working capital solvency during economic contractions.
   - *Design Choice / Threshold Probe*: In retail and fast-inventory businesses with negative working capital cycles (like Costco), a current ratio threshold of 1.0 may be tested.
2. **Net income positive every year** (`pass` / `fail` / `not known`)
   - Requires positive net earnings in each of the 5 trailing fiscal years (earnings stability).
3. **Net income grew, first year to last** (`pass` / `fail` / `not known`)
   - Net income in Year 5 must exceed Net income in Year 1.

## Investment Memo Structure

Write an internal memo saved as `<TICKER>_graham_memo.md`:
- **Verdict**: Exactly one of `Enter position (Margin of Safety)`, `Defensive watch`, or `Reject / Pass`.
- **Strict Grounding Rule**: Use **ONLY numbers printed by the script**.
- **Threshold Documentation**: Explicitly record the current-ratio threshold kept and the economic rationale.
