---
name: burry-investor
description: Michael Burry legend investor skill. Downloads SEC EDGAR 10-K facts keyless, extracts 5 fiscal years of cash flows and balance sheet solvency data, evaluates Burry's 2 core forensic checks in code (OCF >= Net Income every year, Liabilities <= 2x Equity in latest year), and writes a contrarian deep-value evaluation memo using only code-computed numbers.
---

# Michael Burry Legend Investor Skill

This skill operationalizes Michael Burry's forensic, contrarian fundamental analysis framework.
It enforces strict separation between computation and judgment:
- **Code computes every number** directly from official SEC EDGAR 10-K filings.
- **The model only judges** cash conversion quality, structural leverage risk, and accounting integrity using strictly the printed numbers.

## Data Rules & Integrity Guardrails

1. **Filings**: 10-K only; exactly the last 5 fiscal years, labeled by fiscal-year-end date.
2. **Cash Flow & Balance Sheet Tags**:
   - Operating Cash Flow: `NetCashProvidedByUsedInOperatingActivities`
   - Net Income: `NetIncomeLoss`
   - Liabilities: `Liabilities`
   - Stockholders' Equity: `StockholdersEquity`
3. **Formulas**:
   - Cash Flow Quality: Operating Cash Flow $\ge$ Net Income each year.
   - Solvency / Leverage Hurdle: Liabilities $\div$ Stockholders' Equity $\le 2.0$ in the latest year.
   - Any check with a missing input evaluates to `"not known"`.

## Burry's Two Core Checks in Code

1. **Operating cash flow at least net income every year** (`pass` / `fail` / `not known`)
   - Forensic earnings quality filter: Cash generated from operations must match or exceed net income every single year. Any shortfall indicates accrual puffery, uncollected receivables, or aggressive revenue recognition.
2. **Liabilities no more than twice equity, latest year** (`pass (<ratio>)` / `fail (<ratio>)` / `not known`)
   - Capital structure defense: Total balance sheet obligations must not exceed twice net book value ($\text{Liabilities} \le 2 \times \text{Equity}$). Excessive leverage creates terminal downside risk during liquidity crunches.

## Investment Memo Structure

Write an internal memo saved as `<TICKER>_burry_memo.md`:
- **Verdict**: Exactly one of `High Conviction Long`, `Monitor / Scavenge`, or `Avoid / Short candidate`.
- **Strict Grounding Rule**: Use **ONLY numbers printed by the script**.
- **Accrual & Solvency Assessment**: Discuss the cash conversion buffer ($\text{OCF} - \text{NI}$) and the balance sheet leverage ratio.
