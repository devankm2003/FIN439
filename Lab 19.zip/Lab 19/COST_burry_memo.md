# Michael Burry Memo: Costco Wholesale Corp (COST)

**Verdict:** High Conviction Long

### 1. Forensic Cash Flow & Leverage Lens
Rather than trusting management accounting narratives or adjusted EBITDA, we examine raw cash conversion from the cash flow statement against reported net income, paired with structural leverage on the balance sheet.

### 2. Quantitative Evaluation from Audited 10-K Filings
Across the 5 fiscal years from 2022 to 2026:
- **Cash Flow vs. Net Income Quality (OCF >= Net Income):** Operating cash flow exceeded net income in every single year:
  - 2022: Operating cash flow of 7,392 exceeded net income of 5,844.
  - 2023: Operating cash flow of 11,068 exceeded net income of 6,292.
  - 2024: Operating cash flow of 11,339 exceeded net income of 7,367.
  - 2025: Operating cash flow of 13,335 exceeded net income of 8,099.
  - 2026: Operating cash flow of 15,817 exceeded net income of 9,226.
  This consistent cash conversion surplus demonstrates high-quality earnings with zero accrual inflation, receivables buildup, or aggressive revenue timing.
- **Balance Sheet Leverage (Liabilities <= 2x Equity):** In the latest year (2026), total liabilities were 53,242 against stockholders' equity of 35,803, resulting in liabilities to equity of 1.49. In previous years, this ratio was 2.11 in 2022, 1.75 in 2023, 1.96 in 2024, and 1.64 in 2025. In the latest year, Costco comfortably satisfies the hurdle with liabilities no more than twice equity (1.49).

### 3. Conclusion
Costco passes both of Burry's forensic checks (2 of 2). Strong cash conversion and de-leveraging balance sheet dynamics confirm underlying business resilience.

