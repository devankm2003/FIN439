#!/usr/bin/env python3
"""
panel_metrics.py — Lab 19: Legend Panel (Buffett, Graham, Burry)
Downloads 10-K facts from SEC EDGAR keyless, extracts the last 5 fiscal years,
computes ROE, Owner Earnings, Current Ratio, and Liabilities / Equity,
and evaluates quantitative checks in code for Warren Buffett, Benjamin Graham, and Michael Burry.
"""

import sys
import os
import json
import re
from datetime import datetime
import requests

USER_AGENT = "Devan Mahajan devankmahajan@university.edu"
CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".cache")


def ensure_cache_dir():
    os.makedirs(CACHE_DIR, exist_ok=True)


def get_cik_for_ticker(ticker: str) -> str:
    """Resolve a ticker symbol to a 10-digit zero-padded CIK string."""
    ensure_cache_dir()
    ticker_cache = os.path.join(CACHE_DIR, "company_tickers.json")

    data = None
    if os.path.exists(ticker_cache):
        try:
            with open(ticker_cache, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = None

    if not data:
        url = "https://www.sec.gov/files/company_tickers.json"
        headers = {"User-Agent": USER_AGENT}
        resp = requests.get(url, headers=headers, timeout=15)
        resp.raise_for_status()
        data = resp.json()
        with open(ticker_cache, "w", encoding="utf-8") as f:
            json.dump(data, f)

    clean_ticker = ticker.strip().upper()
    for item in data.values():
        if item.get("ticker", "").upper() == clean_ticker:
            cik_int = item.get("cik_str")
            return str(cik_int).zfill(10)

    raise ValueError(f"Ticker '{ticker}' not found in SEC EDGAR directory.")


def get_company_facts(cik: str) -> dict:
    """Fetch company facts JSON from SEC EDGAR for given CIK (cached locally)."""
    ensure_cache_dir()
    facts_cache = os.path.join(CACHE_DIR, f"facts_{cik}.json")

    if os.path.exists(facts_cache):
        try:
            with open(facts_cache, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass

    url = f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json"
    headers = {"User-Agent": USER_AGENT}
    resp = requests.get(url, headers=headers, timeout=20)
    resp.raise_for_status()
    facts = resp.json()
    with open(facts_cache, "w", encoding="utf-8") as f:
        json.dump(facts, f)
    return facts


def get_flow_value(us_gaap: dict, tag_names: list, end_date: str):
    """
    Find a 1-year flow value (duration between 340 and 385 days) filed on Form 10-K
    for a specific fiscal year end date. Latest filing date wins.
    Returns (raw_value, tag_used) or (None, None).
    """
    for tag in tag_names:
        if tag not in us_gaap:
            continue
        units = us_gaap[tag].get("units", {}).get("USD", [])
        candidates = []
        for e in units:
            if e.get("form") == "10-K" and e.get("end") == end_date:
                if "start" in e:
                    try:
                        d1 = datetime.strptime(e["start"], "%Y-%m-%d")
                        d2 = datetime.strptime(e["end"], "%Y-%m-%d")
                        days = (d2 - d1).days
                        if 340 <= days <= 385:
                            candidates.append(e)
                    except ValueError:
                        continue
        if candidates:
            candidates.sort(key=lambda x: x.get("filed", ""), reverse=True)
            return candidates[0].get("val"), tag

    return None, None


def get_instant_value(us_gaap: dict, tag_names: list, end_date: str):
    """
    Find a point-in-time balance sheet value filed on Form 10-K for a specific fiscal year end date.
    Latest filing date wins.
    Returns (raw_value, tag_used) or (None, None).
    """
    for tag in tag_names:
        if tag not in us_gaap:
            continue
        units = us_gaap[tag].get("units", {}).get("USD", [])
        candidates = []
        for e in units:
            if e.get("form") == "10-K" and e.get("end") == end_date:
                candidates.append(e)
        if candidates:
            candidates.sort(key=lambda x: x.get("filed", ""), reverse=True)
            return candidates[0].get("val"), tag

    return None, None


def extract_panel_data(ticker: str, graham_cr_threshold: float = 2.0) -> dict:
    """
    Extract the last five fiscal years for a ticker according to panel rules:
    - Filings: 10-K only; last 5 fiscal years labelled by fiscal-year-end date
    - Flows: revenue, net income, cash flows need a 1-year period
    - Latest filing wins
    - Tags:
      * Revenue: RevenueFromContractWithCustomerExcludingAssessedTax, then Revenues
      * Net income: NetIncomeLoss
      * Operating cash flow: NetCashProvidedByUsedInOperatingActivities
      * Capital spending: PaymentsToAcquirePropertyPlantAndEquipment, then PaymentsToAcquireProductiveAssets
      * Equity: StockholdersEquity
      * Current Assets: AssetsCurrent
      * Current Liabilities: LiabilitiesCurrent
      * Total Liabilities: Liabilities
    - Derived Metrics:
      * ROE: Net Income ÷ Year-End Equity (not known if Equity <= 0)
      * Owner Earnings: Operating Cash Flow − Capital Spending (not found if either missing)
      * Current Ratio: AssetsCurrent ÷ LiabilitiesCurrent (not known if either missing or LiabCurrent <= 0)
      * Liabilities ÷ Equity: Liabilities ÷ Equity (not known if either missing or Equity <= 0)
    - Checks:
      * Buffett (3 checks):
        1. ROE of 15% or more every year
        2. Owner earnings positive every year
        3. Owner earnings grew, first year to last
      * Graham (3 checks):
        1. Current ratio of 2 or more, latest year (or custom threshold)
        2. Net income positive every year
        3. Net income grew, first year to last
      * Burry (2 checks):
        1. Operating cash flow at least net income every year
        2. Liabilities no more than twice equity, latest year
    """
    cik = get_cik_for_ticker(ticker)
    facts = get_company_facts(cik)
    entity_name = facts.get("entityName", ticker)
    us_gaap = facts.get("facts", {}).get("us-gaap", {})

    # Determine 10-K fiscal year ends from NetIncomeLoss
    ni_units = us_gaap.get("NetIncomeLoss", {}).get("units", {}).get("USD", [])
    fy_end_dates = set()
    for e in ni_units:
        if e.get("form") == "10-K" and "start" in e and "end" in e:
            try:
                d1 = datetime.strptime(e["start"], "%Y-%m-%d")
                d2 = datetime.strptime(e["end"], "%Y-%m-%d")
                if 340 <= (d2 - d1).days <= 385:
                    fy_end_dates.add(e["end"])
            except ValueError:
                pass

    if not fy_end_dates:
        rev_units = us_gaap.get("Revenues", {}).get("units", {}).get("USD", [])
        for e in rev_units:
            if e.get("form") == "10-K" and "start" in e and "end" in e:
                try:
                    d1 = datetime.strptime(e["start"], "%Y-%m-%d")
                    d2 = datetime.strptime(e["end"], "%Y-%m-%d")
                    if 340 <= (d2 - d1).days <= 385:
                        fy_end_dates.add(e["end"])
                except ValueError:
                    pass

    sorted_dates = sorted(list(fy_end_dates))
    last_5_dates = sorted_dates[-5:]

    rows = []
    used_tags = {}

    for dt in last_5_dates:
        rev_val, rev_tag = get_flow_value(
            us_gaap,
            ["RevenueFromContractWithCustomerExcludingAssessedTax", "Revenues"],
            dt
        )
        ni_val, ni_tag = get_flow_value(us_gaap, ["NetIncomeLoss"], dt)
        ocf_val, ocf_tag = get_flow_value(
            us_gaap, ["NetCashProvidedByUsedInOperatingActivities"], dt
        )
        capex_val, capex_tag = get_flow_value(
            us_gaap,
            ["PaymentsToAcquirePropertyPlantAndEquipment", "PaymentsToAcquireProductiveAssets"],
            dt
        )
        eq_val, eq_tag = get_instant_value(us_gaap, ["StockholdersEquity"], dt)
        ca_val, ca_tag = get_instant_value(us_gaap, ["AssetsCurrent"], dt)
        cl_val, cl_tag = get_instant_value(us_gaap, ["LiabilitiesCurrent"], dt)
        liab_val, liab_tag = get_instant_value(us_gaap, ["Liabilities"], dt)

        # Record tags used
        used_tags["Revenue"] = rev_tag or "not found"
        used_tags["Net Income"] = ni_tag or "not found"
        used_tags["Operating Cash Flow"] = ocf_tag or "not found"
        used_tags["Capital Spending"] = capex_tag or "not found"
        used_tags["Equity"] = eq_tag or "not found"
        used_tags["AssetsCurrent"] = ca_tag or "not found"
        used_tags["LiabilitiesCurrent"] = cl_tag or "not found"
        used_tags["Liabilities"] = liab_tag or "not found"

        # ROE calculation: net income ÷ year-end equity
        if eq_val is None or ni_val is None:
            roe = "not known"
        elif eq_val <= 0:
            roe = "not known"
        else:
            roe = (ni_val / eq_val) * 100.0

        # Owner earnings: operating cash flow - capital spending
        if ocf_val is None or capex_val is None:
            owner_earnings = "not found"
        else:
            owner_earnings = ocf_val - capex_val

        # Current ratio: Current Assets ÷ Current Liabilities
        if ca_val is None or cl_val is None:
            current_ratio = "not known"
        elif cl_val <= 0:
            current_ratio = "not known"
        else:
            current_ratio = ca_val / cl_val

        # Liabilities ÷ Equity: Total Liabilities ÷ Stockholders' Equity
        if liab_val is None or eq_val is None:
            liabilities_to_equity = "not known"
        elif eq_val <= 0:
            liabilities_to_equity = "not known"
        else:
            liabilities_to_equity = liab_val / eq_val

        rows.append({
            "end_date": dt,
            "revenue": rev_val,
            "net_income": ni_val,
            "operating_cash_flow": ocf_val,
            "capital_spending": capex_val,
            "equity": eq_val,
            "assets_current": ca_val,
            "liabilities_current": cl_val,
            "liabilities": liab_val,
            "roe": roe,
            "owner_earnings": owner_earnings,
            "current_ratio": current_ratio,
            "liabilities_to_equity": liabilities_to_equity,
            "tags": {
                "revenue": rev_tag,
                "net_income": ni_tag,
                "operating_cash_flow": ocf_tag,
                "capital_spending": capex_tag,
                "equity": eq_tag,
                "assets_current": ca_tag,
                "liabilities_current": cl_tag,
                "liabilities": liab_tag
            }
        })

    # =========================================================================
    # Buffett's Three Checks in Code
    # =========================================================================
    # Check 1: ROE of 15% or more every year
    buffett_roe = "pass"
    for r in rows:
        val = r["roe"]
        if val == "not known":
            buffett_roe = "not known"
            break
        elif isinstance(val, (int, float)):
            if val < 15.0:
                buffett_roe = "fail"
                break
        else:
            buffett_roe = "not known"
            break

    # Check 2: Owner earnings positive every year
    buffett_oe_pos = "pass"
    for r in rows:
        val = r["owner_earnings"]
        if val == "not found":
            buffett_oe_pos = "not known"
            break
        elif isinstance(val, (int, float)):
            if val <= 0:
                buffett_oe_pos = "fail"
                break
        else:
            buffett_oe_pos = "not known"
            break

    # Check 3: Owner earnings grew, first year to last
    buffett_oe_growth = "pass"
    if len(rows) < 2:
        buffett_oe_growth = "not known"
    else:
        first_oe = rows[0]["owner_earnings"]
        last_oe = rows[-1]["owner_earnings"]
        if first_oe == "not found" or last_oe == "not found":
            buffett_oe_growth = "not known"
        elif isinstance(first_oe, (int, float)) and isinstance(last_oe, (int, float)):
            if last_oe > first_oe:
                buffett_oe_growth = "pass"
            else:
                buffett_oe_growth = "fail"
        else:
            buffett_oe_growth = "not known"

    buffett_checks = {
        "roe_above_15_all_years": buffett_roe,
        "owner_earnings_positive_all_years": buffett_oe_pos,
        "owner_earnings_grew_first_to_last": buffett_oe_growth
    }

    # =========================================================================
    # Graham's Three Checks in Code
    # =========================================================================
    # Check 1: Current ratio of 2 or more, latest year (or threshold)
    if not rows:
        graham_cr = "not known"
    else:
        latest_cr = rows[-1]["current_ratio"]
        if latest_cr == "not known" or latest_cr is None:
            graham_cr = "not known"
        elif isinstance(latest_cr, (int, float)):
            if latest_cr >= graham_cr_threshold:
                graham_cr = "pass"
            else:
                graham_cr = f"fail ({latest_cr:.2f})"
        else:
            graham_cr = "not known"

    # Check 2: Net income positive every year
    graham_ni_pos = "pass"
    for r in rows:
        val = r["net_income"]
        if val is None or val == "not found":
            graham_ni_pos = "not known"
            break
        elif isinstance(val, (int, float)):
            if val <= 0:
                graham_ni_pos = "fail"
                break
        else:
            graham_ni_pos = "not known"
            break

    # Check 3: Net income grew, first year to last
    graham_ni_growth = "pass"
    if len(rows) < 2:
        graham_ni_growth = "not known"
    else:
        first_ni = rows[0]["net_income"]
        last_ni = rows[-1]["net_income"]
        if first_ni is None or last_ni is None or first_ni == "not found" or last_ni == "not found":
            graham_ni_growth = "not known"
        elif isinstance(first_ni, (int, float)) and isinstance(last_ni, (int, float)):
            if last_ni > first_ni:
                graham_ni_growth = "pass"
            else:
                graham_ni_growth = "fail"
        else:
            graham_ni_growth = "not known"

    graham_checks = {
        "current_ratio_threshold": graham_cr,
        "net_income_positive_all_years": graham_ni_pos,
        "net_income_grew_first_to_last": graham_ni_growth,
        "threshold_used": graham_cr_threshold
    }

    # =========================================================================
    # Burry's Two Checks in Code
    # =========================================================================
    # Check 1: Operating cash flow at least net income every year
    burry_ocf_ge_ni = "pass"
    for r in rows:
        ocf_v = r["operating_cash_flow"]
        ni_v = r["net_income"]
        if ocf_v is None or ni_v is None or ocf_v == "not found" or ni_v == "not found":
            burry_ocf_ge_ni = "not known"
            break
        elif isinstance(ocf_v, (int, float)) and isinstance(ni_v, (int, float)):
            if ocf_v < ni_v:
                burry_ocf_ge_ni = "fail"
                break
        else:
            burry_ocf_ge_ni = "not known"
            break

    # Check 2: Liabilities no more than twice equity, latest year
    if not rows:
        burry_liab_le_2x_eq = "not known"
    else:
        latest_le = rows[-1]["liabilities_to_equity"]
        if latest_le == "not known" or latest_le is None:
            burry_liab_le_2x_eq = "not known"
        elif isinstance(latest_le, (int, float)):
            if latest_le <= 2.0:
                burry_liab_le_2x_eq = f"pass ({latest_le:.2f})"
            else:
                burry_liab_le_2x_eq = f"fail ({latest_le:.2f})"
        else:
            burry_liab_le_2x_eq = "not known"

    burry_checks = {
        "operating_cash_flow_ge_net_income_all_years": burry_ocf_ge_ni,
        "liabilities_no_more_than_twice_equity_latest_year": burry_liab_le_2x_eq
    }

    # Panel checks list (Investor, Check, Result)
    panel_table = [
        {"investor": "Buffett", "check": "ROE of 15% or more every year", "result": buffett_roe},
        {"investor": "Buffett", "check": "Owner earnings positive every year", "result": buffett_oe_pos},
        {"investor": "Buffett", "check": "Owner earnings grew, first year to last", "result": buffett_oe_growth},
        {
            "investor": "Graham",
            "check": f"Current ratio of {graham_cr_threshold:g} or more, latest year",
            "result": graham_cr
        },
        {"investor": "Graham", "check": "Net income positive every year", "result": graham_ni_pos},
        {"investor": "Graham", "check": "Net income grew, first year to last", "result": graham_ni_growth},
        {"investor": "Burry", "check": "Operating cash flow at least net income every year", "result": burry_ocf_ge_ni},
        {"investor": "Burry", "check": "Liabilities no more than twice equity, latest year", "result": burry_liab_le_2x_eq},
    ]

    # Investor verdicts
    # Buffett passes if 3/3
    b_passes = sum(1 for c in [buffett_roe, buffett_oe_pos, buffett_oe_growth] if c == "pass")
    b_verdict = "Own the business" if b_passes == 3 else ("Pass" if "fail" in [buffett_roe, buffett_oe_pos, buffett_oe_growth] else "Watch it")

    # Graham passes if 3/3
    g_passes = 0
    if graham_cr == "pass": g_passes += 1
    if graham_ni_pos == "pass": g_passes += 1
    if graham_ni_growth == "pass": g_passes += 1
    g_verdict = "Enter position (Margin of Safety)" if g_passes == 3 else ("Reject / Pass" if "fail" in str(graham_cr) or graham_ni_pos == "fail" or graham_ni_growth == "fail" else "Defensive watch")

    # Burry passes if 2/2
    burry_p1 = burry_ocf_ge_ni == "pass"
    burry_p2 = "pass" in str(burry_liab_le_2x_eq)
    burry_passes = (1 if burry_p1 else 0) + (1 if burry_p2 else 0)
    burry_verdict = "High Conviction Long" if burry_passes == 2 else ("Avoid / Short candidate" if "fail" in str(burry_ocf_ge_ni) or "fail" in str(burry_liab_le_2x_eq) else "Monitor / Scavenge")

    verdicts = {
        "Buffett": {"score": f"{b_passes} of 3", "verdict": b_verdict},
        "Graham": {"score": f"{g_passes} of 3", "verdict": g_verdict},
        "Burry": {"score": f"{burry_passes} of 2", "verdict": burry_verdict}
    }

    return {
        "ticker": ticker.upper(),
        "entity_name": entity_name,
        "cik": cik,
        "rows": rows,
        "tags": used_tags,
        "buffett_checks": buffett_checks,
        "graham_checks": graham_checks,
        "burry_checks": burry_checks,
        "panel_table": panel_table,
        "verdicts": verdicts
    }


def format_table(data: dict) -> str:
    """Format extracted 5 fiscal years and the legend panel into clean tables."""
    rows = data["rows"]
    lines = []
    lines.append(f"{data['ticker']} ({data['entity_name']}), $ millions:")
    header = f"{'FY end':<12} | {'Revenue':<9} | {'Net income':<10} | {'Operating cash flow':<20} | {'Capital spending':<16} | {'Equity':<8} | {'AssetsCurr':<10} | {'LiabCurr':<10} | {'Liabilities':<11}"
    sep = "-" * len(header)
    lines.append(header)
    lines.append(sep)

    for r in rows:
        def fmt(val):
            if val is None or val == "not found":
                return "not found"
            if isinstance(val, (int, float)):
                return f"{val / 1e6:,.0f}"
            return str(val)

        line = (
            f"{r['end_date']:<12} | "
            f"{fmt(r['revenue']):>9} | "
            f"{fmt(r['net_income']):>10} | "
            f"{fmt(r['operating_cash_flow']):>20} | "
            f"{fmt(r['capital_spending']):>16} | "
            f"{fmt(r['equity']):>8} | "
            f"{fmt(r['assets_current']):>10} | "
            f"{fmt(r['liabilities_current']):>10} | "
            f"{fmt(r['liabilities']):>11}"
        )
        lines.append(line)

    lines.append("")
    lines.append("Ratios:")
    r_hdr = f"{'FY end':<12} | {'Current ratio':<14} | {'Liabilities ÷ equity':<20} | {'ROE %':<8} | {'Owner earnings ($M)':<20}"
    lines.append(r_hdr)
    lines.append("-" * len(r_hdr))
    for r in rows:
        cr_s = f"{r['current_ratio']:.2f}" if isinstance(r['current_ratio'], (int, float)) else str(r['current_ratio'])
        le_s = f"{r['liabilities_to_equity']:.2f}" if isinstance(r['liabilities_to_equity'], (int, float)) else str(r['liabilities_to_equity'])
        roe_s = f"{r['roe']:.1f}%" if isinstance(r['roe'], (int, float)) else str(r['roe'])
        def fmt_m(val):
            if val is None or val == "not found": return "not found"
            if isinstance(val, (int, float)): return f"{val / 1e6:,.0f}"
            return str(val)
        oe_s = fmt_m(r['owner_earnings'])
        lines.append(f"{r['end_date']:<12} | {cr_s:>14} | {le_s:>20} | {roe_s:>8} | {oe_s:>20}")

    lines.append("")
    lines.append("The Panel Table:")
    p_hdr = f"{'Investor':<10} | {'Check':<52} | {data['ticker']}"
    lines.append(p_hdr)
    lines.append("-" * len(p_hdr))
    for p in data["panel_table"]:
        lines.append(f"{p['investor']:<10} | {p['check']:<52} | {p['result']}")

    lines.append("")
    lines.append("Panel Summary Scores:")
    for inv, res in data["verdicts"].items():
        lines.append(f"  - {inv}: {res['score']} -> Verdict: {res['verdict']}")

    return "\n".join(lines)


def get_allowed_printed_numbers(data: dict) -> set:
    """
    Collect all numbers printed by the script to audit against hallucinations in the memo.
    Includes integer and 1/2-decimal versions, raw values, values in millions, dates, ratios, and check constants.
    """
    allowed = set()
    # Structural constants
    allowed.update({1, 2, 3, 5, 10, 15, 2.0, 1.0, 15.0, 0, 0.0})

    for r in data["rows"]:
        # Dates: year, month, day
        try:
            parts = r["end_date"].split("-")
            for p in parts:
                allowed.add(int(p))
                allowed.add(float(p))
        except Exception:
            pass

        # Raw & millions for numeric flows and balances
        for field in [
            "revenue", "net_income", "operating_cash_flow", "capital_spending",
            "equity", "assets_current", "liabilities_current", "liabilities", "owner_earnings"
        ]:
            val = r[field]
            if isinstance(val, (int, float)):
                millions_int = int(round(val / 1e6))
                millions_flt = round(val / 1e6, 1)
                allowed.add(millions_int)
                allowed.add(millions_flt)
                allowed.add(int(val))

        # Ratios
        for r_name in ["roe", "current_ratio", "liabilities_to_equity"]:
            val = r[r_name]
            if isinstance(val, (int, float)):
                allowed.add(round(val, 2))
                allowed.add(round(val, 1))
                allowed.add(int(round(val)))

    return allowed


if __name__ == "__main__":
    t = sys.argv[1] if len(sys.argv) > 1 else "COST"
    res = extract_panel_data(t)
    print(format_table(res))

