# Benjamin Graham Memo: Microsoft Corp (MSFT)

**Verdict:** Reject / Pass (Classical) · Defensive watch (Adjusted)

### 1. Balance Sheet Safety & Liquidity
A conservative margin of safety requires strong working capital buffers to absorb macroeconomic volatility without relying on debt refinancing.

### 2. Quantitative Evaluation from Audited 10-K Filings
Across the 5 fiscal years from 2022 to 2026:
- **Current Ratio (Hurdle >= 2.0):** In the latest year (2026), current assets were 207,710 compared to current liabilities of 168,825, resulting in a current ratio of 1.23. In previous years, current ratios were 1.78 in 2022, 1.77 in 2023, 1.27 in 2024, and 1.35 in 2025. Because 1.23 falls below 2.0, Microsoft fails Graham's classical liquidity test in 2026 (1.23).
- **Earnings Stability (Positive Net Income):** Net income was positive in each year: 72,738 in 2022, 72,361 in 2023, 88,136 in 2024, 101,832 in 2025, and 133,749 in 2026.
- **Earnings Growth:** Net income grew substantially from 72,738 in the first year to 133,749 in the last year, comfortably passing the growth check.

### 3. Conclusion & Threshold Probe
Microsoft satisfies 2 of 3 Graham checks, failing on classical liquidity.

Threshold kept: 1.0; Microsoft's massive unearned revenue and predictable deferred subscription contracts provide abundant liquidity that makes the classical 2.0 industrial working capital ratio overly restrictive.

