# Warren Buffett Memo: Costco Wholesale Corp (COST)

**Verdict:** Own the business

### 1. Circle of Competence & Economic Moat
Costco operates a disciplined warehouse retail model protected by an impregnable moat: customer membership loyalty, massive purchasing scale, and negative working capital. The company reinvests profits into delivering the lowest possible prices to its members, driving repeat foot traffic and predictable annual cash flows.

### 2. Quantitative Evaluation from Audited 10-K Filings
Over the 5 fiscal years from 2022 to 2026, Costco satisfied all 3 quantitative hurdles:
- **Return on Equity (ROE >= 15%):** Net income divided by year-end stockholders' equity was 28.3% in 2022, 25.1% in 2023, 31.2% in 2024, 27.8% in 2025, and 25.8% in 2026. Every year exceeded our 15% hurdle.
- **Owner Earnings Positive:** Operating cash flow minus capital expenditures was 3,501 in 2022, 6,745 in 2023, 6,629 in 2024, 7,837 in 2025, and 9,382 in 2026. Cash generation was positive across all 5 years.
- **Owner Earnings Growth:** Owner earnings expanded from 3,501 in 2022 to 9,382 in 2026, representing substantial compounding of free cash flow.

### 3. Conclusion
Costco demonstrates the durable competitive advantages, shareholder-oriented stewardship, and consistent capital productivity required of a core long-term franchise holding.

