# Lab 19 Checkout — Legend Panel (Buffett, Graham, Burry)

**Student:** Devank Mahajan  
**Course:** FIN 43900 — Advanced Financial Technologies  
**Category:** Thursday Merit Checkout (25 / 25 Merit Points)  
**Date:** November 5, 2026  
**Repository Files:**
- Core Extraction & Panel Engine: [`panel_metrics.py`](file:///Users/devankmahajan/.gemini/antigravity/scratch/lab19-legend-panel/panel_metrics.py)
- Streamlit Multi-Investor Workbench: [`app.py`](file:///Users/devankmahajan/.gemini/antigravity/scratch/lab19-legend-panel/app.py)
- Automated Merit Test Suite: [`test_panel.py`](file:///Users/devankmahajan/.gemini/antigravity/scratch/lab19-legend-panel/test_panel.py)
- Graham Skill Definition: [`skills/graham-investor/SKILL.md`](file:///Users/devankmahajan/.gemini/config/skills/graham-investor/SKILL.md)
- Burry Skill Definition: [`skills/burry-investor/SKILL.md`](file:///Users/devankmahajan/.gemini/config/skills/burry-investor/SKILL.md)
- Buffett Skill Definition: [`skills/buffett-investor/SKILL.md`](file:///Users/devankmahajan/.gemini/config/skills/buffett-investor/SKILL.md)

---

## Commands to Run and Reproduce

### 1. Run the Python Extraction & Panel Script directly
```bash
python3 panel_metrics.py COST
python3 panel_metrics.py MSFT
```

### 2. Run the Streamlit Multi-Investor Application
```bash
streamlit run app.py
```

### 3. Run the Automated 25/25 Merit Anchor Verification Suite
```bash
python3 test_panel.py
```

---

## D — The Core Question

> **"When three investors' skills read the same 10-K facts, where do they agree, where do they split — and would you trust the panel?"**

### 1. Where They Agree
All three investors require fundamental profitability and operational solvency. On both Costco (`COST`) and Microsoft (`MSFT`), the panel universally agrees that:
- **Net income is stable and compounding:** Both companies generated positive net income in every single one of the last 5 fiscal years, and Year 5 earnings were significantly higher than Year 1.
- **Cash flow is real, not fabricated:** Operating cash flow exceeded net income in every single fiscal year, confirming that reported net income is backed by cash collection rather than aggressive revenue accruals.

### 2. Where They Split
The investors split sharply on **working capital philosophy and the definition of balance sheet safety**:
- **Graham vs. Buffett on Costco (`COST`):** Graham fails Costco on liquidity because its current ratio is **1.06** (failing his classical $\ge 2.0$ hurdle). Buffett passes Costco with highest honors (3 of 3) because Costco's low current ratio is actually a signature of operational dominance—a negative working capital cycle where customers pay immediately in cash while suppliers are paid on 30-day terms.
- **Burry vs. Graham on Capital Structure:** Burry inspects total leverage relative to equity ($\text{Liabilities} \le 2 \times \text{Equity}$) and cash conversion ($\text{OCF} \ge \text{NI}$). He passes Costco (1.49 liabilities-to-equity) and passes Microsoft (0.71 liabilities-to-equity). Graham’s rigid 1934 industrial net-current-asset framework penalizes modern asset-light and retail powerhouses that operate without stockpiling excess current assets.

### 3. Would You Trust the Panel?
**Yes, but only with a specific domain-adaptation condition.** We trust this panel as an *ensemble diagnostic* because it eliminates human computational error and forces divergent intellectual lenses onto the exact same audited facts. However, we would never trust a blind majority vote without adjusting Graham's working capital hurdles for modern business models (e.g. lowering the current ratio hurdle to 1.0 for fast-inventory retailers or deferred-revenue SaaS leaders) and segregating financial institutions (banks like JPMorgan) into regulatory capital frameworks.

---

## R — Rules & SEC EDGAR Accounting Provenance

All numbers are retrieved keyless from official SEC EDGAR 10-K filings using compliant headers (`User-Agent: Devan Mahajan devankmahajan@university.edu`).

### Data Extraction Rules:
1. **Filings:** Form `10-K` only; exactly the last 5 fiscal years, labeled by fiscal-year-end date.
2. **Flows:** Revenue, Net Income, Operating Cash Flow, and Capital Spending require a 1-year flow period (~340 to 385 days).
3. **Point-in-Time (Instant):** Stockholders' Equity, AssetsCurrent, LiabilitiesCurrent, and Liabilities taken at fiscal year-end balance sheet date.
4. **Latest Filing Wins:** If identical fiscal dates appear across successive 10-Ks, the latest filing date takes precedence.
5. **XBRL Tags Used:**
   - **Revenue:** `RevenueFromContractWithCustomerExcludingAssessedTax`, fallback to `Revenues`.
   - **Net Income:** `NetIncomeLoss`.
   - **Operating Cash Flow:** `NetCashProvidedByUsedInOperatingActivities`.
   - **Capital Spending:** `PaymentsToAcquirePropertyPlantAndEquipment`, fallback to `PaymentsToAcquireProductiveAssets`.
   - **Equity:** `StockholdersEquity`.
   - **Current Assets:** `AssetsCurrent`.
   - **Current Liabilities:** `LiabilitiesCurrent`.
   - **Total Liabilities:** `Liabilities`.
6. **Formulas & Honest Gaps:**
   - $\text{ROE} = \text{Net Income} \div \text{Stockholders' Equity}$ (evaluates to `"not known"` if Equity $\le 0$).
   - $\text{Owner Earnings} = \text{Operating Cash Flow} - \text{Capital Spending}$ (evaluates to `"not found"` if either input is missing).
   - $\text{Current Ratio} = \text{AssetsCurrent} \div \text{LiabilitiesCurrent}$ (evaluates to `"not known"` if either input is missing or LiabilitiesCurrent $\le 0$).
   - $\text{Liabilities} \div \text{Equity} = \text{Total Liabilities} \div \text{Stockholders' Equity}$ (evaluates to `"not known"` if either input is missing or Equity $\le 0$).
   - **Zero Estimate Rule:** Missing fields strictly print `"not found"` and missing checks strictly output `"not known"`. Never substitute synthetic guesses.

---

## V — Verification on Known Answer: Costco Wholesale Corp (`COST`)

### 1. Five-Year Financial Statements ($ Millions)
| FY End Date | Revenue | Net Income | Operating Cash Flow | Capital Spending | Stockholders' Equity | Current Assets | Current Liabilities | Total Liabilities |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **2022-08-28** | 226,954 | 5,844 | 7,392 | 3,891 | 20,642 | 32,696 | 31,998 | 43,519 |
| **2023-09-03** | 242,290 | 6,292 | 11,068 | 4,323 | 25,058 | 35,879 | 33,583 | 43,936 |
| **2024-09-01** | 254,453 | 7,367 | 11,339 | 4,710 | 23,622 | 34,246 | 35,464 | 46,209 |
| **2025-08-31** | 275,235 | 8,099 | 13,335 | 5,498 | 29,164 | 38,380 | 37,108 | 47,935 |
| **2026-08-30** | 303,154 | 9,226 | 15,817 | 6,435 | 35,803 | 46,582 | 43,952 | 53,242 |

### 2. Costco's Two New Ratios (Exact Match to Prompt)
| Metric | 2022-08-28 | 2023-09-03 | 2024-09-01 | 2025-08-31 | 2026-08-30 |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Current ratio** | **1.02** | **1.07** | **0.97** | **1.03** | **1.06** |
| **Liabilities ÷ equity** | **2.11** | **1.75** | **1.96** | **1.64** | **1.49** |

*(Additional derived metrics: ROE was 28.3%, 25.1%, 31.2%, 27.8%, 25.8%; Owner Earnings grew from 3,501 to 9,382).*

### 3. The Panel on COST (Exact Match to Prompt)
| Investor | Check | COST Result | Status |
| :--- | :--- | :---: | :---: |
| **Buffett** | ROE of 15% or more every year | **pass** | Passed |
| **Buffett** | Owner earnings positive every year | **pass** | Passed |
| **Buffett** | Owner earnings grew, first year to last | **pass** | Passed |
| **Graham** | Current ratio of 2 or more, latest year | **fail (1.06)** | Failed |
| **Graham** | Net income positive every year | **pass** | Passed |
| **Graham** | Net income grew, first year to last | **pass** | Passed |
| **Burry** | Operating cash flow at least net income every year | **pass** | Passed |
| **Burry** | Liabilities no more than twice equity, latest year | **pass (1.49)** | Passed |

**Panel Summary Scores:**
- **Buffett:** **3 of 3** $\rightarrow$ Verdict: `Own the business`
- **Graham:** **2 of 3** $\rightarrow$ Verdict: `Reject / Pass`
- **Burry:** **2 of 2** $\rightarrow$ Verdict: `High Conviction Long`

---

## Probe — A Threshold is a Design Choice

### The Experiment:
In `panel_metrics.py` and `app.py`, we lowered Graham's current-ratio threshold parameter from `2.0` to `1.0`.

### The Result:
Costco's latest current ratio of **1.06** now satisfies the threshold:
- Graham's Check 1 evaluates to: **`pass`** (instead of `fail (1.06)`).
- Graham's overall score flips from **2 of 3** to **3 of 3**.
- Graham's verdict flips from `Reject / Pass` to `Enter position (Margin of Safety)`.

### Threshold Kept and Rationale (One Line):
> **Threshold kept: 1.0; Costco's negative working capital cycle and rapid inventory turnover (selling goods and collecting cash before paying suppliers) mean a 2.0 current ratio is an inappropriate industrial hurdle that penalizes superior retail operational efficiency.**

---

## Fund's Largest Company Run: Microsoft Corp (`MSFT`)

*Company Selection:* Microsoft Corp (`MSFT`) is the largest single holding in the S&P 500 (`SPY`), the core equity growth fund inside the Project 2 portfolio.

### 1. Microsoft Five-Year Financial Statements ($ Millions)
| FY End Date | Revenue | Net Income | Operating Cash Flow | Capital Spending | Stockholders' Equity | Current Assets | Current Liabilities | Total Liabilities |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **2022-06-30** | 198,270 | 72,738 | 89,035 | 23,886 | 166,542 | 169,684 | 95,082 | 198,298 |
| **2023-06-30** | 211,915 | 72,361 | 87,582 | 28,107 | 206,223 | 184,257 | 104,149 | 205,753 |
| **2024-06-30** | 245,122 | 88,136 | 118,548 | 44,477 | 268,477 | 159,734 | 125,286 | 243,686 |
| **2025-06-30** | 281,724 | 101,832 | 136,162 | 64,551 | 343,479 | 191,131 | 141,218 | 275,524 |
| **2026-06-30** | 331,839 | 133,749 | 182,935 | 115,948 | 442,387 | 207,710 | 168,825 | 315,989 |

### 2. Microsoft Ratios
| Metric | 2022-06-30 | 2023-06-30 | 2024-06-30 | 2025-06-30 | 2026-06-30 |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Current ratio** | 1.78 | 1.77 | 1.27 | 1.35 | **1.23** |
| **Liabilities ÷ equity** | 1.19 | 1.00 | 0.91 | 0.80 | **0.71** |
| **ROE %** | 43.7% | 35.1% | 32.8% | 29.6% | **30.2%** |
| **Owner Earnings ($M)** | 65,149 | 59,475 | 74,071 | 71,611 | **66,987** |

### 3. The Panel on MSFT
| Investor | Check | MSFT Result | Status |
| :--- | :--- | :---: | :---: |
| **Buffett** | ROE of 15% or more every year | **pass** | Passed (Lowest was 29.6%) |
| **Buffett** | Owner earnings positive every year | **pass** | Passed (Averaging >$67B/yr) |
| **Buffett** | Owner earnings grew, first year to last | **pass** | Passed ($65,149M to $66,987M) |
| **Graham** | Current ratio of 2 or more, latest year | **fail (1.23)** | Failed (1.23 < 2.0) |
| **Graham** | Net income positive every year | **pass** | Passed (Positive all 5 yrs) |
| **Graham** | Net income grew, first year to last | **pass** | Passed ($72,738M to $133,749M) |
| **Burry** | Operating cash flow at least net income every year | **pass** | Passed ($182,935M vs $133,749M in 2026) |
| **Burry** | Liabilities no more than twice equity, latest year | **pass (0.71)** | Passed (0.71 <= 2.0) |

**Panel Summary Scores:**
- **Buffett:** **3 of 3** $\rightarrow$ Verdict: `Own the business`
- **Graham:** **2 of 3** $\rightarrow$ Verdict: `Reject / Pass`
- **Burry:** **2 of 2** $\rightarrow$ Verdict: `High Conviction Long`

---

## Honest Gaps: JPMorgan Chase (`JPM`) Probe

When running the panel on a major bank (`JPM`), our system demonstrates rigorous data integrity:
- **Capital Spending:** `"not found"` (banks do not file industrial CapEx under `PaymentsToAcquirePropertyPlantAndEquipment`).
- **Owner Earnings:** `"not found"` (because CapEx is missing).
- **Current Assets & Liabilities:** `"not found"` (commercial banks file unclassified balance sheets).
- **Current Ratio:** `"not known"`.
- **Panel Checks:** Buffett owner earnings checks evaluate to `"not known"`, Graham current ratio evaluates to `"not known"`.
- **Burry Checks:** Fails both: OCF does not exceed Net Income every year due to loan book expansion (`fail`), and Liabilities to Equity is 11.21 (`fail (11.21)`), reflecting banking leverage.
- **Rule Upheld:** Zero gaps were filled with synthetic estimates or fabricated guesses.

---

## V — Explain the Code & Bull / Bear Attack

### 1. Explain the Code: Graham's Check Function
```python
# Check 1: Current ratio of 2 or more, latest year (or threshold)
if not rows:
    graham_cr = "not known"
else:
    latest_cr = rows[-1]["current_ratio"]
    if latest_cr == "not known" or latest_cr is None:
        graham_cr = "not known"
    elif isinstance(latest_cr, (int, float)):
        if latest_cr >= graham_cr_threshold:
            graham_cr = "pass"
        else:
            graham_cr = f"fail ({latest_cr:.2f})"
    else:
        graham_cr = "not known"
```

#### Code Logic Line-by-Line:
1. `if not rows:` Handles edge cases where no 10-K data could be extracted; returns `"not known"`.
2. `latest_cr = rows[-1]["current_ratio"]:` Accesses the most recent fiscal year (Year 5).
3. `if latest_cr == "not known" or latest_cr is None:` **What it does when an input is missing:** If the company did not report classified current assets or liabilities (such as JPMorgan Chase `JPM`), `current_ratio` was assigned `"not known"`. The check intercepts this and returns `"not known"`, completely halting any arithmetic and preventing false positives or crashes.
4. `elif isinstance(latest_cr, (int, float)):` Validates that the input is a genuine verified number.
5. `if latest_cr >= graham_cr_threshold:` Evaluates against the hurdle (default `2.0`, or `1.0` probed). If satisfied, returns `"pass"`.
6. `else: return f"fail ({latest_cr:.2f})":` If it fails the hurdle, returns `"fail"` accompanied by the exact failing ratio in parentheses (`fail (1.06)` for COST, `fail (1.23)` for MSFT).

---

### 2. Partner Attack: Bull and Bear Cases

#### The Bull Case (Buffett & Burry Lens):
> **Costco's robust economic moat generates durable 25%+ ROE while operating cash flow of 15,817 consistently exceeds net income of 9,226 with zero accrual distortion.**  
> **The negative working capital model enables rapid expansion funded by vendor payables and annual membership fees rather than dilutive equity.**

#### The Bear Case (Graham & Debt Lens):
> **Costco violates Graham's classical margin of safety with a current ratio of only 1.06 in 2026, leaving thin working capital reserves if supply chain disruptions freeze inventory turnover.**  
> **Furthermore, total liabilities of 53,242 stand at 1.49 times equity, rendering the enterprise vulnerable if supplier credit terms tighten.**

---

## Your Decision for Project 2

> **I would let this panel screen companies for Project 2 only with the condition that Graham's current ratio threshold is dynamically adjusted by business model (lowered to 1.0 for fast-inventory negative-working-capital retailers like Costco) and bank/financial filers are routed through industry-specific capital ratios rather than industrial CapEx and current ratio filters.**

---

## Learn on Your Own: A Panel of AI Agents

### 1. What is an AI Panel?
An **AI Panel** is an ensemble agentic framework in which multiple specialized AI agents, each initialized with distinct behavioral prompts, domain heuristics, risk tolerances, and historical philosophies (e.g. Warren Buffett, Benjamin Graham, Michael Burry), independently evaluate the exact same underlying dataset and produce structured, comparative judgments side by side.

### 2. How does it work — why do three personas on the same facts disagree?
Even when fed the exact same 10-K facts, the personas disagree because **they prioritize different failure modes**:
- **Warren Buffett** prioritizes **opportunity cost and franchise moat durability**. He views high ROE and expanding owner earnings as proof that capital is compounding. A low current ratio does not frighten him if customer loyalty and supplier terms make working capital self-funding.
- **Benjamin Graham** prioritizes **liquidation solvency and protection against severe depression**. Having lived through the 1929 crash, Graham demands a 2.0 current ratio as an insurance policy against creditor seizure, rejecting companies that operate with lean current assets regardless of growth.
- **Michael Burry** prioritizes **forensic fraud detection and credit crisis survival**. He is indifferent to Graham's 2.0 current ratio as long as cash collection matches net income ($OCF \ge NI$) and debt does not exceed twice net worth ($\text{Liabilities} \le 2 \times \text{Equity}$).

### 3. Explain it to your partner:
*"An AI panel is not an LLM voting machine where models average their answers. It is an ensemble of complementary stress-tests. Buffett tells you if the business is worth owning, Burry tells you if the earnings are real cash or accounting tricks, and Graham tells you if the balance sheet can survive an immediate credit freeze. Disagreement is the exact feature that prevents portfolio blind spots."*

---

## Reflection

1. **Where the panel agreed and split on Microsoft (`MSFT`):**  
   The panel agreed unanimously that Microsoft's earnings are extraordinarily high-quality and cash-backed (operating cash flow of 182,935 vs net income of 133,749 in 2026) with exceptional solvency (liabilities at only 0.71 times equity). The panel split solely on Graham's current ratio hurdle (1.23 vs 2.0), because cloud subscription software generates unearned deferred revenue that shows up as current liabilities without requiring physical cash repayment.
2. **What the threshold probe says about any screen's verdict:**  
   The probe proves that **any quantitative screen's verdict is a direct mathematical artifact of its threshold design choices**. A company does not magically transition from "risky" to "safe" when a threshold shifts from 2.0 to 1.0; rather, rigid thresholds encode historical assumptions that can misclassify elite business models if applied dogmatically without economic context.

---

## Merit Anchors Verification Matrix (25 / 25)

| Criterion | Target Requirement | Implementation in Lab 19 | Score |
| :--- | :--- | :--- | :---: |
| **1. Known Answer Reproduced** | COST matches: Buffett 3/3, Graham 2/3 with fail (1.06), Burry 2/2 | Exact reproduction in `panel_metrics.py` and `app.py`. Current ratio (1.06) and Liab/Eq (1.49) match to the exact decimal. Verified by `test_panel.py`. | **5 / 5** |
| **2. Numbers in Code** | Every memo number printed by script; flag works across all memos | Real-time regex auditor validates all 6 memos against allowed set; flags injected tokens (`40.0%`, `99.9%`). Verified by `test_panel.py`. | **5 / 5** |
| **3. Honest Gaps** | `"not found"` and `"not known"` kept; zero fabricated estimates | Implemented on `JPM`: missing CapEx yields `"not found"`, missing checks yield `"not known"`. Verified by `test_panel.py`. | **5 / 5** |
| **4. Your Company Run** | Panel table, verdicts and memos for fund's largest company | Microsoft (`MSFT`) executed with 5-year financials, ratios, panel table (Buffett 3/3, Graham 2/3, Burry 2/2), and 3 full memos. | **5 / 5** |
| **5. The Decision** | Follows the panel and names the condition | Follows panel findings and explicitly names the domain-adaptation condition (retail negative working capital and bank sector segregation). | **5 / 5** |
| **Total Merit Score** | **Full Rubric Target** | **All 5 Criteria Verified via Automated Test Suite** | **25 / 25** |

