# Michael Burry Memo: Microsoft Corp (MSFT)

**Verdict:** High Conviction Long

### 1. Forensic Cash Flow & Leverage Lens
We scrutinize the gap between operating cash flow and net income to verify accounting conservatism, alongside total balance sheet debt burdens relative to net equity.

### 2. Quantitative Evaluation from Audited 10-K Filings
Across the 5 fiscal years from 2022 to 2026:
- **Cash Flow vs. Net Income Quality (OCF >= Net Income):** Operating cash flow surpassed net income in each year:
  - 2022: Operating cash flow of 89,035 exceeded net income of 72,738.
  - 2023: Operating cash flow of 87,582 exceeded net income of 72,361.
  - 2024: Operating cash flow of 118,548 exceeded net income of 88,136.
  - 2025: Operating cash flow of 136,162 exceeded net income of 101,832.
  - 2026: Operating cash flow of 182,935 exceeded net income of 133,749.
  This continuous cash surplus validates top-tier earnings conversion with zero aggressive receivables capitalization.
- **Balance Sheet Leverage (Liabilities <= 2x Equity):** In the latest year (2026), total liabilities were 315,989 against stockholders' equity of 442,387, yielding a liabilities-to-equity ratio of 0.71. Across prior years, this ratio was 1.19 in 2022, 1.00 in 2023, 0.91 in 2024, and 0.80 in 2025. Microsoft comfortably beats the 2.0 ceiling with a conservative 0.71 ratio.

### 3. Conclusion
Microsoft passes both of Burry's forensic checks (2 of 2), demonstrating pristine cash generation and robust solvency protection.

