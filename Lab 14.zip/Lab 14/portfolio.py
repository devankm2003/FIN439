"""
portfolio.py - Portfolio Risk & Return Baseline Engine
FIN439: Corporate Valuation and Investment Policy Analysis (Lab 14)
Standard Library Only.

Computes expected return, variance, and volatility for candidate asset allocations
using modern portfolio theory covariance matrices built from editable inputs.
"""

import math
import sys

# ==============================================================================
# EDITABLE INPUTS (Course-authored training values, not market estimates)
# ==============================================================================

# Sleeves order in reporting
SLEEVES = [
    "Treasury bills",
    "Treasury 10-year note",
    "Investment-grade bond fund",
    "Global equity index fund",
]

# Expected return per sleeve (% annual)
EXPECTED_RETURNS = {
    "Treasury bills": 3.5,
    "Treasury 10-year note": 4.3,
    "Investment-grade bond fund": 5.0,
    "Global equity index fund": 8.0,
}

# Volatility per sleeve (% annual standard deviation)
VOLATILITIES = {
    "Treasury bills": 0.5,
    "Treasury 10-year note": 7.0,
    "Investment-grade bond fund": 6.0,
    "Global equity index fund": 16.0,
}

# Pairwise Correlation Matrix
CORRELATIONS = {
    "Treasury bills": {
        "Treasury bills": 1.00,
        "Treasury 10-year note": 0.10,
        "Investment-grade bond fund": 0.05,
        "Global equity index fund": 0.00,
    },
    "Treasury 10-year note": {
        "Treasury bills": 0.10,
        "Treasury 10-year note": 1.00,
        "Investment-grade bond fund": 0.80,
        "Global equity index fund": -0.10,
    },
    "Investment-grade bond fund": {
        "Treasury bills": 0.05,
        "Treasury 10-year note": 0.80,
        "Investment-grade bond fund": 1.00,
        "Global equity index fund": 0.25,
    },
    "Global equity index fund": {
        "Treasury bills": 0.00,
        "Treasury 10-year note": -0.10,
        "Investment-grade bond fund": 0.25,
        "Global equity index fund": 1.00,
    },
}

# Objective Return: CPI + 4% (where CPI = 2.5%, so 6.5%)
OBJECTIVE_RETURN = 6.5

# Reserve-eligible sleeves under Meridian Mandate (Lab 13)
RESERVE_ELIGIBLE_SLEEVES = {
    "Treasury bills",
    "Treasury 10-year note",
}


# ==============================================================================
# INPUT VALIDATION FUNCTIONS
# ==============================================================================

def validate_correlations(sleeves, correlations):
    """
    Validates correlation matrix integrity:
    1. Every correlation must be bounded between -1.0 and 1.0 inclusive.
    2. The correlation matrix must be symmetric: Corr(i, j) == Corr(j, i).
    3. Self-correlations on the diagonal must equal 1.0.

    Raises ValueError with a clear, descriptive message if any check fails.
    """
    tol = 1e-7

    for i in sleeves:
        if i not in correlations:
            raise ValueError(f"Input Error: Missing sleeve '{i}' in correlation table.")

        # Check diagonal
        diag_val = correlations[i].get(i, None)
        if diag_val is None or abs(diag_val - 1.0) > tol:
            raise ValueError(
                f"Validation Error: Diagonal correlation for '{i}' must be 1.00, found {diag_val}."
            )

        for j in sleeves:
            if j not in correlations[i]:
                raise ValueError(
                    f"Input Error: Missing correlation entry between '{i}' and '{j}'."
                )

            val_ij = correlations[i][j]

            # Rule 1: Bounded between -1 and 1
            if val_ij < -1.0 - tol or val_ij > 1.0 + tol:
                raise ValueError(
                    f"Validation Refusal: Correlation between '{i}' and '{j}' is {val_ij}, "
                    f"which violates the mathematical boundary [-1.0, 1.0]."
                )

            # Rule 2: Symmetric matrix
            val_ji = correlations[j].get(i, None)
            if val_ji is None or abs(val_ij - val_ji) > tol:
                raise ValueError(
                    f"Validation Refusal: Correlation table is asymmetric between '{i}' and '{j}'. "
                    f"Corr('{i}', '{j}') = {val_ij} but Corr('{j}', '{i}') = {val_ji}."
                )

    return True


# ==============================================================================
# COMPUTATION ENGINE FUNCTIONS
# ==============================================================================

def build_covariance_matrix(sleeves, volatilities, correlations):
    """
    Builds the covariance matrix as:
        Cov(i, j) = Correlation(i, j) * Volatility(i) * Volatility(j)

    Returns a 2D nested dictionary where cov[i][j] is the covariance between sleeve i and sleeve j.
    Units: (% squared)
    """
    cov_matrix = {}
    for i in sleeves:
        cov_matrix[i] = {}
        for j in sleeves:
            cov_matrix[i][j] = correlations[i][j] * volatilities[i] * volatilities[j]
    return cov_matrix


def build_benchmark_portfolio(sleeves):
    """
    Benchmark portfolio (Lab 13's S4 policy mix):
    40% Investment-grade bond fund, 60% Global equity index fund.
    """
    weights = {s: 0.0 for s in sleeves}
    weights["Investment-grade bond fund"] = 40.0
    weights["Global equity index fund"] = 60.0
    return weights


def build_equal_weight_portfolio(sleeves):
    """
    Equal-weight portfolio:
    Each sleeve receives 1 / N of the total portfolio (25.0% each for N=4).
    """
    n = len(sleeves)
    w = 100.0 / n if n > 0 else 0.0
    return {s: w for s in sleeves}


def build_inverse_volatility_portfolio(sleeves, volatilities):
    """
    Inverse-volatility risk parity portfolio:
    Each weight is proportional to 1 / volatility_i, normalized to sum to 100.0%.
    """
    raw_weights = {}
    for s in sleeves:
        vol = volatilities[s]
        if vol <= 0:
            raise ValueError(f"Volatility for sleeve '{s}' must be strictly positive, found {vol}.")
        raw_weights[s] = 1.0 / vol

    total_inverse = sum(raw_weights.values())
    return {s: (raw_weights[s] / total_inverse) * 100.0 for s in sleeves}


def compute_portfolio_return(weights, expected_returns):
    """
    Computes expected portfolio return as:
        E[R_p] = sum( (w_i / 100) * E[R_i] )
    Units: %
    """
    return sum((weights[s] / 100.0) * expected_returns[s] for s in weights)


def compute_portfolio_variance(weights, cov_matrix, sleeves):
    """
    Computes portfolio variance as:
        Var(R_p) = sum_i sum_j (w_i / 100) * (w_j / 100) * Cov(i, j)
    Units: (% squared)
    """
    variance = 0.0
    for i in sleeves:
        w_i = weights[i] / 100.0
        for j in sleeves:
            w_j = weights[j] / 100.0
            variance += w_i * w_j * cov_matrix[i][j]
    return variance


def compute_portfolio_volatility(weights, cov_matrix, sleeves):
    """
    Computes portfolio volatility (standard deviation) as:
        Vol(R_p) = sqrt(Var(R_p))
    Units: %
    """
    var = compute_portfolio_variance(weights, cov_matrix, sleeves)
    # Guard against tiny negative floating-point epsilon
    if var < 0.0 and var > -1e-12:
        var = 0.0
    return math.sqrt(var)


def compute_reserve_eligible_weight(weights, reserve_sleeves):
    """
    Computes total allocation to reserve-eligible sleeves (Bills + 10-year note).
    Units: %
    """
    return sum(weights[s] for s in reserve_sleeves if s in weights)


def evaluate_portfolio(name, weights, sleeves, expected_returns, cov_matrix, reserve_sleeves, objective):
    """
    Evaluates complete metrics for a given portfolio weighting.
    """
    exp_return = compute_portfolio_return(weights, expected_returns)
    volatility = compute_portfolio_volatility(weights, cov_matrix, sleeves)
    reserve_weight = compute_reserve_eligible_weight(weights, reserve_sleeves)
    meets_obj = exp_return >= objective

    return {
        "name": name,
        "weights": weights,
        "expected_return": exp_return,
        "volatility": volatility,
        "reserve_weight": reserve_weight,
        "meets_objective": meets_obj,
    }


# ==============================================================================
# MAIN EXECUTION & REPORTING
# ==============================================================================

def main():
    # 1. Validate inputs before executing any computations
    try:
        validate_correlations(SLEEVES, CORRELATIONS)
    except ValueError as err:
        print(f"\n[ENGINE REFUSAL] Cannot run portfolio risk engine:")
        print(f"  {err}\n")
        sys.exit(1)

    # 2. Build Covariance Matrix
    cov_matrix = build_covariance_matrix(SLEEVES, VOLATILITIES, CORRELATIONS)

    # 3. Construct the Three Baseline Portfolios
    benchmark_weights = build_benchmark_portfolio(SLEEVES)
    equal_weights = build_equal_weight_portfolio(SLEEVES)
    inverse_vol_weights = build_inverse_volatility_portfolio(SLEEVES, VOLATILITIES)

    portfolios_to_eval = [
        ("Benchmark", benchmark_weights),
        ("Equal weight", equal_weights),
        ("Inverse volatility", inverse_vol_weights),
    ]

    results = []
    for name, w in portfolios_to_eval:
        res = evaluate_portfolio(
            name=name,
            weights=w,
            sleeves=SLEEVES,
            expected_returns=EXPECTED_RETURNS,
            cov_matrix=cov_matrix,
            reserve_sleeves=RESERVE_ELIGIBLE_SLEEVES,
            objective=OBJECTIVE_RETURN,
        )
        results.append(res)

    # 4. Detailed Portfolio Printout
    print("\n" + "=" * 84)
    print("FIN439 LAB 14 — PORTFOLIO RISK & RETURN BASELINE ENGINE")
    print("=" * 84)
    print(f"Objective Return Threshold : {OBJECTIVE_RETURN:.2f}% (CPI 2.5% + 4.0%)")
    print(f"Reserve-Eligible Sleeves   : {', '.join(sorted(RESERVE_ELIGIBLE_SLEEVES))}\n")

    for res in results:
        w = res["weights"]
        meets_text = "yes" if res["meets_objective"] else "no"
        weights_formatted = " / ".join(f"{w[s]:.1f}" for s in SLEEVES)
        print(f"Portfolio: {res['name']}")
        print(f"  Weights (% to 1 dec)   : {weights_formatted}")
        for s in SLEEVES:
            print(f"    - {s:<28}: {w[s]:5.1f}%")
        print(f"  Expected Return (% p.a): {res['expected_return']:6.2f}%")
        print(f"  Volatility (% p.a)     : {res['volatility']:6.2f}%")
        print(f"  Reserve-Eligible Weight: {res['reserve_weight']:6.1f}%")
        print(f"  Meets {OBJECTIVE_RETURN:.1f}% Objective? : {meets_text}")
        print()

    # 5. Section V Rubric Known-Answer Verification Matrix
    print("=" * 96)
    print("SECTION V — VERIFICATION MATRIX (KNOWN ANSWER BENCHMARK)")
    print("=" * 96)
    header = f"{'Portfolio':<20} {'Weights: bills / 10-year / IG / equity':<42} {'Return':>7} {'Volatility':>11} {'Reserve-eligible':>18} {'Meets 6.5%?':>13}"
    print(header)
    print("-" * 96)

    for res in results:
        w = res["weights"]
        w_str = f"{w['Treasury bills']:.1f} / {w['Treasury 10-year note']:.1f} / {w['Investment-grade bond fund']:.1f} / {w['Global equity index fund']:.1f}"
        meets_str = "yes" if res["meets_objective"] else "no"
        row = f"{res['name']:<20} {w_str:<42} {res['expected_return']:>7.2f} {res['volatility']:>11.2f} {res['reserve_weight']:>18.1f} {meets_str:>13}"
        print(row)

    print("=" * 96 + "\n")


if __name__ == "__main__":
    main()

