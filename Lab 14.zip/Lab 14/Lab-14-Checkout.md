# Lab 14 — Tuesday Completion Checkout: Portfolio Baselines & Risk Engine
**Course:** FIN439 — Corporate Valuation & Investment Policy Analysis  
**Category:** Tuesday Completion Checkout (25 or 0)  
**File Created:** [`portfolio.py`](file:///Users/devankmahajan/.gemini/antigravity/scratch/FIN439/portfolio.py)  
**Updated Mandate Checker:** [`mandate.py`](file:///Users/devankmahajan/.gemini/antigravity/scratch/FIN439/mandate.py) (Added Candidate E)  

---

## D — The Question

> **"What does each simple portfolio earn and risk — and does any of them meet the Meridian mandate?"**

### Executive Verdict & Answer
| Portfolio | Expected Return | Volatility | Meets Return Objective ($\ge 6.5\%$)? | Reserve-Eligible Weight | Meets Meridian Mandate ($\ge 3.0\%$)? |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Benchmark (60/40)** | **6.80%** | **10.46%** | **Yes** (6.80% $\ge$ 6.50%) | **0.0%** | **FAILS** (0.0% vs. 3.0% required) |
| **Equal Weight (25/25/25/25)** | **5.20%** | **5.21%** | **No** (5.20% < 6.50%) | **50.0%** | **Passes** reserve constraint, but misses return objective |
| **Inverse Volatility (84.3/6.0/7.0/2.6)** | **3.77%** | **1.05%** | **No** (3.77% < 6.50%) | **90.3%** | **Passes** reserve constraint, but severely misses return |

**Core Conclusion:**
**None of the three simple baselines satisfies the complete Meridian mandate and objective simultaneously:**
1. **The Policy Benchmark (Candidate E)** meets the $6.5\%$ return objective ($6.80\%$), but **fails the Meridian Reserve Mandate entirely** ($0.0\%$ reserve-eligible assets vs. $3.0\%$ required). The client's own stated benchmark violates the client's own investment policy rule!
2. **The Equal Weight and Inverse Volatility Portfolios** easily satisfy the structural reserve liquidity floor ($50.0\%$ and $90.3\%$, respectively), but **fail to earn the required CPI + 4% real return target** ($5.20\%$ and $3.77\%$ vs. $6.50\%$).

---

## Diversification Mechanics: Hand-Proof of the 10.46 Volatility

### The Five-Minute Partner Explanation: Why Two Risky Assets Together Are Less Risky Than Either Alone
Consider the **Benchmark Portfolio**: 
- Asset 1: Investment-Grade Bond Fund ($w_1 = 40\% = 0.40$, $\sigma_1 = 6.0\%$)
- Asset 2: Global Equity Index Fund ($w_2 = 60\% = 0.60$, $\sigma_2 = 16.0\%$)
- Correlation: $\rho_{12} = 0.25$

#### 1. The Weighted Average Volatility (No Diversification)
If the two assets were perfectly correlated ($\rho_{12} = 1.0$), the portfolio volatility would be the simple linear weighted average:
$$\sigma_{\text{linear}} = w_1 \sigma_1 + w_2 \sigma_2 = (0.40 \times 6.0\%) + (0.60 \times 16.0\%) = 2.40\% + 9.60\% = 12.00\%$$

#### 2. The Markowitz Portfolio Variance Formula
Because $\rho_{12} = 0.25 < 1.0$, the diversification benefit dampens total variance:
$$\sigma_p^2 = w_1^2 \sigma_1^2 + w_2^2 \sigma_2^2 + 2 w_1 w_2 \operatorname{Cov}(1, 2)$$
Where $\operatorname{Cov}(1, 2) = \rho_{12} \times \sigma_1 \times \sigma_2 = 0.25 \times 6.0 \times 16.0 = 24.0$

Step-by-step arithmetic:
1. **Bond Variance Term:** $w_1^2 \sigma_1^2 = (0.40)^2 \times 6.0^2 = 0.16 \times 36 = 5.76$
2. **Equity Variance Term:** $w_2^2 \sigma_2^2 = (0.60)^2 \times 16.0^2 = 0.36 \times 256 = 92.16$
3. **Cross-Asset Covariance Term:** $2 w_1 w_2 \operatorname{Cov}(1, 2) = 2 \times 0.40 \times 0.60 \times 24.0 = 0.48 \times 24.0 = 11.52$
4. **Total Variance:** $\sigma_p^2 = 5.76 + 92.16 + 11.52 = 109.44$
5. **Portfolio Volatility:** $\sigma_p = \sqrt{109.44} = \mathbf{10.46\%}$

#### 3. Why Diversification Creates Free Lunch
Notice that:
$$\sigma_p = 10.46\% < \sigma_{\text{linear}} = 12.00\% < \sigma_{\text{equity}} = 16.00\%$$
Because the two assets do not move in perfect lockstep ($\rho_{12} = 0.25$), on days when equities decline, bonds often hold value or decline less, canceling out extreme tail events. This eliminates **1.54% of annualized volatility (from 12.00% to 10.46%)** without giving up a single basis point of expected return.

> **The Classic Student Error:** Ignoring the cross-covariance term ($2 w_1 w_2 \operatorname{Cov}$) calculates $\sqrt{5.76 + 92.16} = \sqrt{97.92} = 9.90\%$. When the positive correlation ($0.25$) is properly included, volatility expands from $9.90\%$ to $10.46\%$.

---

## V — Verification Matrix (Proven on Known Answers)

```
================================================================================================
SECTION V — VERIFICATION MATRIX (KNOWN ANSWER BENCHMARK)
================================================================================================
Portfolio            Weights: bills / 10-year / IG / equity      Return  Volatility   Reserve-eligible   Meets 6.5%?
------------------------------------------------------------------------------------------------
Benchmark            0.0 / 0.0 / 40.0 / 60.0                       6.80       10.46                0.0           yes
Equal weight         25.0 / 25.0 / 25.0 / 25.0                     5.20        5.21               50.0            no
Inverse volatility   84.3 / 6.0 / 7.0 / 2.6                        3.77        1.05               90.3            no
================================================================================================
```

### Proving the Engine Computes Dynamically
1. **Correlation Sensitivity Check:**
   - Setting $\rho(\text{IG Bonds, Equity}) = 0.50$ (symmetric in both cells) raises Benchmark volatility from **10.46% to 11.00%**:
     $$\sigma_p^2 = 5.76 + 92.16 + 2 \times 0.40 \times 0.60 \times (0.50 \times 6.0 \times 16.0) = 97.92 + 23.04 = 120.96$$
     $$\sigma_p = \sqrt{120.96} = 11.00\%$$
2. **Integrity Refusal Check:**
   - Setting $\rho = 1.3$ raises `ValueError: Validation Refusal: Correlation between 'Investment-grade bond fund' and 'Global equity index fund' is 1.3, which violates the mathematical boundary [-1.0, 1.0].`
   - Setting asymmetric values (e.g. 0.15 vs 0.10) raises `ValueError: Validation Refusal: Correlation table is asymmetric between 'Treasury bills' and 'Treasury 10-year note'.`
3. **Mandate Checker Integration (`mandate.py` Candidate E):**
   - Running `python mandate.py` with Candidate E (40% IG Bonds, 60% Equity Fund) yields:
     ```
     Candidate E:
       Weights sum to 100: 100.0 pass
       Long-only (lowest weight): 0.0 pass
       Reserve ≥ 3.0%: 0.0 FAIL
       Redeemable in 5 days ≥ 90%: 100.0 pass
       Largest single company ≤ 8%: 0.0 pass
       Calendar-year loss: requires CIO clarification
       Verdict: fails 1 rule(s)
     ```
   - **Conclusion:** The client's policy benchmark breaks the client's own reserve mandate.

---

## Line-by-Line Code Explanation: Double-Loop Volatility Engine

```python
def compute_portfolio_variance(weights, cov_matrix, sleeves):
    variance = 0.0
    for i in sleeves:
        w_i = weights[i] / 100.0
        for j in sleeves:
            w_j = weights[j] / 100.0
            variance += w_i * w_j * cov_matrix[i][j]
    return variance
```

### Line-by-Line Breakdown:
1. `variance = 0.0`: Initializes the accumulator for total portfolio variance ($\sigma_p^2$).
2. `for i in sleeves:`: Loops through each asset $i$ in the asset menu (outer loop).
3. `w_i = weights[i] / 100.0`: Converts the percentage weight of asset $i$ to a decimal fraction ($40\% \rightarrow 0.40$).
4. `for j in sleeves:`: Loops through every asset $j$ in the asset menu (inner loop).
5. `w_j = weights[j] / 100.0`: Converts the percentage weight of asset $j$ to a decimal fraction ($60\% \rightarrow 0.60$).
6. `variance += w_i * w_j * cov_matrix[i][j]`: Multiplies the two portfolio weights by their pairwise covariance $\operatorname{Cov}(i, j) = \rho_{ij} \sigma_i \sigma_j$ and accumulates the term.
   - When $i == j$, this evaluates to $w_i^2 \sigma_i^2$ (the individual asset variance).
   - When $i \ne j$, this evaluates to $w_i w_j \operatorname{Cov}(i, j)$. Because the double loop visits both $(i, j)$ and $(j, i)$, the two identical off-diagonal terms automatically add together to produce $2 w_i w_j \operatorname{Cov}(i, j)$.

