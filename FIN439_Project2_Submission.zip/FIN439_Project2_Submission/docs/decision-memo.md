# Investment Committee Decision Memorandum: Project 2
**Target Portfolio:** Meridian Foundation Reserve Fund ($100.0M AUM)  
**Security Sleeves:** U.S. Treasury Bills, 10-Year Treasury Notes, Investment-Grade Corporate Bonds, Global Equities  
**Reference / As-Of Date:** November 17, 2026 | **Governance Framework:** Meridian Foundation Reserve Mandate (Lab 13)  
**Author:** Devank Mahajan, Portfolio Analyst | Daniels School of Business, Purdue University  

---

### Mandatory Opening Statements (Rubric Base Requirement 8)
1. **AI Disclosure Statement:** Generative AI tools (Antigravity / Gemini 3.8 Flash (High) and Claude 3.5 Sonnet) were utilized for drafting assistance, interface scaffolding, and documentation styling. All quantitative portfolio calculations, Markowitz covariance formulations, mandate evaluation logic, stress test models, and investment recommendations were independently authored, audited, and verified by Devank Mahajan.
2. **Fiduciary & Educational Disclaimer:** The analysis, evaluations, and investment decisions contained herein are solely the author's work for academic evaluation in FIN 43900 at Purdue University; strictly for educational purposes, not investment advice.

---

## 1. Executive Action Line & Committee Ask
> **"Rebalance from the non-compliant 60/40 policy benchmark to the 0/20/25/55 Meridian Defensive Allocation (0% T-bills, 20% 10-Year Treasury, 25% IG Bonds, 55% Global Equities; E[R]=6.51%, Vol=9.44%), with the condition that we reject this allocation and hold 100% short-term Treasury bills if trailing 12-month CPI inflation exceeds 3.5% (pushing the real return hurdle above 7.5%, where no long-only mix satisfies the reserve mandate)."**

- **Intended User:** Meridian Foundation Investment Committee & Chief Investment Officer (CIO).
- **Recommended Action:** Rebalance the $100.0M reserve pool from the non-compliant 60/40 benchmark to the constrained minimum-volatility 0/20/25/55 allocation.
- **Horizon & Constraints:** 7-year strategic horizon with annual rebalancing (Rule S1); long-only (no leverage or shorting, Rule S5); annual turnover <= 25% (Rule S7); 5-day liquid share >= 90% (Rule S8); single corporate issuer cap <= 8.0% (Rule S6).
- **Edition A/B Boundary:** In Edition A, the analyst qualitatively evaluated the reserve fund and presumed the board-designated 60/40 benchmark was compliant. In Edition B, quantitative translation of IPS rules in `mandate.py` proved the benchmark breaches Rule S3, leading to the Markowitz constrained optimization that constructed the 0/20/25/55 solution.
- **Committee Ask:** Adopt the 0/20/25/55 target policy allocation, approve the defensible operating ranges, and authorize continuous surveillance of our four macroeconomic reversal triggers.

---

## 2. Core Mandate Discrepancy & Baseline Evaluations

### The Policy Benchmark Dilemma
The Foundation historically designated a conventional **60/40 Policy Benchmark** (40% Investment-Grade Bonds, 60% Global Equities; Candidate E). When evaluated against the Foundation's own Investment Policy Statement (IPS), **this benchmark breaches the Foundation's legal mandate**:
- **Return Objective (Rule S2):** Earns **6.80%**, clearing the CPI (2.50%) + 4.00% = **6.50%** real return hurdle.
- **Reserve Liquidity Rule (Rule S3):** Holds **0.0%** in sovereign reserve instruments (Cash, T-bills, or 10-Year Treasuries), violating the **3.0% minimum liquidity reserve** required to fund four quarters of distributions (4 * $0.75M / $100M = 3.0%). Investment-grade corporate bonds represent credit exposure and are non-exempt under mandate governance.
- **Mandate Verdict:** **`FAILS 1 RULE (Rule S3 Reserve Breach: 0.0% < 3.0%)`**. The client's policy benchmark violates the client's own legal rules.

### Mandate Verdict Comparison: Baselines vs. Constrained Portfolio
| Portfolio Candidate | Allocation (Bills / 10-Yr / IG / Equity) | Expected Return (% p.a.) | Annualized Volatility (% p.a.) | Reserve Weight (%) | Mandate Compliance Verdict |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **Baseline 1: Equal Weight** | `25.0 / 25.0 / 25.0 / 25.0` | **5.20%** | **5.21%** | **50.0%** | **FAILS** (Return hurdle missed: 5.20% < 6.50%) |
| **Baseline 2: 60/40 Benchmark** | `0.0 / 0.0 / 40.0 / 60.0` | **6.80%** | **10.46%** | **0.0%** | **FAILS 1 RULE** (Rule S3 breach: 0.0% < 3.0%) |
| **Alternative: Inverse Vol Parity**| `84.3 / 6.0 / 7.0 / 2.6` | **3.77%** | **1.05%** | **90.3%** | **FAILS** (Return hurdle missed: 3.77% < 6.50%) |
| **Meridian Defensive (Optimal)** | `0.0 / 20.0 / 25.0 / 55.0` | **6.51%** | **9.44%** | **20.0%** | **PASSES EVERY CHECKABLE RULE (5/5)** |

---

## 3. The Recommended Decision Portfolio: Meridian Defensive (0/20/25/55)

The constrained minimum-volatility optimization engine solves for the unique long-only allocation on the 4-simplex that satisfies both the return hurdle ($\ge 6.50\%$) and the liquidity floor ($\ge 3.0\%$) with lowest portfolio variance:
- **U.S. Treasury Bills:** **0.0%** ($0.0M)
- **U.S. Treasury 10-Year Notes:** **20.0%** ($20.0M)
- **Investment-Grade Corporate Bond Fund:** **25.0%** ($25.0M)
- **Global Equity Index Fund:** **55.0%** ($55.0M)

### Financial Bridge & Risk-Reduction Rationale
1. **Return Hurdle Clearance:** Delivers an expected return of **6.51%**, clearing the 6.50% objective hurdle with a +1 basis point buffer.
2. **Superior Risk-Reduction:** Achieves an annualized volatility of **9.44%**, saving **102 basis points of risk (-9.8% volatility reduction)** compared to the 60/40 benchmark (10.46%).
3. **Robust Liquidity Cushion:** Allocates **20.0% ($20.0M)** to sovereign paper—providing a **6.67x coverage cushion** over the 3.0% statutory floor, capable of funding 26 quarters of distributions without forced liquidations.
4. **The Critical Sovereign Diversifier:** Incorporating 10-Year Treasuries is mathematically essential: because 10-Year Treasuries carry a **negative correlation to global equities (correlation: -0.10)**, they provide a flight-to-safety shock absorber during equity downturns while legally qualifying as reserve-eligible sovereign debt.

### Defensible Policy Allocation Ranges & Trade Execution Ticket ($100M AUM)
To execute the transition from the 60/40 benchmark to Meridian Defensive without violating the 25.0% annual turnover cap (Rule S7), the committee approves the following actionable orders:

| Asset Sleeve | Current Benchmark ($M / %) | Target Policy ($M / %) | Permissible Policy Range | Execution Order ($M) | Governance Purpose |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **Treasury bills** | $0.0M (0.0%) | **$0.0M (0.0%)** | 0.0% – 5.0% | **HOLD $0.0M** | Cash sweep & rebalancing liquidity buffer. |
| **Treasury 10-year note** | $0.0M (0.0%) | **$20.0M (20.0%)** | 15.0% – 25.0% | **BUY +$20.0M** | Cures Rule S3 reserve breach; equity hedge (correlation: -0.10). |
| **Investment-grade bonds**| $40.0M (40.0%)| **$25.0M (25.0%)** | 20.0% – 30.0% | **SELL -$15.0M** | Reallocate corporate credit into sovereign paper. |
| **Global equity index fund**| $60.0M (60.0%)| **$55.0M (55.0%)** | 50.0% – 58.0% | **SELL -$5.0M** | Trim equity to curb portfolio variance (cap at 58%). |
| **TOTALS** | **$100.0M (100%)** | **$100.0M (100%)** | — | **$40.0M Gross Volume** | **Turnover = 20.0% ≤ 25.0% (PASSES RULE S7)** |

- **Rule S7 Turnover Audit:** One-way turnover is 0.5 * ($0M + $20M + $15M + $5M) / $100M = **20.0% <= 25.0%**, fully compliant with the Investment Policy Statement without requiring a board exception.
- **Distribution Payout Coverage:** The $20.0M sovereign allocation guarantees **26.7 consecutive quarters (6.7 years)** of the Foundation's $0.75M quarterly payouts without forced asset liquidations during market drawdowns.

---

## 4. Point-in-Time Macroeconomic Signal: T10Y2Y

To ensure our investment process is anchored in verified historical information, we integrate the **10-Year Minus 2-Year Treasury Yield Spread (`T10Y2Y`)** retrieved from Federal Reserve ALFRED point-in-time archives:
- **As-Of Vintage Value:** **+0.46% (46 basis points)** as of October 2026.
- **Data Integrity:** Reports with a **T+1 business day lag** and undergoes **0 historical revisions**, representing immutable secondary market transactions.
- **Fiduciary Policy Role:** A positive slope (+46 bps) confirms expansionary/normal monetary transmission, validating our 55% strategic equity allocation. An inverted curve (below 0.00%) serves as an active early-warning trigger to compress equity exposure to our 50% policy floor.

---

## 5. Stress Testing & The Condition That Stops the Process

### Four-Dimensional Sensitivity Analysis
1. **Estimates Shock (Equity Return 8.0% -> 7.0%):** 
   When equity expected return is shocked by -100 bps, the optimizer shifts weights to `0 / 10 / 10 / 80`. Global Equities surge by **+25.0 percentage points** and volatility spikes from **9.44% to 12.94% (+3.50 percentage points / +37.1% risk surge)**. While this mix technically passes the 3.0% reserve rule, **the committee rejects it** because 12.94% volatility exceeds institutional risk tolerances.
2. **Window / History Shock (`prices.csv`):** 
   Slicing price history to the trailing 36 months (2022–2024 Fed rate hike regime) generates negative fixed-income returns, forcing the empirical optimizer to reallocate 30 percentage points into equities (`SPY` 35% -> 65%) and increasing risk by +3.97 percentage points.
3. **Cost Drag Shock (+25 bps & +50 bps):** 
   Adding 25 to 50 bps of management fees ratchets the nominal hurdle up to 6.75%–7.00%, compressing the feasible simplex space from 218 mixes down to 28 mixes.
4. **Constraint Shock:** 
   Raising the reserve requirement to 6.8% (18 months of coverage) leaves the 0/20/25/55 mix unchanged, as our 20.0% allocation provides ample headroom.
5. **Downside Loss Risk & Rule S9 Resolution:**
   Addressing CIO Statement S9 (*"The reserve cannot have a calendar-year loss greater than 10%"*), our quantitative modeling proves that rebalancing from the 60/40 benchmark to Meridian Defensive reduces the probability of a greater than 10% single-year loss from **5.4% down to 4.0% (a 26% tail-risk reduction)**. Under the stressed 80% equity allocation, this risk jumps to **10.1%**, reinforcing the committee's decision to reject the stressed mix.

### 🛑 The Formal Condition That Stops the Process
- **The Trigger:** **Trailing 12-month CPI inflation exceeds 3.5% (pushing the hurdle CPI + 4.0% > 7.50%).**
- **The Economic Breakdown:** Treasury bills yield 3.5%, 10-year Treasuries yield 4.3%, and corporate bonds yield 5.0%. When the required return exceeds 7.50%, **no long-only multi-asset allocation can clear the hurdle without allocating greater than 75% to equities and pushing volatility above 12.5%**.
- **The Remediation Action:** The algorithm **HALTS AND STOPS THE PROCESS**. The committee refuses to adopt an excessively risky equity portfolio. The fund immediately transitions into a **100% short-term Treasury bill (`BIL`) capital preservation posture**, and the CIO requests an institutional spending waiver from the Board of Trustees until CPI inflation normalizes below 3.5%.

---

## 6. Committee Monitoring Triggers & Governance Plan

The portfolio analyst will monitor four observable operational triggers on a monthly surveillance schedule:
1. **Inflation Hurdle Trigger (Trailing 12M CPI > 3.5%):** Halts the optimization process and shifts the fund to 100% T-bills.
2. **Yield Curve Inversion Trigger (T10Y2Y < 0.00%):** Prompts the committee to compress equity exposure from 55% down to the 50% policy floor.
3. **Volatility Drift Trigger (Rolling 12M Realized Volatility > 11.0%):** Triggers an immediate risk re-budgeting review and rebalancing sweep into 10-Year Treasuries.
4. **Liquidity Rule Trigger (5-Day Liquid Share < 90.0%):** Any redemption delay beyond 5 business days triggers immediate liquidation under Rule S8.

**Final Recommendation:** Rebalance $100.0M into the 0/20/25/55 Meridian Defensive Allocation today, establish monthly surveillance of our four triggers, and enforce the 3.5% CPI process-stopping condition.
