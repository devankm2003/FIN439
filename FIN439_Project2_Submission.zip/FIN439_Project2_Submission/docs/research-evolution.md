# Research Evolution: Microsoft Corporation (NASDAQ: MSFT)
FIN 43900 - Corporate Valuation & Financial Modeling
Student Role: Buy-Side Equity Research Analyst
Intended User: Buy-Side Investment Committee (Fund holds no current position)
Valuation Date: September 23, 2026 (Market Close: $500.59)
Primary Filing: Form 10-K for Fiscal Year Ended June 30, 2025 (SEC Accession: 0000950170-25-100235)

================================================================================
SECTION 1. EDITION A - UNCHANGED BRIGHTSPACE BASELINE
================================================================================

Brightspace Checkpoint Verification:
- Assignment Object: Project 1 - Edition A Checkpoint (AI Closed)
- Brightspace Receipt Identifier: FIN439-FA26-P1-EA-083125-992174
- Submission Timestamp: August 31, 2025, 23:14:08 EDT
- Student Attestation: I authored this baseline during the supervised, AI-closed window prior to any project-specific generative-AI research, prompting, or coding assistance.

1. Decision and Intended User
I am advising a buy-side investment committee whose fund currently holds zero position in Microsoft Corporation. The question before the committee is whether to begin fundamental diligence to initiate an equity position, place the stock on watch, or reject the name.

2. Company and Security
- Entity: Microsoft Corporation
- Ticker: MSFT (NASDAQ)
- Valuation Date: August 31, 2025
- Valuation Target: Enterprise value, bridged to common equity value and value per diluted common share.

3. Initial Thesis: Watch / Defer
My initial thesis is to watch and defer an initiation decision. Microsoft is clearly a premier enterprise software and cloud business, but management has been ramping capital expenditures at an unprecedented pace. CapEx accelerated past $44 billion in FY2024 and is approaching $65 billion. Management noted in MD&A that scaling AI datacenter capacity is putting downward pressure on cloud gross margins. Until I build a linked financial model to test whether cloud revenues can generate an adequate return on this new capital, buying at current multiples seems premature.

4. Known Evidence from the Audited Form 10-K (June 30, 2025)
All dollar amounts are in U.S. dollars in millions, from Form 10-K accession 0000950170-25-100235.

- Cash and cash equivalents: $30,242M at June 30, 2025 (Item 8 Balance Sheet, p. 61).
- Short-term investments: $64,323M at June 30, 2025 (Item 8 Balance Sheet, p. 61).
- Total reported liquidity: $94,565M (Cash plus short-term investments).
- Total debt carrying value: $43,151M ($2,999M current portion plus $40,152M long-term debt, Item 8 p. 61 and Note 10 p. 82).
- Diluted common shares: 7,465.0 million weighted-average shares (7,433M basic plus 32M dilutive stock awards, Note 18 p. 94). The cover page reports 7,434M actual shares outstanding.
- Operating revenue driver: Microsoft Cloud revenue was $168.9 billion in FY2025, up 23% year-over-year. Azure and other cloud services grew 34% (Item 7 MD&A, p. 33). Total revenue reached $281,724 million, up 15% year-over-year.

5. Synthetic Enterprise-to-Equity Bridge Check (Class Known Answer)
To confirm my understanding of the bridge mathematics, I reconciled the class synthetic test fixture:
Equity Value = $1,000 EV + $100 Cash - $250 Debt - $20 Minority Interest - $10 Unfunded Pension = $820.0M
Per-Share Value = $820.0M / 100 diluted shares = $8.20 per share.
This synthetic check proves the arithmetic of claims. For Microsoft, my bridge will need to determine how much cash is required for daily operations, how to treat operating leases under ASC 842, and whether other claims exist.

6. Consequential Assumptions
- Microsoft Cloud and Azure revenue growth can be modeled from the FY2025 baseline, but recurring demand must be separated from one-time capacity expansion.
- A substantial portion of the $94.6 billion in cash and short-term investments may represent non-operating value, subject to an operating cash requirement analysis.
- The diluted share count of 7,465.0 million is the correct denominator for per-share DCF equity value.
- Operating leases and debt-like claims must be handled consistently between the operating forecast and the balance sheet bridge.

7. Unknowns and Reversal Conditions
- I do not yet know whether Microsoft's heavy AI infrastructure spending will earn returns above WACC or permanently compress gross margins.
- I do not know how much cash is operationally restricted.
- I need to determine the contemporaneous market price, WACC, forecast horizon, terminal growth rate, and resulting valuation range.
- The watch/defer stance would turn into a do-not-initiate recommendation if the pro-forma shows CapEx permanently depressing free cash conversion. It would become a buy recommendation only if a conservative DCF range offers a clear margin of safety below the market price.

8. Initial Research Plan
- Build a five-year three-statement pro-forma model using audited FY2025 financial statements as the base year.
- Forecast revenue, gross margin, operating expenses, CapEx, and working capital under base, bear, and bull cases.
- Derive FCFF, estimate WACC, set an anchored terminal growth rate, and build a complete enterprise-to-equity bridge.
- Screen comparable companies using an explicit peer policy, calculate valuation multiples, and compare the results with the DCF.
- Formulate explicit reversal triggers and monitoring metrics for the investment committee.

================================================================================
SECTION 2. DATED CORRECTION ADDENDUM (SEPTEMBER 10, 2026)
================================================================================

Date Discovered and Filed: September 10, 2026
Context: During Week 3 when building the valuation engine, two balance sheet refinements were necessary:

1. Operational Cash Floor: In Edition A, I treated all $94,565 million of cash and short-term investments as potential non-operating liquidity. After reviewing Microsoft's operating expenses (roughly $61 billion in annual cash OpEx and $88 billion in cost of revenue), Microsoft requires an operating liquidity buffer. I established an operational cash floor of $15,000 million (approximately 20 days of cash operating costs). The remaining $79,565 million represents true excess liquidity available to equity holders.
2. Operating Lease Liabilities: In Note 8 of the Form 10-K (p. 79), Microsoft reports $18,485 million in operating lease liabilities under ASC 842. Because the amortization of right-of-use lease assets is already included inside operating expenses, these lease obligations are senior debt-like claims that must be deducted in the enterprise-to-equity bridge to avoid double-counting asset value.

================================================================================
SECTION 3. EDITION B - POST-RESEARCH & DISCLOSED AI VALUATION SYSTEM
================================================================================

Current Decision and Intended User:
- Client / Audience: Buy-Side Investment Committee (Fund holds zero position).
- Security: Microsoft Corporation (NASDAQ: MSFT), Common Equity.
- Valuation Date: September 23, 2026.
- Market Price: $500.59 per share.
- Recommendation: WATCH / DEFER.
- Intrinsic DCF Value (FCFF Base): $316.63 per share (Corner Range: $246.49 to $448.76).
- Pro-Forma FCFE Value (Base): $303.85 per share (OAT Range: $255.77 to $365.92).
- Relative Valuation (Peer Median P/E 39.91x): $544.48 per share (Range: $480.71 to $560.56).
- Reverse DCF at $500.59: Requires 21.6% compound organic revenue growth through 2030 (+8.60 percentage points above base).

A-to-B Evidence Table:

Item: Thesis and Recommendation
Edition A: Watch / Defer based on qualitative concern over accelerating CapEx and margin drag.
Edition B: Watch / Defer retained, but grounded in a quantitative model proving the market trades at a 58.1% premium to intrinsic cash value ($316.63 DCF vs $500.59 market).
Primary Driver of Change: Own analysis and financial model execution.
Justifying Evidence / Test: Five-year pro-forma proves that at $500.59, the market prices Microsoft on accounting earnings multiples while ignoring the ongoing $65 billion annual cash CapEx burden.

Item: Data and Source Choice
Edition A: Initial review of headline FY2025 10-K liquidity, total debt, and cloud revenue disclosures.
Edition B: Full three-statement integration from FY2025 Form 10-K, including Note 8 operating leases ($18,485M), Note 7 PP&E depreciation schedules (10.7335%), and Note 18 diluted shares (7,465.0M).
Primary Driver of Change: Course instruction and SEC filing audit.
Justifying Evidence / Test: Incorporating audited balance sheet notes prevented double-counting lease assets and matched depreciation to physical datacenter useful lives.

Item: Assumption and Model Design
Edition A: Conceptual DCF with unmodeled working capital and static terminal growth.
Edition B: Fully linked five-year three-statement pro-forma with company-specific Short-Term Unearned Revenue float engine (22.9143% of revenue) funding CapEx, with zero balance sheet gap across all years.
Primary Driver of Change: Own analysis, model innovation, and partner challenge.
Justifying Evidence / Test: Replaced generic working capital with Microsoft's upfront enterprise software billing model, which generates +$8.4B to +$13.7B in annual positive cash inflows.

Item: Risk, Limitation, and Uncertainty
Edition A: General uncertainty regarding AI monetization and GPU infrastructure costs.
Edition B: Quantified One-at-a-Time sensitivity: Revenue Growth creates a $110.15/sh valuation span versus $23.53/sh for Gross Margin. Reverse DCF proves market price requires 21.6% compound growth through 2030.
Primary Driver of Change: AI assistance in structuring OAT matrix, verified by manual statement trace.
Justifying Evidence / Test: Proved that a 300 bps acceleration in revenue growth adds $58.03/sh, but still leaves intrinsic value ($365.92) far below the prevailing $500.59 market price.

================================================================================
SECTION 4. WHAT CHANGED FROM EDITION A TO EDITION B, AND WHY?
================================================================================

When I look back at my Edition A submission from Week 2, my bottom-line call was Watch / Defer, and in Edition B it remains Watch / Defer. But the nature of that conclusion has changed completely. In Edition A, I had an analyst's intuition: Microsoft was pouring billions into datacenters, and intuition told me that kind of spending had to pinch free cash flow. However, intuition is not investment evidence. Over the last six weeks, through our modeling labs, peer reviews, and careful testing of AI suggestions, I transformed that initial hypothesis into an articulated, five-year financial engine. Here is the story of how my analysis evolved across four major dimensions:

1. From Vague CapEx Worry to the Reality of Physical Asset Depreciation
In Edition A, I saw that cash additions to property and equipment had jumped from $28.1 billion in FY2023 to $44.5 billion in FY2024 and $64.6 billion in FY2025. What I did not understand until I built the pro-forma balance sheet was the structural consequence of that spending. Microsoft's net physical PP&E more than doubled in just twenty-four months, climbing from $95.6 billion to $205.0 billion.
In Week 5, when I linked the PP&E roll-forward schedule to Note 7 of the Form 10-K, I realized that Microsoft's depreciation ratio is roughly 10.73% of opening net PP&E. When you add $65.0 billion in new cash CapEx every year, net PP&E expands past $310 billion by FY2030. That locks in $37.7 billion of non-cash annual depreciation. Microsoft has effectively evolved from an asset-light software platform into a capital-intensive utility for enterprise AI workloads. By discounting those cash flows at a 9.50% WACC, our intrinsic base DCF comes out to $316.63 per share. That proves the current market price of $500.59 is treating Microsoft as if its cash flows were completely unburdened by hardware reinvestment.

2. Discovering Microsoft's Real Financial Engine: Unearned Revenue Float
The single most important modeling breakthrough occurred when I constructed the working capital schedule. In our Week 5 lab, we were given starter templates that used auto dealership working capital lines like floor-plan debt. When I prompted Codex to help set up the balance sheet, it blindly kept that dealership debt structure.
I audited Microsoft's actual 10-K balance sheet and found zero floor-plan debt. Instead, I discovered Microsoft's true financial superpower: Short-Term Unearned Revenue of $64,555 million, representing 22.91% of revenue. Because enterprise customers pay upfront for multi-year Azure and Microsoft 365 subscriptions at 0% interest, every dollar of revenue growth automatically pulls in customer cash before software is even delivered. In our pro-forma, this creates +$8.4 billion to +$13.7 billion in positive working capital cash inflow each year. This customer float internally finances roughly 15% to 20% of Microsoft's $65 billion annual CapEx bill. Without modeling this company-specific engine, any Microsoft valuation would fundamentally misunderstand how the company funds its infrastructure.

3. Reconciling Why Valuation Methods Disagree Instead of Averaging Them
In Edition A, I had not performed any peer multiples analysis. In Week 4, I formulated a strict peer selection policy requiring enterprise commercial cloud infrastructure (IaaS/PaaS) and high-margin recurring SaaS revenues. When I ran the peer comps in Lab 8 across Alphabet, Oracle, and Amazon, the peer median P/E was 39.91x, implying a Microsoft share price of $544.48.
A naive analyst might average the DCF ($316.63) and the comps ($544.48) to produce a blended target around $430. But course instruction taught us that averaging conflicting methods is an analytical failure. The disagreement is the entire message:
P/E multiples look only at accounting net income. They do not penalize Microsoft for spending $65 billion in cash on datacenters and GPU servers. In contrast, our FCFF DCF rigorously subtracts all cash CapEx from free cash flow, exposing the cash drag that accounting net income conceals. The market today trades at $500.59 because it is valuing Microsoft on accounting earnings multiples. Our Reverse DCF demonstrates that to justify $500.59 under an intrinsic cash engine, Microsoft would have to generate 21.6% compound organic revenue growth through 2030—a growth acceleration of +8.60 percentage points over our 13% base that management's own guidance does not support.

4. Auditing and Rejecting AI Suggestions
Throughout this project, AI was a valuable coding assistant, but I never allowed it to own the finance judgment. Two major interventions stand out:
First, as mentioned earlier, when Codex scaffolded the balance sheet, it attempted to force-fit dealership floor-plan debt into Microsoft's liabilities. I rejected that suggestion immediately and replaced it with audited Unearned Revenue float.
Second, when I asked GPT-4o to recommend comparable company peers, it suggested Nvidia (NVDA) and Apple (AAPL). I audited both against my pre-declared Peer Policy and rejected them. Nvidia is a pure-play fabless semiconductor hardware company with 75% gross margins driven by chip shortages, while Apple is a consumer hardware OEM without an enterprise cloud platform. Accepting them would have corrupted the peer multiple. I qualified Alphabet (GOOGL), Oracle (ORCL), and Amazon (AMZN) instead.

5. Partner Challenge from the Learning Labs
During our Week 5 and 6 labs, I paired with my learning partner, who was analyzing McDonald's (MCD). Reviewing McDonald's balance sheet—with its negative stockholders' equity and heavy franchise royalty engine—forced me to think deeply about capital structure. My partner looked at my Microsoft model and asked a sharp question: If Microsoft's AI CapEx has a three-to-five year hardware replacement cycle, won't depreciation catch up to CapEx by 2029 and permanently crush net margins?
That challenge prompted me to build the One-at-a-Time sensitivity analysis in Lab 11. I tested Organic Revenue Growth (10% to 16%) against Gross Margin (66.5% to 70.5%). The test showed that Revenue Growth dominates Gross Margin by 4.68 times ($110.15 per share span versus $23.53 per share). Growth compounds exponentially and pulls in unearned revenue float, which partially offsets the depreciation drag. My partner's fresh-eyes critique directly strengthened the causal explanation in my final memo.

6. Final Stance and Observable Reversal Triggers
My final recommendation to the investment committee remains Watch / Defer. But unlike Edition A's open-ended caution, Edition B provides explicit quantitative triggers:
- Initiate Buy if: Microsoft's share price pulls back below $310.00 (entering our intrinsic DCF base range), OR if subsequent quarterly Form 10-Q filings prove that commercial cloud gross margins expand above 72.0% while annual CapEx growth slows below 15% (confirming that Copilot software adoption is outrunning infrastructure costs).
- Reject / Remove from Watchlist if: Annual CapEx exceeds $75.0 billion while Azure constant-currency growth drops below 15% and gross margins slip below 67.0% (confirming structural return dilution).
The committee should commit zero capital today and direct our task force to audit Microsoft's Q1 FY2027 Form 10-Q when filed in October 2026.
