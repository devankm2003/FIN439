"""
test_project2.py - Comprehensive Test Suite for Project 2
FIN439: Investment Management Application
Author: Devank Mahajan | Daniels School of Business, Purdue University

Verifies all requirements under Rubric Criterion 5 (Validation, Sensitivity, Reproducibility - 75 pts):
1. Input Guard: Correlation Bounds and Symmetry Invariants
2. Core Math: Markowitz Double-Loop Hand-Proof (60/40 Mix = 10.46% Volatility)
3. Mandate Governance: Candidates A, B, C, D, E Rule-by-Rule Compliance
4. Entity Aggregation: Proves Acme Corp stock and bonds combine under entity risk (Rule S6)
5. Simplex Search: 1,771 grid points evaluated; exactly 218 feasible; global minimum variance is 0/20/25/55
6. Optimal Portfolio Mandate Compliance: 0/20/25/55 passes 5/5 checkable rules
7. Locked Changed-Input Test: Equity 8.0% -> 7.0% matches precommitted prediction (+25 pts equity, +3.50% vol)
8. Process Stop Condition: Return hurdle > 7.50% triggers process halt (no long-only mix meets objective)
9. Point-in-Time Signal: T10Y2Y spread (+0.46%), T+1 lag, zero revisions
10. Contract Synchronization: visible_output.json matches decision memo and code outputs
"""

import copy
import json
from pathlib import Path
import unittest

from portfolio import (
    SLEEVES,
    EXPECTED_RETURNS,
    VOLATILITIES,
    CORRELATIONS,
    OBJECTIVE_RETURN,
    RESERVE_ELIGIBLE_SLEEVES,
    validate_correlations,
    build_covariance_matrix,
    compute_portfolio_return,
    compute_portfolio_volatility,
    compute_reserve_eligible_weight,
    build_benchmark_portfolio,
    build_equal_weight_portfolio,
    build_inverse_volatility_portfolio,
    evaluate_portfolio,
    search_lowest_risk_mix,
    generate_weight_mixes,
)
from mandate import (
    CANDIDATES,
    HOLDINGS,
    compute_reserve_minimum,
    evaluate_candidate,
)


class TestProject2Validation(unittest.TestCase):
    """Institutional test suite for Project 2 investment management app."""

    def setUp(self):
        self.cov_matrix = build_covariance_matrix(SLEEVES, VOLATILITIES, CORRELATIONS)
        self.reserve_min = compute_reserve_minimum()

    # --------------------------------------------------------------------------
    # 1. INPUT GUARDS: CORRELATION BOUNDS & SYMMETRY
    # --------------------------------------------------------------------------
    def test_correlation_bounds_and_symmetry(self):
        """Assert valid correlations pass and out-of-bound / asymmetric inputs raise ValueError."""
        # Baseline must pass
        self.assertTrue(validate_correlations(SLEEVES, CORRELATIONS))

        # Test out-of-bounds correlation (> 1.0)
        bad_corr_high = copy.deepcopy(CORRELATIONS)
        bad_corr_high["Treasury bills"]["Treasury 10-year note"] = 1.30
        bad_corr_high["Treasury 10-year note"]["Treasury bills"] = 1.30
        with self.assertRaises(ValueError):
            validate_correlations(SLEEVES, bad_corr_high)

        # Test out-of-bounds correlation (< -1.0)
        bad_corr_low = copy.deepcopy(CORRELATIONS)
        bad_corr_low["Treasury bills"]["Treasury 10-year note"] = -1.05
        bad_corr_low["Treasury 10-year note"]["Treasury bills"] = -1.05
        with self.assertRaises(ValueError):
            validate_correlations(SLEEVES, bad_corr_low)

        # Test asymmetric correlation matrix
        bad_corr_asym = copy.deepcopy(CORRELATIONS)
        bad_corr_asym["Treasury bills"]["Treasury 10-year note"] = 0.20
        bad_corr_asym["Treasury 10-year note"]["Treasury bills"] = 0.10
        with self.assertRaises(ValueError):
            validate_correlations(SLEEVES, bad_corr_asym)

    # --------------------------------------------------------------------------
    # 2. CORE MATH: MARKOWITZ DOUBLE-LOOP HAND-PROOF
    # --------------------------------------------------------------------------
    def test_double_loop_volatility_hand_proof(self):
        """Verify Markowitz formula matches hand proof on 60/40 benchmark to exact 10.46%."""
        bench_w = {"Treasury bills": 0.0, "Treasury 10-year note": 0.0, "Investment-grade bond fund": 40.0, "Global equity index fund": 60.0}
        vol = compute_portfolio_volatility(bench_w, self.cov_matrix, SLEEVES)
        # Hand-calculation: sqrt(0.4^2 * 36 + 0.6^2 * 256 + 2 * 0.4 * 0.6 * 0.25 * 6 * 16) = sqrt(109.44) = 10.461357...
        self.assertAlmostEqual(vol, 10.461357, places=4)
        self.assertEqual(round(vol, 2), 10.46)

    # --------------------------------------------------------------------------
    # 3. MANDATE CHECKS: CANDIDATES A-E KNOWN ANSWERS
    # --------------------------------------------------------------------------
    def test_candidates_a_through_e_mandate_verdicts(self):
        """Verify mandate verdicts match known answers across all course candidates."""
        # Candidate A: Passes every rule
        res_a = evaluate_candidate("A", CANDIDATES["A"], self.reserve_min)
        self.assertEqual(res_a["verdict"], "passes every checkable rule")
        self.assertTrue(res_a["rules"][2][2])  # Reserve pass

        # Candidate B: Fails 3 rules (Reserve, 5-day liquidity, Single issuer)
        res_b = evaluate_candidate("B", CANDIDATES["B"], self.reserve_min)
        self.assertEqual(res_b["verdict"], "fails 3 rule(s)")
        self.assertFalse(res_b["rules"][2][2])  # Reserve fail
        self.assertFalse(res_b["rules"][3][2])  # 5-day liquidity fail
        self.assertFalse(res_b["rules"][4][2])  # Single issuer fail

        # Candidate C: Fails 1 rule (Reserve)
        res_c = evaluate_candidate("C", CANDIDATES["C"], self.reserve_min)
        self.assertEqual(res_c["verdict"], "fails 1 rule(s)")
        self.assertFalse(res_c["rules"][2][2])  # Reserve fail
        self.assertTrue(res_c["rules"][4][2])   # Single issuer pass

        # Candidate D: Attack candidate (3% cash, 97% equity) passes all checkable rules
        res_d = evaluate_candidate("D", CANDIDATES["D"], self.reserve_min)
        self.assertEqual(res_d["verdict"], "passes every checkable rule")

        # Candidate E: Policy benchmark (60/40) fails 1 rule (Reserve = 0.0% < 3.0%)
        res_e = evaluate_candidate("E", CANDIDATES["E"], self.reserve_min)
        self.assertEqual(res_e["verdict"], "fails 1 rule(s)")
        self.assertFalse(res_e["rules"][2][2])  # Reserve fail
        self.assertEqual(res_e["rules"][2][1], 0.0)

    # --------------------------------------------------------------------------
    # 4. ECONOMIC ENTITY RISK AGGREGATION
    # --------------------------------------------------------------------------
    def test_entity_aggregation_logic(self):
        """Verify Acme Corp bonds (5%) and stock (4%) aggregate to 9.0%, failing Rule S6."""
        weights = copy.deepcopy(CANDIDATES["A"])
        weights["Acme Corp bonds"] = 5.0
        weights["Acme Corp stock"] = 4.0
        weights["Cash"] -= 9.0
        res = evaluate_candidate("EntityTest", weights, self.reserve_min)
        max_company_wt = res["rules"][4][1]
        company_pass = res["rules"][4][2]
        self.assertEqual(max_company_wt, 9.0)
        self.assertFalse(company_pass)

    # --------------------------------------------------------------------------
    # 5. SIMPLEX SEARCH SPACE & OPTIMAL PORTFOLIO
    # --------------------------------------------------------------------------
    def test_simplex_search_and_optimal_portfolio(self):
        """Verify grid search evaluates 1,771 mixes and finds 0/20/25/55 as global minimum risk."""
        all_mixes = list(generate_weight_mixes(len(SLEEVES), step=5))
        self.assertEqual(len(all_mixes), 1771, "4 assets in 5% steps must produce exactly 1,771 mixes.")

        optimal_mix = search_lowest_risk_mix(
            sleeves=SLEEVES,
            expected_returns=EXPECTED_RETURNS,
            cov_matrix=self.cov_matrix,
            reserve_sleeves=RESERVE_ELIGIBLE_SLEEVES,
            objective=OBJECTIVE_RETURN,
            min_reserve_weight=self.reserve_min,
            step=5,
        )
        self.assertIsNotNone(optimal_mix)
        self.assertEqual(optimal_mix["weights"]["Treasury bills"], 0.0)
        self.assertEqual(optimal_mix["weights"]["Treasury 10-year note"], 20.0)
        self.assertEqual(optimal_mix["weights"]["Investment-grade bond fund"], 25.0)
        self.assertEqual(optimal_mix["weights"]["Global equity index fund"], 55.0)
        self.assertEqual(round(optimal_mix["expected_return"], 2), 6.51)
        self.assertEqual(round(optimal_mix["volatility"], 2), 9.44)
        self.assertEqual(optimal_mix["reserve_weight"], 20.0)

    # --------------------------------------------------------------------------
    # 6. OPTIMAL MIX MANDATE COMPLIANCE
    # --------------------------------------------------------------------------
    def test_optimal_portfolio_mandate_compliance(self):
        """Verify 0/20/25/55 mix satisfies 5/5 mandate rules with 20.0% reserve-eligible weight."""
        opt_mandate_weights = {
            "Cash": 0.0,
            "Treasury bills": 0.0,
            "Treasury 10-year note": 20.0,
            "Global equity index fund": 55.0,
            "Investment-grade bond fund": 25.0,
            "Private real estate fund": 0.0,
            "Acme Corp bonds": 0.0,
            "Acme Corp stock": 0.0,
        }
        res = evaluate_candidate("OptimalMix", opt_mandate_weights, self.reserve_min)
        self.assertEqual(res["verdict"], "passes every checkable rule")
        self.assertEqual(res["rules"][2][1], 20.0)  # Reserve = 20.0%
        self.assertEqual(res["rules"][3][1], 100.0) # 5-day liquid = 100%
        self.assertEqual(res["rules"][4][1], 0.0)   # Max company = 0.0%

    # --------------------------------------------------------------------------
    # 7. LOCKED CHANGED-INPUT STRESS TEST
    # --------------------------------------------------------------------------
    def test_locked_changed_input_reconciliation(self):
        """Verify equity return 8.0% -> 7.0% reproduces precommitted shift and volatility surge."""
        stress_returns = dict(EXPECTED_RETURNS)
        stress_returns["Global equity index fund"] = 7.0
        stress_mix = search_lowest_risk_mix(
            sleeves=SLEEVES,
            expected_returns=stress_returns,
            cov_matrix=self.cov_matrix,
            reserve_sleeves=RESERVE_ELIGIBLE_SLEEVES,
            objective=OBJECTIVE_RETURN,
            min_reserve_weight=self.reserve_min,
            step=5,
        )
        self.assertIsNotNone(stress_mix)
        self.assertEqual(stress_mix["weights"]["Treasury bills"], 0.0)
        self.assertEqual(stress_mix["weights"]["Treasury 10-year note"], 10.0)
        self.assertEqual(stress_mix["weights"]["Investment-grade bond fund"], 10.0)
        self.assertEqual(stress_mix["weights"]["Global equity index fund"], 80.0)
        self.assertEqual(round(stress_mix["expected_return"], 2), 6.53)
        self.assertEqual(round(stress_mix["volatility"], 2), 12.94)
        self.assertEqual(stress_mix["reserve_weight"], 10.0)

        # Largest weight change: 55% -> 80% = +25.0 points in equity
        delta_equity = stress_mix["weights"]["Global equity index fund"] - 55.0
        self.assertEqual(delta_equity, 25.0)

        # Volatility surge: 9.44% -> 12.94% = +3.50 percentage points
        delta_vol = round(stress_mix["volatility"] - 9.44, 2)
        self.assertEqual(delta_vol, 3.50)

    # --------------------------------------------------------------------------
    # 8. PROCESS STOP CONDITION
    # --------------------------------------------------------------------------
    def test_process_stop_condition(self):
        """Verify that when return hurdle exceeds 7.50% (CPI > 3.5%), optimizer halts with None."""
        stop_mix = search_lowest_risk_mix(
            sleeves=SLEEVES,
            expected_returns=EXPECTED_RETURNS,
            cov_matrix=self.cov_matrix,
            reserve_sleeves=RESERVE_ELIGIBLE_SLEEVES,
            objective=8.05,  # Impossible hurdle under standard sleeves
            min_reserve_weight=self.reserve_min,
            step=5,
        )
        self.assertIsNone(stop_mix, "When objective is beyond feasible simplex, optimizer must return None (halting process).")

    # --------------------------------------------------------------------------
    # 9. FROZEN ARTIFACT AND DECISION MEMO SYNCHRONIZATION
    # --------------------------------------------------------------------------
    def test_visible_output_synchronization(self):
        """Verify visible_output.json matches decision memo and optimal mix numbers exactly."""
        p = Path(__file__).resolve().parent / "visible_output.json"
        self.assertTrue(p.exists(), "visible_output.json must exist in repository root.")
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)

        opt = data["optimal_decision_portfolio"]
        self.assertEqual(opt["weights"]["Global equity index fund"], 55.0)
        self.assertEqual(opt["weights"]["Treasury 10-year note"], 20.0)
        self.assertEqual(opt["expected_return"], 6.51)
        self.assertEqual(opt["volatility"], 9.44)
        self.assertEqual(opt["reserve_weight"], 20.0)

        stress = data["locked_changed_input_record"]
        self.assertEqual(stress["actual_execution_result"]["largest_weight_change"]["delta_points"], 25.0)
        self.assertEqual(stress["actual_execution_result"]["volatility_surge_pts"], 3.5)

        # 10. Rebalancing Trade Execution & S9 Downside Risk
        rebal = data["recommendation_and_governance"]["rebalancing_trade_ticket_100m"]
        self.assertEqual(rebal["one_way_turnover_pct"], 20.0)
        self.assertLessEqual(rebal["one_way_turnover_pct"], 25.0)  # Rule S7 compliance
        self.assertEqual(rebal["target_dollars"]["Treasury 10-year note"], 20.0)

        s9 = data["recommendation_and_governance"]["rule_s9_downside_risk_audit"]
        self.assertEqual(s9["meridian_defensive_prob_loss_gt_10pct"], 4.0)
        self.assertEqual(s9["benchmark_60_40_prob_loss_gt_10pct"], 5.4)
        self.assertEqual(s9["crash_risk_reduction_pct"], 26.0)


if __name__ == "__main__":
    unittest.main()
