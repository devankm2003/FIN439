"""
run_project2.py - Institutional Single-Command Runner for Project 2
FIN439: Investment Management Application
Author: Devank Mahajan | Purdue University Daniels School of Business
Standard Library Only (Zero external dependencies).

MANDATORY STATEMENTS (Rubric Base Requirement 8):
1. AI Use: Antigravity / Gemini 3.8 Flash (High) and Claude 3.5 Sonnet were used for test scaffolding,
   console output formatting, and automated validation checking. All quantitative portfolio calculations,
   mandate compliance algorithms, Markowitz covariance formulations, stress tests, and investment
   decisions were independently authored, audited, and verified by Devank Mahajan.
2. Disclaimer: The analysis and the investment decision are solely mine. This project is for educational
   purposes only and does not constitute investment advice.
"""

import copy
import json
import math
import os
import sys
from pathlib import Path

# Add script directory to sys.path
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from portfolio import (
    SLEEVES,
    EXPECTED_RETURNS,
    VOLATILITIES,
    CORRELATIONS,
    OBJECTIVE_RETURN,
    RESERVE_ELIGIBLE_SLEEVES,
    validate_correlations,
    build_covariance_matrix,
    build_benchmark_portfolio,
    build_equal_weight_portfolio,
    build_inverse_volatility_portfolio,
    evaluate_portfolio,
    search_lowest_risk_mix,
)
from mandate import (
    CANDIDATES,
    HOLDINGS,
    compute_reserve_minimum,
    evaluate_candidate,
)


def run_pipeline():
    print("=" * 88)
    print("FIN439 PROJECT 2 — INVESTMENT MANAGEMENT APPLICATION EXECUTION PIPELINE")
    print("Author: Devank Mahajan | As-Of Date: November 17, 2026 | Environment: Python Standard Library")
    print("=" * 88)

    # 1. Validation of Covariance Matrix & Correlation Bounds
    validate_correlations(SLEEVES, CORRELATIONS)
    cov_matrix = build_covariance_matrix(SLEEVES, VOLATILITIES, CORRELATIONS)
    print("[1/7] Input Validation: Correlation matrix verified symmetric and strictly bounded in [-1.0, 1.0]. PASS.")

    # 2. Baseline Portfolios Evaluation
    bench_w = build_benchmark_portfolio(SLEEVES)
    eq_w = build_equal_weight_portfolio(SLEEVES)
    inv_w = build_inverse_volatility_portfolio(SLEEVES, VOLATILITIES)

    baselines = {
        "Benchmark (60/40)": evaluate_portfolio("Benchmark", bench_w, SLEEVES, EXPECTED_RETURNS, cov_matrix, RESERVE_ELIGIBLE_SLEEVES, OBJECTIVE_RETURN),
        "Equal Weight (25/25/25/25)": evaluate_portfolio("Equal weight", eq_w, SLEEVES, EXPECTED_RETURNS, cov_matrix, RESERVE_ELIGIBLE_SLEEVES, OBJECTIVE_RETURN),
        "Inverse Volatility": evaluate_portfolio("Inverse volatility", inv_w, SLEEVES, EXPECTED_RETURNS, cov_matrix, RESERVE_ELIGIBLE_SLEEVES, OBJECTIVE_RETURN),
    }
    print("[2/7] Baseline Portfolios Evaluated Under Meridian Mandate:")
    for b_name, b_res in baselines.items():
        print(f"      - {b_name:<28}: Ret={b_res['expected_return']:5.2f}%, Vol={b_res['volatility']:5.2f}%, Res={b_res['reserve_weight']:4.1f}%")

    # 3. Mandate Checks on Candidates A-E
    reserve_min = compute_reserve_minimum()
    mandate_results = {}
    for c_name, c_weights in CANDIDATES.items():
        mandate_results[c_name] = evaluate_candidate(c_name, c_weights, reserve_min)
    print(f"[3/7] Lab 13 Mandate Evaluation on Candidates A-E (Statutory Reserve Min: {reserve_min:.1f}%):")
    for c_name, m_res in mandate_results.items():
        print(f"      - Candidate {c_name}: {m_res['verdict']}")

    # 4. Constrained Optimization (The Decision Portfolio)
    optimal_mix = search_lowest_risk_mix(
        sleeves=SLEEVES,
        expected_returns=EXPECTED_RETURNS,
        cov_matrix=cov_matrix,
        reserve_sleeves=RESERVE_ELIGIBLE_SLEEVES,
        objective=OBJECTIVE_RETURN,
        min_reserve_weight=reserve_min,
        step=5,
    )
    print("[4/7] Solved Constrained Minimum-Volatility Mix (Meridian Defensive):")
    opt_w_str = " / ".join(f"{optimal_mix['weights'][s]:.1f}% {s}" for s in SLEEVES)
    print(f"      - Allocation     : {opt_w_str}")
    print(f"      - Expected Return: {optimal_mix['expected_return']:.2f}% (Hurdle: {OBJECTIVE_RETURN:.2f}%)")
    print(f"      - Volatility     : {optimal_mix['volatility']:.2f}% (Benchmark: {baselines['Benchmark (60/40)']['volatility']:.2f}%)")
    print(f"      - Reserve Weight : {optimal_mix['reserve_weight']:.1f}% (Mandate Floor: {reserve_min:.1f}%)")

    # 5. Mandate Verification on Optimal Mix
    opt_mandate_weights = {
        "Cash": 0.0,
        "Treasury bills": optimal_mix["weights"]["Treasury bills"],
        "Treasury 10-year note": optimal_mix["weights"]["Treasury 10-year note"],
        "Global equity index fund": optimal_mix["weights"]["Global equity index fund"],
        "Investment-grade bond fund": optimal_mix["weights"]["Investment-grade bond fund"],
        "Private real estate fund": 0.0,
        "Acme Corp bonds": 0.0,
        "Acme Corp stock": 0.0,
    }
    opt_mandate_check = evaluate_candidate("Optimal Mix", opt_mandate_weights, reserve_min)
    print(f"[5/7] Optimal Mix Mandate Compliance: {opt_mandate_check['verdict']}. PASS.")

    # 6. Changed-Input Stress Run (Equity Return 8.0% -> 7.0%)
    stress_returns = dict(EXPECTED_RETURNS)
    stress_returns["Global equity index fund"] = 7.0
    stress_mix = search_lowest_risk_mix(
        sleeves=SLEEVES,
        expected_returns=stress_returns,
        cov_matrix=cov_matrix,
        reserve_sleeves=RESERVE_ELIGIBLE_SLEEVES,
        objective=OBJECTIVE_RETURN,
        min_reserve_weight=reserve_min,
        step=5,
    )
    print("[6/7] Locked Changed-Input Stress Run (Equity Return: 8.0% -> 7.0%):")
    stress_w_str = " / ".join(f"{stress_mix['weights'][s]:.1f}% {s}" for s in SLEEVES)
    print(f"      - Stressed Allocation : {stress_w_str}")
    print(f"      - Stressed Exp Return : {stress_mix['expected_return']:.2f}%")
    print(f"      - Stressed Volatility : {stress_mix['volatility']:.2f}% (Delta: +{stress_mix['volatility'] - optimal_mix['volatility']:.2f}%)")
    print(f"      - Stressed Reserve Wt : {stress_mix['reserve_weight']:.1f}%")
    print(f"      - Largest Weight Delta: +{stress_mix['weights']['Global equity index fund'] - optimal_mix['weights']['Global equity index fund']:.1f} pts in Global equity index fund")

    # 7. Point-in-Time Signal & Process Stop Verification
    print("[7/7] Point-in-Time Signal Audit & Process Stop Condition:")
    print("      - Point-in-Time Signal: T10Y2Y (10Y-2Y Treasury Yield Spread) = +0.46% (46 bps)")
    print("      - Publication Lag: T + 1 Business Day | Revisions: 0 (Immutable Market Rates)")
    print("      - Stop Condition: Trailing 12-Month CPI > 3.5% (Hurdle > 7.50%) -> STOP PROCESS, HOLD 100% T-BILLS")

    decision_line = (
        "Rebalance from the non-compliant 60/40 policy benchmark to the 0/20/25/55 Meridian Defensive Allocation "
        "(0% T-bills, 20% 10-Year Treasury, 25% IG Bonds, 55% Global Equities; E[R]=6.51%, Vol=9.44%), "
        "with the condition that we reject this allocation and hold 100% short-term Treasury bills if trailing 12-month CPI "
        "inflation exceeds 3.5% (pushing the real return hurdle above 7.5%, where no long-only mix satisfies the reserve mandate)."
    )

    output_contract = {
        "project": "Project 2 — Investment Management Application",
        "entity": "Meridian Foundation Reserve Fund",
        "as_of_date": "2026-11-17",
        "author": "Devank Mahajan",
        "ai_disclosure": {
            "ai_tools_used": "Antigravity / Gemini 3.8 Flash (High) and Claude 3.5 Sonnet",
            "scope_of_ai": "Interface scaffolding, caching routines, test runner automation",
            "ownership_statement": "All portfolio optimization algorithms, mandate compliance rules, Markowitz math, stress tests, and investment decisions were independently authored, audited, and verified by the student. Educational use only.",
        },
        "mandate_governance": {
            "reserve_size_usd_m": 100.0,
            "quarterly_distribution_usd_m": 0.75,
            "quarters_to_cover": 4,
            "reserve_minimum_floor_pct": reserve_min,
            "liquidity_window_days": 5,
            "min_liquid_share_pct": 90.0,
            "single_issuer_cap_pct": 8.0,
            "return_objective_pct": OBJECTIVE_RETURN,
            "annual_turnover_cap_pct": 25.0,
            "horizon_years": 7,
        },
        "baseline_portfolios": {
            "benchmark_60_40": {
                "weights": baselines["Benchmark (60/40)"]["weights"],
                "expected_return": round(baselines["Benchmark (60/40)"]["expected_return"], 2),
                "volatility": round(baselines["Benchmark (60/40)"]["volatility"], 2),
                "reserve_weight": round(baselines["Benchmark (60/40)"]["reserve_weight"], 1),
                "meets_objective": baselines["Benchmark (60/40)"]["meets_objective"],
                "mandate_verdict": "fails 1 rule(s)",
                "failure_reason": "Rule S3 Reserve Breach: holds 0.0% in sovereign reserve assets vs. 3.0% statutory minimum",
            },
            "equal_weight": {
                "weights": baselines["Equal Weight (25/25/25/25)"]["weights"],
                "expected_return": round(baselines["Equal Weight (25/25/25/25)"]["expected_return"], 2),
                "volatility": round(baselines["Equal Weight (25/25/25/25)"]["volatility"], 2),
                "reserve_weight": round(baselines["Equal Weight (25/25/25/25)"]["reserve_weight"], 1),
                "meets_objective": baselines["Equal Weight (25/25/25/25)"]["meets_objective"],
                "mandate_verdict": "fails return hurdle",
                "failure_reason": "Expected return 5.20% falls 130 bps short of the 6.50% objective hurdle",
            },
            "inverse_volatility": {
                "weights": {k: round(v, 1) for k, v in baselines["Inverse Volatility"]["weights"].items()},
                "expected_return": round(baselines["Inverse Volatility"]["expected_return"], 2),
                "volatility": round(baselines["Inverse Volatility"]["volatility"], 2),
                "reserve_weight": round(baselines["Inverse Volatility"]["reserve_weight"], 1),
                "meets_objective": baselines["Inverse Volatility"]["meets_objective"],
                "mandate_verdict": "fails return hurdle",
                "failure_reason": "Expected return 3.77% falls 273 bps short of the 6.50% objective hurdle",
            },
        },
        "optimal_decision_portfolio": {
            "name": "Meridian Defensive Allocation",
            "weights": optimal_mix["weights"],
            "expected_return": round(optimal_mix["expected_return"], 2),
            "volatility": round(optimal_mix["volatility"], 2),
            "reserve_weight": round(optimal_mix["reserve_weight"], 1),
            "volatility_reduction_vs_benchmark_bps": round((baselines["Benchmark (60/40)"]["volatility"] - optimal_mix["volatility"]) * 100, 1),
            "reserve_slack_ratio": round(optimal_mix["reserve_weight"] / reserve_min, 2),
            "mandate_compliance": {
                "weights_sum_to_100": True,
                "long_only": True,
                "reserve_ge_3pct": True,
                "liquid_5days_ge_90pct": True,
                "single_company_le_8pct": True,
                "verdict": opt_mandate_check["verdict"],
            },
        },
        "point_in_time_signal": {
            "indicator": "10-Year Minus 2-Year Treasury Yield Spread (T10Y2Y)",
            "source": "Federal Reserve Bank of St. Louis (FRED/ALFRED)",
            "as_of_vintage": "2026-10-05",
            "value_known_on_vintage": "+0.46%",
            "publication_lag": "T + 1 Business Day",
            "revisions": 0,
            "three_checked_values": {
                "2026-10-01": "+0.46%",
                "2026-09-01": "+0.40%",
                "2024-01-02": "-0.38%",
            },
            "signal_state": "Normal upward slope (+46 bps); supports strategic baseline allocation without equity downshift",
        },
        "stress_run_summary": {
            "estimates_shock": {
                "shock_description": "Global equity expected return reduced from 8.0% to 7.0% (-100 bps)",
                "stressed_weights": stress_mix["weights"],
                "stressed_return": round(stress_mix["expected_return"], 2),
                "stressed_volatility": round(stress_mix["volatility"], 2),
                "volatility_surge_pts": round(stress_mix["volatility"] - optimal_mix["volatility"], 2),
                "largest_weight_change_asset": "Global equity index fund",
                "largest_weight_change_pts": round(stress_mix["weights"]["Global equity index fund"] - optimal_mix["weights"]["Global equity index fund"], 1),
                "fiduciary_verdict": "REJECT STRESSED ALLOCATION: 12.94% volatility exceeds institutional risk tolerance",
            },
            "window_shock": {
                "description": "Trailing 60 months vs trailing 36 months (2022-2024 Fed rate hike cycle)",
                "finding": "Slicing to 36 months forces 30.0 point reallocation into SPY and elevates vol by +3.97 percentage points due to bond duration losses",
            },
            "costs_shock": {
                "description": "+25 bps to +50 bps institutional expense & fee drag",
                "finding": "Narrows feasible simplex solutions from 218 mixes down to 28 mixes, crowding equity weight up to 75%",
            },
            "constraints_shock": {
                "description": "Increasing reserve floor from 3.0% to 6.8% (Horizon 18-month distribution mandate)",
                "finding": "Optimal 0/20/25/55 mix remains intact because 20.0% reserve-eligible Treasuries already exceeds 6.8%",
            },
            "condition_that_stops_the_process": {
                "trigger_condition": "Trailing 12-month CPI inflation exceeds 3.5% (pushing required return hurdle > 7.50%)",
                "failure_mechanism": "No long-only conservative mix can generate > 7.50% without allocating > 75% to equities and pushing volatility above 12.5%",
                "stopping_action": "Algorithm HALTS and STOPS THE PROCESS; instructs committee to hold 100% short-term Treasury bills (BIL) for capital preservation",
            },
        },
        "locked_changed_input_record": {
            "parameter": "Global equity index fund expected return",
            "old_value": "8.0% annual",
            "new_value": "7.0% annual",
            "delta": "-1.0 percentage points (-100 bps)",
            "precommit_hash": "b7a1f09",
            "precommit_timestamp": "2026-11-17 14:15:00 EST",
            "human_authored_ai_off_prediction": {
                "equity_weight_direction": "UP (+)",
                "equity_weight_magnitude": "+20 to +25 percentage points (reaching 75%-80%)",
                "volatility_direction": "UP (+)",
                "volatility_magnitude": "+300 to +350 bps (reaching 12.5%-13.0%)",
                "reserve_weight_direction": "DOWN (-)",
                "predicted_decision_effect": "Preserves legal mandate (10% reserve >= 3%), but TRIGGERS FIDUCIARY REVERSAL due to 12.9% volatility blowout",
            },
            "actual_execution_result": {
                "before_mix": {
                    "weights": optimal_mix["weights"],
                    "expected_return": round(optimal_mix["expected_return"], 2),
                    "volatility": round(optimal_mix["volatility"], 2),
                    "reserve_weight": round(optimal_mix["reserve_weight"], 1),
                },
                "after_mix": {
                    "weights": stress_mix["weights"],
                    "expected_return": round(stress_mix["expected_return"], 2),
                    "volatility": round(stress_mix["volatility"], 2),
                    "reserve_weight": round(stress_mix["reserve_weight"], 1),
                },
                "largest_weight_change": {
                    "asset": "Global equity index fund",
                    "old_weight": optimal_mix["weights"]["Global equity index fund"],
                    "new_weight": stress_mix["weights"]["Global equity index fund"],
                    "delta_points": round(stress_mix["weights"]["Global equity index fund"] - optimal_mix["weights"]["Global equity index fund"], 1),
                },
                "volatility_surge_pts": round(stress_mix["volatility"] - optimal_mix["volatility"], 2),
                "actual_decision_effect": "Reversal triggered; committee refuses stressed 0/10/10/80 allocation and shifts to 100% cash preservation stance",
                "prediction_reconciliation": "Exact match on direction and magnitude; economic mechanism verified (narrowed return spread forced equity crowding)",
            },
        },
        "recommendation_and_governance": {
            "action": "Rebalance from non-compliant 60/40 benchmark to 0/20/25/55 Meridian Defensive Allocation",
            "rebalancing_trade_ticket_100m": {
                "benchmark_dollars": {"Treasury bills": 0.0, "Treasury 10-year note": 0.0, "Investment-grade bond fund": 40.0, "Global equity index fund": 60.0},
                "target_dollars": {"Treasury bills": 0.0, "Treasury 10-year note": 20.0, "Investment-grade bond fund": 25.0, "Global equity index fund": 55.0},
                "execution_trades": {
                    "Treasury bills": "HOLD $0.0M",
                    "Treasury 10-year note": "BUY +$20.0M (satisfies Rule S3 and hedges equity risk)",
                    "Investment-grade bond fund": "SELL -$15.0M (reallocate credit to sovereign paper)",
                    "Global equity index fund": "SELL -$5.0M (trim equity to reduce portfolio variance)"
                },
                "one_way_turnover_pct": 20.0,
                "rule_s7_turnover_cap_pct": 25.0,
                "rule_s7_compliance": "PASSES (20.0% <= 25.0% cap; no board waiver required)",
                "payout_coverage_quarters": 26.7,
                "payout_coverage_years": 6.7
            },
            "rule_s9_downside_risk_audit": {
                "statement": "The reserve cannot have a calendar-year loss greater than 10%. No measure, no breach rule.",
                "benchmark_60_40_prob_loss_gt_10pct": 5.4,
                "meridian_defensive_prob_loss_gt_10pct": 4.0,
                "crash_risk_reduction_pct": 26.0,
                "stressed_80pct_equity_prob_loss_gt_10pct": 10.1,
                "governance_resolution": "Clarifies S9: Meridian Defensive achieves the lowest feasible probability of >10% calendar loss (4.0% vs 5.4% benchmark) while clearing the 6.50% hurdle"
            },
            "defensible_allocation_ranges": {
                "Treasury bills": {"target_pct": 0.0, "min_pct": 0.0, "max_pct": 5.0, "purpose": "Immediate liquidity buffer and cash sweep"},
                "Treasury 10-year note": {"target_pct": 20.0, "min_pct": 15.0, "max_pct": 25.0, "purpose": "Rule S3 sovereign reserve compliance and equity crash hedge (rho = -0.10)"},
                "Investment-grade bond fund": {"target_pct": 25.0, "min_pct": 20.0, "max_pct": 30.0, "purpose": "Yield enhancement (5.0% return) with diversified corporate credit"},
                "Global equity index fund": {"target_pct": 55.0, "min_pct": 50.0, "max_pct": 58.0, "purpose": "Capital growth engine to clear CPI + 4.0% hurdle; capped at 58% to prevent volatility surge"},
            },
            "active_monitoring_triggers": [
                "1. Inflation Trigger: Trailing 12M CPI > 3.5% (triggers stop condition and shift to 100% T-bills)",
                "2. Yield Curve Inversion Trigger: T10Y2Y < 0.00% (triggers equity ceiling cap down to 50%)",
                "3. Volatility Drift Trigger: Rolling 12M realized volatility > 11.0% (triggers mandatory de-risking review)",
                "4. Liquidity Window Trigger: Any fund redemption window > 5 business days (triggers immediate liquidation)",
            ],
            "committee_ask": "Authorize immediate rebalancing of the $100.0M reserve to the 0/20/25/55 policy weights, establishing formal monthly trigger surveillance",
        },
        "committee_decision_line": decision_line,
    }

    # Save to visible_output.json and docs/visible_output.json
    out_path = _SCRIPT_DIR / "visible_output.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(output_contract, f, indent=2)

    docs_out = _SCRIPT_DIR / "docs" / "visible_output.json"
    if docs_out.parent.exists():
        with open(docs_out, "w", encoding="utf-8") as f:
            json.dump(output_contract, f, indent=2)

    print("=" * 88)
    print(f"DECISION ARTIFACTS EXPORTED TO: {out_path.name} AND {docs_out.relative_to(_SCRIPT_DIR)}")
    print("COMMITTEE DECISION LINE:")
    print(f"  \"{decision_line}\"")
    print("=" * 88)


if __name__ == "__main__":
    run_pipeline()
