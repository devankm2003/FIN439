# Meridian Foundation Reserve Fund — Investment Management Application
**Project 2 | FIN 43900: Applied Financial Decision Systems | Daniels School of Business, Purdue University**  
**Author:** Devank Mahajan | **Reference / As-Of Date:** November 17, 2026  

---

### Mandatory Opening Statements (Rubric Base Requirement 8)
1. **AI Disclosure Statement:** Generative AI tools (Antigravity / Gemini 3.8 Flash (High) and Claude 3.5 Sonnet) were utilized for user interface scaffolding, data-caching wrappers, test runner automation, and documentation styling. All quantitative portfolio calculations, Markowitz covariance formulations, mandate compliance rules, financial stress tests, and investment decisions were independently authored, audited, and verified by Devank Mahajan.
2. **Fiduciary & Educational Disclaimer:** The analysis, evaluations, and investment decisions contained herein are solely the author's work for academic evaluation in FIN 43900 at Purdue University; strictly for educational purposes, not investment advice.

---

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![Decision: Rebalance to Defensive](https://img.shields.io/badge/decision-REBALANCE%20TO%200%2F20%2F25%2F55-green.svg)](docs/decision-memo.md)
[![Mandate Compliance: 5/5 Passing](https://img.shields.io/badge/mandate-5%2F5%20PASSING-brightgreen.svg)](mandate.py)
[![Standard Library Runner: Zero Pip Dependencies](https://img.shields.io/badge/runner-STANDARD%20LIBRARY%20ONLY-blue.svg)](run_project2.py)

---

## 1. Executive Summary & Committee Action Line

> **"Rebalance from the non-compliant 60/40 policy benchmark to the 0/20/25/55 Meridian Defensive Allocation (0% T-bills, 20% 10-Year Treasury, 25% IG Bonds, 55% Global Equities; E[R]=6.51%, Vol=9.44%), with the condition that we reject this allocation and hold 100% short-term Treasury bills if trailing 12-month CPI inflation exceeds 3.5% (pushing the real return hurdle above 7.5%, where no long-only mix satisfies the reserve mandate)."**

- **Target Fund:** Meridian Foundation Reserve Fund ($100.0M perpetual AUM).
- **Primary Objective (Rule S2):** Earn >= CPI + 4.0% (6.50% nominal) net of costs over rolling 5-year periods.
- **Liquidity Floor (Rule S3):** Maintain >= 4 quarters of distributions (4 * $0.75M = $3.0M = 3.0%) in cash or daily-liquid sovereign paper.
- **Risk Measure & Limits:** Annualized portfolio volatility, long-only weights (no shorting, Rule S5), annual turnover <= 25% (Rule S7), 5-day liquid share >= 90% (Rule S8), and single corporate issuer cap <= 8.0% (Rule S6).

---

## 2. Quickstart: How a Stranger Starts and Operates the App

### Option A: The Single Command to Reproduce the Full Quantitative Result (Zero Dependencies)
A stranger can clone this repository and reproduce every baseline evaluation, mandate check, Markowitz optimization, and stress run in **0.18 seconds** using only the Python standard library (no pip packages or virtual environment activation required):
```bash
python3 run_project2.py
```

### Option B: The Interactive Streamlit Investment Management Application
To launch the interactive multi-tab web application where committee members can adjust sliders, inspect point-in-time signals, and simulate stress tests:
```bash
# 1. Install dependencies (if not already present)
pip install streamlit pandas

# 2. Launch the application
streamlit run app.py
```
The app opens automatically at `http://localhost:8501`. A committee member can move any return input, toggle reserve statuses, or adjust hurdles to immediately observe live allocation changes and compliance badges.

---

## 3. Two Baselines and Your Constrained Portfolio (Rubric Base Requirement 3)

The table below benchmarks our constrained portfolio directly against the Foundation's two required transparent baselines under the strict legal mandate of the Investment Policy Statement:

| Portfolio Strategy | Allocation (Bills / 10-Yr / IG / Equity) | Expected Return (% p.a.) | Annualized Volatility (% p.a.) | Sovereign Reserve Weight (%) | Mandate Compliance Status & Rule Verdict |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **Baseline 1: Equal Weight** | `25.0 / 25.0 / 25.0 / 25.0` | **5.20%** | **5.21%** | **50.0%** | ❌ **FAILS** (Return hurdle missed: 5.20% < 6.50%) |
| **Baseline 2: 60/40 Policy Benchmark** | `0.0 / 0.0 / 40.0 / 60.0` | **6.80%** | **10.46%** | **0.0%** | ❌ **FAILS 1 RULE** (Rule S3 Reserve Breach: 0.0% < 3.0%) |
| **Alternative: Inverse Volatility** | `84.3 / 6.0 / 7.0 / 2.6` | **3.77%** | **1.05%** | **90.3%** | ❌ **FAILS** (Return hurdle missed: 3.77% < 6.50%) |
| **Meridian Defensive (Constrained)** | `0.0 / 20.0 / 25.0 / 55.0` | **6.51%** | **9.44%** | **20.0%** | ✅ **PASSES EVERY CHECKABLE RULE (5/5 Passing)** |

### Governance Insight: The 60/40 Policy Benchmark Dilemma
The board-designated 60/40 Policy Benchmark holds **0.0% in sovereign reserve assets**. Investment-grade corporate bonds represent corporate credit and are non-exempt under mandate governance. Consequently, **the board's own policy benchmark violates the Foundation's own legal reserve requirement**. Our Meridian Defensive allocation fixes this breach by allocating 20.0% to 10-Year Treasuries, which satisfies the reserve floor while reducing portfolio risk by -102 bps due to negative equity correlation (correlation: -0.10).

---

## 4. Point-in-Time Signal & Data Card (Rubric Base Requirement 4)

We integrate the **10-Year Minus 2-Year Treasury Yield Spread (`T10Y2Y`)** as our point-in-time macroeconomic signal from Federal Reserve ALFRED archives.

```
+-----------------------------------------------------------------------------------------------+
| FORMAL DATA CARD: T10Y2Y POINT-IN-TIME SIGNAL                                                 |
+-----------------------------------------------------------------------------------------------+
| Indicator Name       : 10-Year Treasury Minus 2-Year Treasury Constant Maturity Yield Spread  |
| Source & URL         : Federal Reserve Bank of St. Louis (ALFRED / FRED):                     |
|                        https://fred.stlouisfed.org/series/T10Y2Y                              |
| Economic Construct   : Term spread / yield curve slope; primary recession & drawdown indicator|
| Units                : Percentage points (e.g., 0.46 = 46 basis points)                       |
| Publication Lag      : T + 1 business day (published ~8:00 AM ET each business morning)       |
| Revision History     : 0 revisions (executed market transactions; immutable historical quotes)|
| As-Of Vintage Date   : October 5, 2026                                                        |
| Three Hand-Checked   : 1. 2026-10-01: +0.46% (Dis-inverting curve steepener)                  |
| Verification Points  : 2. 2026-09-01: +0.40% (Normalizing slope post-inversion)               |
|                      : 3. 2024-01-02: -0.38% (Inverted curve warning of equity drawdown)      |
| Decision Rule        : Inversion (< 0.00%) caps equity ceiling at 50%; normal slope (>= 0.00%) |
|                        permits the 55% strategic allocation.                                  |
+-----------------------------------------------------------------------------------------------+
```

---

## 5. Stress Testing & The Condition That Stops the Process (Rubric Base Requirement 5)

Our application executes sensitivity analysis across four dimensions:
1. **Estimates Shock:** A -100 bps drop in Global Equity expected return (8.0% $\rightarrow$ 7.0%) forces the optimizer into a crowded 0/10/10/80 mix, surging portfolio volatility by **+3.50 percentage points (+37.1% risk surge to 12.94%)**. The committee explicitly rejects this stressed mix.
2. **Window / History Shock:** Slicing empirical returns from `prices.csv` to the trailing 36 months (2022–2024 Fed rate hike regime) generates fixed-income duration losses, forcing a 30-point reallocation into equities (`SPY` 35% $\rightarrow$ 65%) and increasing risk by +3.97 percentage points.
3. **Cost Drag Shock:** Adding 25 to 50 bps of management fees ratchets the nominal hurdle up to 6.75%–7.00%, compressing feasible simplex mixes from 218 down to 28.
4. **Constraint Shock:** Raising the reserve floor from 3.0% to 6.8% (18 months of coverage) leaves the 0/20/25/55 allocation unchanged, demonstrating structural liquidity slack.

### 🛑 The Formal Condition That Stops the Process
- **Stopping Trigger:** **Trailing 12-month CPI inflation exceeds 3.5% (pushing required hurdle > 7.50%).**
- **Economic Breakdown:** Because Treasury bills yield 3.5%, 10-year Treasuries yield 4.3%, and corporate bonds yield 5.0%, no long-only multi-asset allocation can generate > 7.50% return without taking $> 75\%$ equity concentration and $> 12.5\%$ volatility.
- **Stopping Action:** The algorithm **HALTS AND STOPS THE PROCESS**. It refuses to optimize into a reckless high-volatility mix and directs the fund to hold **100% short-term Treasury bills (`BIL`)** for capital preservation until CPI inflation normalizes below 3.5%.

---

## 6. Locked Changed-Input Record (Rubric Base Requirement 6)

Authored and precommitted with AI closed before the execution run:
- **Precommit Timestamp:** November 17, 2026, 14:15:00 EST
- **Precommit Repository Hash:** `b7a1f09`
- **Material Input Selected:** Expected Annual Return of the **Global Equity Index Fund**.
- **Old Value $\rightarrow$ New Value & Units:** **8.00% annual** $\rightarrow$ **7.00% annual** (-100 bps).

| Performance Metric | Before Output (8.0% Equity E[R]) | After Output (7.0% Equity E[R]) | Actual Shift & Reconciliation |
| :--- | :---: | :---: | :--- |
| **Treasury bills weight** | 0.0% | 0.0% | 0.0 points |
| **Treasury 10-year note weight** | 20.0% | 10.0% | -10.0 points (displaced by equity) |
| **Investment-grade bond weight** | 25.0% | 10.0% | -15.0 points (displaced by equity) |
| **Global equity index fund weight** | 55.0% | 80.0% | **+25.0 points (Largest Weight Change)** |
| **Expected Portfolio Return** | 6.51% | 6.53% | +0.02 points |
| **Annualized Portfolio Volatility** | 9.44% | 12.94% | **+3.50 percentage points (+37.1% Risk Surge)** |
| **Reserve-Eligible Weight** | 20.0% | 10.0% | -10.0 points (remains $\ge 3.0\%$ legal floor) |
| **Mandate Compliance Status** | PASS (5/5 rules) | PASS (5/5 rules) | Preserved legally |
| **Fiduciary Committee Decision** | **ADOPT (0/20/25/55)** | **REJECT (0/10/10/80)** | **REVERSAL TRIGGERED due to 12.94% risk** |

*Failure Diagnosis:* Direction (+ for equity, + for volatility, - for reserve) and magnitude (+25 pts equity, +3.50 pts vol) matched human precommit prediction with 100% accuracy. The narrowed return spread between equities and bonds forced the optimizer to concentrate capital into equities to clear the 6.50% hurdle.

---

## 7. Recommendation, Defensible Ranges & Triggers (Rubric Base Requirement 7)

### Defensible Policy Allocation Ranges
- **Treasury bills (Cash Equivalents):** Target **0.0%** (Permissible Range: **0.0% – 5.0%**; cash sweep).
- **Treasury 10-year notes (Sovereign Paper):** Target **20.0%** (Permissible Range: **15.0% – 25.0%**; Rule S3 reserve buffer & crash hedge).
- **Investment-grade bond fund (Corporate Credit):** Target **25.0%** (Permissible Range: **20.0% – 30.0%**; credit carry).
- **Global equity index fund (Public Equities):** Target **55.0%** (Permissible Range: **50.0% – 58.0%**; growth engine, hard cap at 58% to prevent volatility blowout).

### Actionable Rebalancing Trade Ticket ($100M AUM)
| Asset Sleeve | Benchmark Weight ($M) | Target Policy Weight ($M) | Permissible Policy Range | Execution Order ($M) | Governance Role |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **Treasury bills** | 0.0% ($0.0M) | **0.0% ($0.0M)** | 0.0% – 5.0% | **HOLD $0.0M** | Cash sweep & rebalancing buffer. |
| **Treasury 10-year note** | 0.0% ($0.0M) | **20.0% ($20.0M)** | 15.0% – 25.0% | **BUY +$20.0M** | Cures Rule S3 breach; hedges equities (correlation: -0.10). |
| **Investment-grade bonds**| 40.0% ($40.0M)| **25.0% ($25.0M)** | 20.0% – 30.0% | **SELL -$15.0M** | Reallocate credit to sovereign paper. |
| **Global equity index fund**| 60.0% ($60.0M)| **55.0% ($55.0M)** | 50.0% – 58.0% | **SELL -$5.0M** | Trim equity to curb portfolio variance. |
| **TOTALS** | **100.0% ($100.0M)** | **100.0% ($100.0M)**| — | **$40.0M Volume** | **Turnover = 20.0% <= 25.0% (PASSES RULE S7)** |

- **Rule S7 Turnover Audit:** Rebalancing churn is 0.5 * ($0M + $20M + $15M + $5M) / $100M = **20.0% <= 25.0%**, adhering to IPS limits without requiring a committee waiver.
- **Rule S9 Downside Risk Resolution:** Moving from 60/40 to Meridian Defensive reduces the probability of a greater than 10% single-year loss from **5.4% down to 4.0% (a 26% crash risk reduction)**.
- **Distribution Payout Coverage:** The $20.0M sovereign liquidity pool guarantees **26.7 consecutive quarters (6.7 years)** of distributions without forced asset liquidations during market drawdowns.

### Active Monitoring Triggers
1. **Inflation Hurdle Trigger (Trailing 12M CPI > 3.5%):** Stops process and shifts fund to 100% T-bills.
2. **Yield Curve Inversion Trigger (T10Y2Y < 0.00%):** Prompts downshift of equity allocation to 50% floor.
3. **Volatility Drift Trigger (Rolling 12M Volatility > 11.0%):** Triggers mandatory de-risking rebalance into 10-Year Treasuries.
4. **Liquidity Rule Trigger (5-Day Liquid Share < 90.0%):** Rule S8 breach; prompts immediate liquidation of delayed holdings.

---

## 8. Cold Run Peer Audit & Reproduction Record

- **Peer Auditor:** Kaosi Ogbuef (FIN 43900 Lab Task Force).
- **Repository Provided:** `https://github.com/devankm2003/FIN439.git` (no verbal coaching).
- **First Failure Recorded:** The auditor encountered an `ImportError` on `streamlit` when attempting `python3 app.py` in a fresh environment, and observed legacy Project 1 references in the old README.
- **Resolution:** Engineered `run_project2.py` requiring standard library only (zero external packages), executing in 0.18 seconds, and restructured `README.md` to highlight the single command at the top.
- **Verification:** All baseline metrics, mandate checks, and stress results in [`visible_output.json`](visible_output.json) matched terminal stdout and `docs/decision-memo.md` exactly.

---

## 9. Submission Manifest & Key Artifacts

| Deliverable Part | File Location | GitHub URL | Description |
| :--- | :--- | :--- | :--- |
| **Repository** | Root | [FIN439 Repository](https://github.com/devankm2003/FIN439.git) | Accessible repository with runnable source & visible output |
| **Single-Command Runner** | `run_project2.py` | [run_project2.py](https://github.com/devankm2003/FIN439/blob/main/run_project2.py) | Python standard library single-command reproduction engine |
| **Interactive App** | `app.py` | [app.py](https://github.com/devankm2003/FIN439/blob/main/app.py) | Streamlit multi-tab institutional workbench |
| **Visible Output** | `visible_output.json` | [visible_output.json](https://github.com/devankm2003/FIN439/blob/main/visible_output.json) | Frozen reviewable decision numbers readable on GitHub |
| **Decision Memo** | `docs/decision-memo.md` | [decision-memo.md](https://github.com/devankm2003/FIN439/blob/main/docs/decision-memo.md) | 2-page equivalent executive investment memorandum |
| **Validation & AI Use** | `docs/validation-and-ai-use.md` | [validation-and-ai-use.md](https://github.com/devankm2003/FIN439/blob/main/docs/validation-and-ai-use.md) | Validation register, AI register, and Locked Prediction Record |
| **Submission Manifest** | `manifest.csv` | [manifest.csv](https://github.com/devankm2003/FIN439/blob/main/manifest.csv) | Machine-readable audit manifest with commit & durations |
| **Video 1 Transcript** | `docs/transcript-video-1.txt` | [transcript-video-1.txt](https://github.com/devankm2003/FIN439/blob/main/docs/transcript-video-1.txt) | Video 1 script: System evolution & audited AI output (02:54) |
| **Video 2 Transcript** | `docs/transcript-video-2.txt` | [transcript-video-2.txt](https://github.com/devankm2003/FIN439/blob/main/docs/transcript-video-2.txt) | Video 2 script: Code walkthrough & cold run audit (04:48) |
| **Video 3 Transcript** | `docs/transcript-video-3.txt` | [transcript-video-3.txt](https://github.com/devankm2003/FIN439/blob/main/docs/transcript-video-3.txt) | Video 3 script: Committee defense opening with live demo (04:51) |
