#!/bin/bash
cd "$(dirname "$0")"
echo "Starting Meridian Foundation Investment Application..."
python3 -m streamlit run app.py
