"""asof_app.py — Lab 17: Point-in-Time FRED & ALFRED Interest Rates & Macro Audit

Streamlit application demonstrating point-in-time information availability,
publication lags, and historical revisions using public CSV feeds from FRED and ALFRED.

No API key required. One request per series.
"""

from datetime import date
import io
import os
import urllib.request
import urllib.error

import pandas as pd
import streamlit as st

# Ensure local cache directory exists for resilience against network latency
CACHE_DIR = os.path.expanduser("~/.fred_cache")
os.makedirs(CACHE_DIR, exist_ok=True)

# ==============================================================================
# 1. CORE DATA INGESTION & CACHING FUNCTIONS
# ==============================================================================

@st.cache_data(ttl=3600, show_spinner=False)
def get_today_data(series_id: str) -> pd.DataFrame:
    """
    Downloads today's latest values for a series from FRED's public CSV endpoint.
    URL: https://fred.stlouisfed.org/graph/fredgraph.csv?id=SERIES
    
    Filters out '.' missing values and returns a DataFrame with:
      - 'observation_date': pd.Timestamp
      - 'value': float
    """
    cache_path = os.path.join(CACHE_DIR, f"{series_id}_today.csv")
    content = None
    url = f"https://fred.stlouisfed.org/graph/fredgraph.csv?id={series_id}"
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "curl/8.7.1", "Connection": "close"}
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            content = resp.read().decode("utf-8")
            with open(cache_path, "w", encoding="utf-8") as f:
                f.write(content)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise ValueError(f"Series ID '{series_id}' was not found on FRED (HTTP 404).")
        if os.path.exists(cache_path):
            with open(cache_path, "r", encoding="utf-8") as f:
                content = f.read()
        else:
            raise RuntimeError(f"FRED request failed for '{series_id}': HTTP {e.code} {e.reason}")
    except Exception as e:
        if os.path.exists(cache_path):
            with open(cache_path, "r", encoding="utf-8") as f:
                content = f.read()
        else:
            raise RuntimeError(f"Network error connecting to FRED for '{series_id}': {e}")

    df = pd.read_csv(io.StringIO(content))
    if df.empty or len(df.columns) < 2:
        raise ValueError(f"No data returned from FRED for series '{series_id}'.")

    val_col = df.columns[1]
    # Filter out missing days indicated by '.'
    df = df[df[val_col] != "."].copy()
    df[val_col] = pd.to_numeric(df[val_col], errors="coerce")
    df = df.dropna(subset=[val_col])
    df["observation_date"] = pd.to_datetime(df["observation_date"])
    return df.rename(columns={val_col: "value"}).sort_values("observation_date").reset_index(drop=True)


@st.cache_data(ttl=3600, show_spinner=False)
def get_asof_data(series_id: str, vintage_date: str) -> pd.DataFrame:
    """
    Downloads values as known on a specific vintage date from ALFRED's public CSV endpoint.
    URL: https://alfred.stlouisfed.org/graph/alfredgraph.csv?id=SERIES&vintage_date=YYYY-MM-DD
    
    Filters out '.' missing values and returns a DataFrame with:
      - 'observation_date': pd.Timestamp
      - 'value': float
    """
    cache_path = os.path.join(CACHE_DIR, f"{series_id}_{vintage_date}.csv")
    content = None
    url = f"https://alfred.stlouisfed.org/graph/alfredgraph.csv?id={series_id}&vintage_date={vintage_date}"
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "curl/8.7.1", "Connection": "close"}
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            content = resp.read().decode("utf-8")
            with open(cache_path, "w", encoding="utf-8") as f:
                f.write(content)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise ValueError(f"Series ID '{series_id}' was not found on ALFRED for vintage {vintage_date} (HTTP 404).")
        if os.path.exists(cache_path):
            with open(cache_path, "r", encoding="utf-8") as f:
                content = f.read()
        else:
            raise RuntimeError(f"ALFRED request failed for '{series_id}': HTTP {e.code} {e.reason}")
    except Exception as e:
        if os.path.exists(cache_path):
            with open(cache_path, "r", encoding="utf-8") as f:
                content = f.read()
        else:
            raise RuntimeError(f"Network error connecting to ALFRED for '{series_id}': {e}")

    df = pd.read_csv(io.StringIO(content))
    if df.empty or len(df.columns) < 2:
        raise ValueError(f"No vintage data returned from ALFRED for series '{series_id}' on {vintage_date}.")

    val_col = df.columns[1]
    # Filter out missing days indicated by '.'
    df = df[df[val_col] != "."].copy()
    df[val_col] = pd.to_numeric(df[val_col], errors="coerce")
    df = df.dropna(subset=[val_col])
    df["observation_date"] = pd.to_datetime(df["observation_date"])
    return df.rename(columns={val_col: "value"}).sort_values("observation_date").reset_index(drop=True)


# ==============================================================================
# 2. HELPER FORMATTERS
# ==============================================================================

def format_observation_date(dt: pd.Timestamp, df: pd.DataFrame) -> str:
    """
    Formats observation dates cleanly:
      - Monthly series: 'September 2026'
      - Weekly / Daily series: '1 October 2026', '2 October 2026'
    """
    median_diff = df["observation_date"].diff().dropna().dt.days.median()
    if pd.notna(median_diff) and median_diff >= 25:
        return dt.strftime("%B %Y")
    return f"{dt.day} {dt.strftime('%B %Y')}"


def format_series_value(val: float) -> str:
    """Formats numbers cleanly (e.g. 6.47 or 159,536)."""
    if abs(val) >= 1000:
        return f"{val:,.0f}" if float(val).is_integer() else f"{val:,.2f}"
    return f"{val:.2f}"


# ==============================================================================
# 3. STREAMLIT UI CONFIGURATION & SIDEBAR
# ==============================================================================

st.set_page_config(
    page_title="FRED Point-in-Time Audit",
    page_icon="📈",
    layout="wide",
)

st.title("FRED Point-in-Time Interest Rates & Macro Audit")
st.caption("data from FRED and ALFRED, Federal Reserve Bank of St. Louis, downloaded today; built with AI help, a learning demonstration, not investment advice.")

# Sidebar options
st.sidebar.header("Data & Point-in-Time Controls")

DEFAULT_SERIES = {
    "BAA": "BAA (Moody's Baa corporate bond yield)",
    "FEDFUNDS": "FEDFUNDS (federal funds rate)",
    "DGS10": "DGS10 (10-year Treasury yield)",
    "MORTGAGE30US": "MORTGAGE30US (30-year mortgage rate)",
}

selected_series_keys = st.sidebar.multiselect(
    "Select Series IDs:",
    options=list(DEFAULT_SERIES.keys()),
    default=list(DEFAULT_SERIES.keys()),
    format_func=lambda k: DEFAULT_SERIES.get(k, k),
    help="Select one or more benchmark series to analyze.",
)

custom_series_input = st.sidebar.text_input(
    "Add any other FRED series ID:",
    value="",
    placeholder="e.g. PAYEMS, UNRATE, T10Y2Y, CPIAUCSL",
    help="Type any FRED series ID and press Enter.",
)

# Combine selected IDs preserving order without duplicates
active_series = list(selected_series_keys)
if custom_series_input.strip():
    for raw_id in custom_series_input.replace(",", " ").split():
        cleaned_id = raw_id.strip().upper()
        if cleaned_id and cleaned_id not in active_series:
            active_series.append(cleaned_id)

start_date_val = st.sidebar.date_input(
    "Start date for charts:",
    value=date(2020, 1, 1),
    help="Charts will plot today's values from this date onward.",
)

asof_date_val = st.sidebar.date_input(
    "As known on date (ALFRED vintage):",
    value=date.today(),
    help="Reconstructs what was known on this exact date in history.",
)
asof_str = asof_date_val.strftime("%Y-%m-%d")
start_dt = pd.to_datetime(start_date_val)

# ==============================================================================
# 4. DATA PROCESSING & LINE CHARTS
# ==============================================================================

if not active_series:
    st.warning("Please select at least one series from the sidebar.")
    st.stop()

table_rows = []

st.header("1. Historical Rate Series (Today's Values from Start Date)")

for sid in active_series:
    display_title = DEFAULT_SERIES.get(sid, f"{sid} (Custom Series)")
    try:
        df_today = get_today_data(sid)
        df_asof = get_asof_data(sid, asof_str)
    except Exception as e:
        st.error(f"⚠️ Error loading series '{sid}': {e}")
        continue

    if df_today.empty or df_asof.empty:
        st.error(f"⚠️ Series '{sid}' returned no valid data.")
        continue

    # Plot today's values from start date
    df_chart = df_today[df_today["observation_date"] >= start_dt].copy()

    st.subheader(f"📊 {display_title}")
    if df_chart.empty:
        st.info(f"No observations available after {start_date_val} for {sid}.")
    else:
        st.line_chart(df_chart, x="observation_date", y="value")

    # Under chart: last date in data known on the "as known on" date
    last_asof_row = df_asof.iloc[-1]
    last_asof_dt = last_asof_row["observation_date"]
    last_asof_val = last_asof_row["value"]
    formatted_asof_date = format_observation_date(last_asof_dt, df_asof)
    formatted_asof_val = format_series_value(last_asof_val)

    st.markdown(
        f"**Last date in the data known on {asof_str}:** "
        f"`{formatted_asof_date}` &nbsp;|&nbsp; "
        f"**Value known then:** `{formatted_asof_val}`"
    )
    st.divider()

    # Collect metrics for comparative table
    last_today_row = df_today.iloc[-1]
    last_today_dt = last_today_row["observation_date"]
    last_today_val = last_today_row["value"]
    formatted_today_date = format_observation_date(last_today_dt, df_today)
    formatted_today_val = format_series_value(last_today_val)

    # How many values today's data has after the last date known then
    late_count = int((df_today["observation_date"] > last_asof_dt).sum())

    # How many values on the same dates have been revised since
    merged = pd.merge(df_asof, df_today, on="observation_date", suffixes=("_asof", "_today"))
    revised_count = int((abs(merged["value_asof"] - merged["value_today"]) > 1e-4).sum())

    table_rows.append({
        "Series ID": sid,
        "FRED URL": f"https://fred.stlouisfed.org/series/{sid}",
        "Last Date Known Then": formatted_asof_date,
        "Value Known Then": formatted_asof_val,
        "Last Date Measured Today": formatted_today_date,
        "Value Today": formatted_today_val,
        "Values Published Since (Late Count)": late_count,
        "Values Revised Since (Revision Count)": revised_count,
    })

# ==============================================================================
# 5. POINT-IN-TIME AUDIT SUMMARY TABLE
# ==============================================================================

st.header(f"2. Point-in-Time Audit Table (Vintage: {asof_str})")

if table_rows:
    df_summary = pd.DataFrame(table_rows)

    # Render interactive Streamlit dataframe with clickable links
    st.dataframe(
        df_summary,
        column_config={
            "FRED URL": st.column_config.LinkColumn(
                "FRED Page",
                display_text=r"https://fred\.stlouisfed\.org/series/(.*)",
            ),
            "Series ID": st.column_config.TextColumn("ID", width="small"),
            "Last Date Known Then": st.column_config.TextColumn(f"Last Date Known ({asof_str})"),
            "Value Known Then": st.column_config.TextColumn(f"Value Known ({asof_str})"),
            "Last Date Measured Today": st.column_config.TextColumn("Last Date Today"),
            "Value Today": st.column_config.TextColumn("Value Today"),
            "Values Published Since (Late Count)": st.column_config.NumberColumn(
                "Values After As-Of Date",
                help="How many observations have been published with observation dates after the vintage cutoff.",
            ),
            "Values Revised Since (Revision Count)": st.column_config.NumberColumn(
                "Revised Observations",
                help="How many observations on overlapping dates have been modified between vintage date and today.",
            ),
        },
        hide_index=True,
        use_container_width=True,
    )

    # Clean markdown table with hyperlinked IDs for immediate copy/paste into checkout memos
    md_lines = [
        "| Series ID | Last Date Known Then | Value Known Then | Last Date Measured Today | Value Today | Values Published Since | Values Revised Since |",
        "| :--- | :--- | :--- | :--- | :--- | :---: | :---: |",
    ]
    for r in table_rows:
        link = f"[{r['Series ID']}]({r['FRED URL']})"
        md_lines.append(
            f"| {link} | {r['Last Date Known Then']} | {r['Value Known Then']} | "
            f"{r['Last Date Measured Today']} | {r['Value Today']} | "
            f"{r['Values Published Since (Late Count)']} | {r['Values Revised Since (Revision Count)']} |"
        )
    
    with st.expander("📋 Copyable Markdown Table (for Lab Checkout & Decision Memos)", expanded=True):
        st.markdown("\n".join(md_lines))
else:
    st.warning("No series could be loaded to populate the summary table.")
