# Warren Buffett Investment Memo: JPMorgan Chase & Co. (JPM)

**To:** Berkshire Hathaway Investment Committee  
**From:** Warren E. Buffett  
**Date:** FY2025 Review  
**Subject:** Evaluation of JPMorgan Chase & Co. (JPM)  
**Verdict:** Watch it  

---

### 1. Circle of Competence & Business Nature
JPMorgan Chase is the preeminent commercial and investment banking institution in the United States, steered by Jamie Dimon, one of the sharpest banking minds in business history. We understand banking well, having owned banks across many decades. However, commercial banks are fundamentally leveraged balance sheet operations that cannot be evaluated using traditional industrial manufacturing frameworks.

### 2. Financial Metrics from 10-K Filings
Examining the last five fiscal years from 2021-12-31 through 2025-12-31:
- **Revenue:** Reported revenues under XBRL tag Revenues were $121,649 million in FY2021, $128,695 million in FY2022, $158,104 million in FY2023, $177,556 million in FY2024, and $182,447 million in FY2025.
- **Net Income:** Reported net income was $48,334 million in FY2021, $37,676 million in FY2022, $49,552 million in FY2023, $58,471 million in FY2024, and $57,048 million in FY2025.
- **Stockholders' Equity & ROE:** Stockholders' equity stood at $294,127 million in FY2021, $292,332 million in FY2022, $327,878 million in FY2023, $344,758 million in FY2024, and $362,438 million in FY2025.
  - FY2021: 16.4%
  - FY2022: 12.9%
  - FY2023: 15.1%
  - FY2024: 17.0%
  - FY2025: 15.7%
- **Capital Spending & Owner Earnings:** In bank regulatory filings, Capital Spending (XBRL tags `PaymentsToAcquirePropertyPlantAndEquipment` and `PaymentsToAcquireProductiveAssets`) is not found. Because capital spending is not found, owner earnings is not found.

### 3. Quantitative Verification
1. **ROE >= 15% every year:** Fail (FY2022 dipped to 12.9%, below our 15% threshold).
2. **Owner earnings positive every year:** Not known (input missing because capital spending was not found).
3. **Owner earnings grew from first year to last:** Not known (input missing because capital spending was not found).

### 4. Verdict & Recommendation
**Verdict: Watch it.**  
We cannot judge owner earnings for JPMorgan Chase under our standard industrial owner-earnings formula. While Jamie Dimon runs a premier institution with strong accounting returns, banks operate with high leverage, and our quantitative filters strictly flag missing capital expenditure data as not known rather than guessing. We keep it on our watch list.

---
**Your Decision:**  
*I agree with placing JPM on 'Watch it' because financial institutions cannot be assessed with standard owner-earnings cash flows, and missing 10-K tags must strictly yield 'not known' rather than fabricated estimates.*
