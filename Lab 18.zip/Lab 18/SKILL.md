---
name: buffett-investor
description: Warren Buffett legend investor skill. Downloads SEC EDGAR 10-K facts keyless, extracts the last 5 fiscal years of Revenue, Net Income, Operating Cash Flow, CapEx, Equity, ROE, and Owner Earnings with XBRL tags, evaluates Buffett's 3 checks in code, and writes a business evaluation memo (own, watch, or pass) using only code-computed numbers.
---

# Warren Buffett Legend Investor Skill

This skill operationalizes Warren Buffett's fundamental business evaluation philosophy. 
It enforces strict separation between computation and judgment:
- **Code computes every number** directly from official SEC EDGAR 10-K filings.
- **The model only judges** the business quality, economic moat, and management durability using strictly the printed numbers.

## Data Rules & Integrity Guardrails

1. **Filings**: 10-K only; last 5 fiscal years, labeled by fiscal-year-end date.
2. **Flows**: Revenue, Net income, Operating cash flow, and Capital spending require a 1-year flow period (~365 days).
3. **Latest Filing Wins**: If the same period appears across multiple 10-Ks, the latest filed date takes precedence.
4. **Tags**:
   - Revenue: `RevenueFromContractWithCustomerExcludingAssessedTax`, then fallback to `Revenues`.
   - Net Income: `NetIncomeLoss`.
   - Operating Cash Flow: `NetCashProvidedByUsedInOperatingActivities`.
   - Capital Spending: `PaymentsToAcquirePropertyPlantAndEquipment`, then fallback to `PaymentsToAcquireProductiveAssets`.
   - Equity: `StockholdersEquity`.
5. **Formulas**:
   - ROE = Net Income ÷ Year-End Stockholders' Equity.
   - Owner Earnings = Operating Cash Flow − Capital Spending.
6. **Integrity Rules**:
   - Any value not found prints `"not found"` — never an estimate or synthetic approximation.
   - If Equity is zero or negative, ROE is `"not known"`.
   - Any check with a missing input evaluates to `"not known"`.

## Buffett's Three Core Code Checks

The bundled Python script evaluates three non-negotiable quantitative filters in code:
1. **ROE of 15% or more every year** (`pass` / `fail` / `not known`)
2. **Owner earnings positive every year** (`pass` / `fail` / `not known`)
3. **Owner earnings grew, first year to last** (`pass` / `fail` / `not known`)

## Step-by-Step Workflow

### Step 1: Run the Metrics Extraction Script
Run the bundled script for the target ticker:
```bash
python3 scripts/buffett_metrics.py <TICKER>
```
The script contacts SEC EDGAR keyless with a compliant `User-Agent` header, parses company facts XBRL data, and outputs the 5-year table, tags used, and the 3 checks.

### Step 2: Formulate Buffett's Judgment
As Warren Buffett, evaluate the business quality based on:
1. **Circle of Competence & Business Simplicity**: Does the company sell a product or service that people understand and need?
2. **Economic Moat**: Durable competitive advantage (switching costs, low-cost producer, brand loyalty, scale advantages).
3. **Capital Allocation & Owner Earnings**: Did owner earnings expand without diluting equity or requiring excessive leverage?
4. **The Three Checks**: Did the company pass all three quantitative tests?

### Step 3: Write the Investment Memo
Write a concise, decisive internal memo saved as `<TICKER>_buffett_memo.md`.
- **Verdict**: Exactly one of `Own the business`, `Watch it`, or `Pass`.
- **Strict Grounding Rule**: Use **ONLY numbers printed by the script**. Do not cite outside estimates, consensus forecasts, or share prices (no price data this week; judge the business, not the price).
- **Handling Missing Values**: If Capital Spending or Owner Earnings are `"not found"` (such as in banks like JPM), explicitly state that owner earnings cannot be judged under standard industrial accounting.
