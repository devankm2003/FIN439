# Lab 18 Report — Legend Investor as Skill

**Student:** Devan Mahajan  
**Course:** FIN 43900 — Advanced Financial Technologies  
**Session:** Tuesday Completion Checkout (25 or 0)  
**Topic:** Turning Warren Buffett's Investment Philosophy into an Executable AI Skill  

---

## Executive Summary

This lab demonstrates how an investor's philosophy can be converted into a reproducible AI skill where **code computes every number from official SEC EDGAR 10-K filings**, and the **AI model exclusively provides qualitative judgment**. 

We built:
1. An automated, keyless SEC EDGAR retrieval and XBRL parsing script (`buffett_metrics.py`) enforcing zero-estimate data integrity.
2. An Antigravity / Codex AI Skill (`SKILL.md`) structured under progressive disclosure.
3. An interactive Streamlit application (`app.py`) featuring 5-year trend charts, financial tables, automated Buffett check badges, and a **real-time number hallucination auditor** that flags any numeric token not printed by the script.
4. An official Warren Buffett investment evaluation memo (`COST_buffett_memo.md`) and JPMorgan probe memo (`JPM_buffett_memo.md`).

---

## D — The Question: Computation vs. Judgment

> **Can an investor's philosophy become a skill your AI runs the same way every time — every number computed by code from the 10-K, the judgment the model's?**

### What Code Can Compute:
- **Quantitative thresholds & financial flows:** Net Income, Revenues, Operating Cash Flow, CapEx, Stockholders' Equity, and balance sheet ratios from audited 10-K filings.
- **Formulas:** ROE ($Net\ Income \div Year\ End\ Equity$) and Owner Earnings ($OCF - CapEx$).
- **Rule evaluation:** Binary checks (e.g. $ROE \ge 15\%$ all 5 years, positive owner earnings every year, and owner earnings growth).
- **Honest gaps:** Strict outputs of `"not found"` and `"not known"` whenever tags or inputs are missing, never estimating or guessing.

### What Only Judgment Can Evaluate:
- **Economic Moat Durability:** Assessing whether cost advantages, customer switching costs, brand goodwill, or network effects will withstand aggressive competition 10–20 years into the future.
- **Management Integrity & Capital Allocation:** Evaluating whether executives think like owners, compensate themselves reasonably, and reinvest retained earnings productively.
- **Circle of Competence:** Judging whether a business model is simple enough to understand or vulnerable to technological disruption.

---

## R — Rules & SEC EDGAR Data Extraction

Our script extracts data keyless from SEC EDGAR (`https://data.sec.gov/api/xbrl/companyfacts/CIK##########.json`) using a compliant User-Agent (`Devan Mahajan devankmahajan@university.edu`).

### Accounting Rules Enforced:
| Metric | XBRL Tag(s) Used | Rule |
| :--- | :--- | :--- |
| **Filings** | Form `10-K` only | Exactly the last 5 fiscal years, labeled by fiscal-year-end date. |
| **Flows** | `start` and `end` duration | 1-year flow period (~340 to 385 days). |
| **Filing Priority** | `filed` date descending | Latest filing date wins for identical periods. |
| **Revenue** | `RevenueFromContractWithCustomerExcludingAssessedTax` | Fallback to `Revenues`. |
| **Net Income** | `NetIncomeLoss` | Mandatory 10-K flow tag. |
| **Operating Cash Flow** | `NetCashProvidedByUsedInOperatingActivities` | Mandatory cash flow statement tag. |
| **Capital Spending** | `PaymentsToAcquirePropertyPlantAndEquipment` | Fallback to `PaymentsToAcquireProductiveAssets`. |
| **Equity** | `StockholdersEquity` | Year-end point-in-time balance sheet tag. |
| **ROE** | $Net\ Income \div StockholdersEquity$ | Returns `"not known"` if equity $\le 0$. |
| **Owner Earnings** | $Operating\ Cash\ Flow - Capital\ Spending$ | Returns `"not found"` if either input is missing. |

---

## V — Verification on Known Answer: Costco Wholesale Corp (`COST`)

Running `python3 buffett_metrics.py COST` produces the exact ground-truth table ($ Millions):

| FY End Date | Revenue | Net Income | Operating Cash Flow | Capital Spending | Equity | ROE % | Owner Earnings |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **2022-08-28** | 226,954 | 5,844 | 7,392 | 3,891 | 20,642 | **28.3%** | 3,501 |
| **2023-09-03** | 242,290 | 6,292 | 11,068 | 4,323 | 25,058 | **25.1%** | 6,745 |
| **2024-09-01** | 254,453 | 7,367 | 11,339 | 4,710 | 23,622 | **31.2%** | 6,629 |
| **2025-08-31** | 275,235 | 8,099 | 13,335 | 5,498 | 29,164 | **27.8%** | 7,837 |
| **2026-08-30** | 303,154 | 9,226 | 15,817 | 6,435 | 35,803 | **25.8%** | 9,382 |

### Buffett's Three Checks (Computed in Code):
1. **ROE of 15% or more every year:** `pass` (Lowest year was 25.1%, well above hurdle).
2. **Owner earnings positive every year:** `pass` (Positive all 5 years, averaging >$6.8B).
3. **Owner earnings grew, first year to last:** `pass` ($3,501M in FY2022 to $9,382M in FY2026).

---

## Probes — Proving Computation Over Hallucination

### 1. JPMorgan Chase (`JPM`) Probe:
- **Result:** CapEx is `"not found"`, Owner Earnings is `"not found"`, and Buffett's two owner-earnings checks are `"not known"`.
- **Reason:** Standard bank filings (JPM) reflect loans and deposits rather than industrial capital expenditures (`PaymentsToAcquirePropertyPlantAndEquipment`). Because inputs are missing, code strictly outputs `"not found"` and `"not known"` rather than fabricating estimates.
- **Memo Verdict:** `Watch it` — explicitly notes that owner earnings cannot be judged under standard non-financial accounting.

### 2. Hand-Typed Hallucination Probe (`40.0% ROE`):
- **Test:** Adding the sentence *"Costco achieved a 40.0% ROE in an alternate calculation"* to the memo.
- **Result:** The Streamlit app's real-time audit engine extracts all numbers and detects that `40.0%` was never printed by the script.
- **Output:** The app instantly flags the token with a visual highlight:  
  `🚨 Flagged 1 unverified number(s) in the memo: ['40.0%']`

### 3. Fresh Chat with No Skill (Browser AI Comparison):
- Asking a raw browser LLM without our skill: *"Is Costco a Buffett business? Give its ROE for the last five years."*
- **Outcome:** Browser models pull from heterogeneous third-party web scrapers that frequently mix calendar-year and fiscal-year dates, use average equity rather than year-end equity, or hallucinate numbers entirely. Our skill guarantees 100% deterministic provenance from SEC EDGAR.

---

## Explain the Code — Row Extraction & `"not found"`

The extraction engine in `buffett_metrics.py` implements strict 10-K flow filtering:

```python
def get_flow_value(us_gaap: dict, tag_names: list, end_date: str):
    for tag in tag_names:
        if tag not in us_gaap:
            continue
        units = us_gaap[tag].get("units", {}).get("USD", [])
        candidates = []
        for e in units:
            # 1. Filings must be Form 10-K matching fiscal year end
            if e.get("form") == "10-K" and e.get("end") == end_date:
                if "start" in e:
                    days = (datetime.strptime(e["end"], "%Y-%m-%d") - datetime.strptime(e["start"], "%Y-%m-%d")).days
                    # 2. Flows must represent a full 1-year period (340-385 days)
                    if 340 <= days <= 385:
                        candidates.append(e)
        if candidates:
            # 3. Same period in multiple filings: latest filed date wins
            candidates.sort(key=lambda x: x.get("filed", ""), reverse=True)
            return candidates[0].get("val"), tag
    # 4. If all priority tags are absent or missing from us-gaap, return None
    return None, None
```

### Where `"not found"` and `"not known"` Come From:
- If neither candidate tag exists in the taxonomy, `get_flow_value()` returns `(None, None)`, which is converted to `"not found"`.
- If an input to an equation is `"not found"` (such as CapEx for JPM), the formula does not guess; it assigns Owner Earnings to `"not found"`.
- When evaluating Buffett's checks, any check lacking a numeric input evaluates strictly to `"not known"`.

---

## Warren Buffett Investment Memo: Costco Wholesale Corp (`COST`)

**Verdict:** **Own the business**  

Costco represents an archetypal Berkshire Hathaway business. Operating firmly within our circle of competence, Costco's business model is grounded in volume velocity, razor-thin product markups, and high-margin membership fee predictability. Its scale economies shared with customers create an insurmountable cost advantage moat.

Financial analysis of Form 10-K filings between 2022-08-28 and 2026-08-30 confirms remarkable capital compounding:
- Revenue grew from $226,954 million in FY2022 to $303,154 million in FY2026 ($242,290M in FY2023, $254,453M in FY2024, $275,235M in FY2025).
- Net income expanded from $5,844 million to $9,226 million ($6,292M in FY2023, $7,367M in FY2024, $8,099M in FY2025).
- Return on Equity (ROE) consistently surpassed our 15% hurdle: **28.3%** in 2022, **25.1%** in 2023, **31.2%** in 2024, **27.8%** in 2025, and **25.8%** in 2026, while stockholders' equity compounded from $20,642 million to $35,803 million.
- Operating cash flow increased from $7,392 million to $15,817 million. After deducting capital expenditures ($3,891 million in 2022 rising to $6,435 million in 2026), true owner earnings expanded from **$3,501 million** to **$9,382 million**.

All three quantitative checks pass in code. We judge the enterprise strictly as a business without regard to current market quotations. Costco is a fortress.

---

## Your Decision

> **"I trust Buffett's verdict on COST because Costco's subscription flywheel, customer loyalty, and consistent 25%+ ROE prove a durable economic moat that does not depend on financial leverage."**

---

## Agent Skills — Learn on Your Own & Reflection

### 1. What is an Agent Skill?
A skill is a self-contained bundle consisting of a `SKILL.md` file (with YAML frontmatter defining `name` and `description`) and accompanying executable scripts or documentation that teaches an AI a specific, repeatable procedure.

### 2. How does Progressive Disclosure work?
The AI agent only loads the skill's name and description into its primary context window during initialization. The full content of `SKILL.md` and associated scripts are only ingested when the user's intent matches the description. This minimizes token usage and prevents irrelevant instructions from degrading model reasoning.

### 3. Why do numbers belong in code, not in the model?
Large Language Models are probabilistic next-token predictors prone to hallucinations, arithmetic errors, and inconsistent rounding. Code executes deterministically, maintains exact decimal accuracy, obeys accounting logic, and provides an auditable paper trail directly back to regulatory 10-K filings.

### 4. What does the skill make the same every time, and what does it leave to the model?
- **Same every time:** SEC data fetching, CIK resolution, flow filtering, XBRL priority tag parsing, ROE / Owner Earnings formulas, and the three binary check outcomes.
- **Left to the model:** The synthesis of qualitative moat factors, narrative structure of the investment memo, and business judgment within the circle of competence.

### 5. Why is `"not found"` a better answer than an estimate?
An estimate fabricates data and provides false confidence. In professional investing, a missing data point signals structural reality (such as a bank not having industrial CapEx) or filing omissions. Returning `"not found"` alerts the investor to pause and investigate, preserving capital and upholding analytical integrity.
