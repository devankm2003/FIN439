#!/usr/bin/env python3
"""
buffett_metrics.py — Lab 18: Legend Investor as Skill
Downloads 10-K facts from SEC EDGAR keyless, extracts the last 5 fiscal years,
computes ROE and Owner Earnings, evaluates Warren Buffett's three core checks in code,
and prints the XBRL tag provenance for every number.
"""

import sys
import os
import json
import re
from datetime import datetime
import requests

USER_AGENT = "Devan Mahajan devankmahajan@university.edu"
CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".cache")


def ensure_cache_dir():
    os.makedirs(CACHE_DIR, exist_ok=True)


def get_cik_for_ticker(ticker: str) -> str:
    """Resolve a ticker symbol to a 10-digit zero-padded CIK string."""
    ensure_cache_dir()
    ticker_cache = os.path.join(CACHE_DIR, "company_tickers.json")
    
    data = None
    if os.path.exists(ticker_cache):
        try:
            with open(ticker_cache, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = None

    if not data:
        url = "https://www.sec.gov/files/company_tickers.json"
        headers = {"User-Agent": USER_AGENT}
        resp = requests.get(url, headers=headers, timeout=15)
        resp.raise_for_status()
        data = resp.json()
        with open(ticker_cache, "w", encoding="utf-8") as f:
            json.dump(data, f)

    clean_ticker = ticker.strip().upper()
    for item in data.values():
        if item.get("ticker", "").upper() == clean_ticker:
            cik_int = item.get("cik_str")
            return str(cik_int).zfill(10)

    raise ValueError(f"Ticker '{ticker}' not found in SEC EDGAR directory.")


def get_company_facts(cik: str) -> dict:
    """Fetch company facts JSON from SEC EDGAR for given CIK."""
    ensure_cache_dir()
    facts_cache = os.path.join(CACHE_DIR, f"facts_{cik}.json")
    
    if os.path.exists(facts_cache):
        try:
            with open(facts_cache, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass

    url = f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json"
    headers = {"User-Agent": USER_AGENT}
    resp = requests.get(url, headers=headers, timeout=20)
    resp.raise_for_status()
    facts = resp.json()
    with open(facts_cache, "w", encoding="utf-8") as f:
        json.dump(facts, f)
    return facts


def get_flow_value(us_gaap: dict, tag_names: list, end_date: str):
    """
    Find a 1-year flow value (duration between 340 and 385 days) filed on Form 10-K
    for a specific fiscal year end date. Latest filing date wins.
    Returns (raw_value, tag_used) or (None, None).
    """
    for tag in tag_names:
        if tag not in us_gaap:
            continue
        units = us_gaap[tag].get("units", {}).get("USD", [])
        candidates = []
        for e in units:
            if e.get("form") == "10-K" and e.get("end") == end_date:
                if "start" in e:
                    try:
                        d1 = datetime.strptime(e["start"], "%Y-%m-%d")
                        d2 = datetime.strptime(e["end"], "%Y-%m-%d")
                        days = (d2 - d1).days
                        # 1-year flow period
                        if 340 <= days <= 385:
                            candidates.append(e)
                    except ValueError:
                        continue
        if candidates:
            # Latest filing wins
            candidates.sort(key=lambda x: x.get("filed", ""), reverse=True)
            return candidates[0].get("val"), tag

    return None, None


def get_instant_value(us_gaap: dict, tag_names: list, end_date: str):
    """
    Find a point-in-time balance sheet value filed on Form 10-K for a specific fiscal year end date.
    Latest filing date wins.
    Returns (raw_value, tag_used) or (None, None).
    """
    for tag in tag_names:
        if tag not in us_gaap:
            continue
        units = us_gaap[tag].get("units", {}).get("USD", [])
        candidates = []
        for e in units:
            if e.get("form") == "10-K" and e.get("end") == end_date:
                candidates.append(e)
        if candidates:
            candidates.sort(key=lambda x: x.get("filed", ""), reverse=True)
            return candidates[0].get("val"), tag

    return None, None


def extract_buffett_data(ticker: str) -> dict:
    """
    Extract the last five fiscal years for a ticker according to Buffett rules:
    - Filings: 10-K only; last 5 fiscal years labelled by fiscal-year-end date
    - Flows: revenue, net income, cash flows need a 1-year period
    - Latest filing wins
    - Tags:
      * Revenue: RevenueFromContractWithCustomerExcludingAssessedTax, then Revenues
      * Net income: NetIncomeLoss
      * Operating cash flow: NetCashProvidedByUsedInOperatingActivities
      * Capital spending: PaymentsToAcquirePropertyPlantAndEquipment, then PaymentsToAcquireProductiveAssets
      * Equity: StockholdersEquity
      * ROE: net income ÷ year-end equity
      * Owner earnings: operating cash flow − capital spending
      * A value not found: prints "not found", never an estimate
      * Equity zero or below: ROE is "not known"
      * A check with a missing input: "not known"
    """
    cik = get_cik_for_ticker(ticker)
    facts = get_company_facts(cik)
    entity_name = facts.get("entityName", ticker)
    us_gaap = facts.get("facts", {}).get("us-gaap", {})

    # Determine 10-K fiscal year ends from NetIncomeLoss
    ni_units = us_gaap.get("NetIncomeLoss", {}).get("units", {}).get("USD", [])
    fy_end_dates = set()
    for e in ni_units:
        if e.get("form") == "10-K" and "start" in e and "end" in e:
            try:
                d1 = datetime.strptime(e["start"], "%Y-%m-%d")
                d2 = datetime.strptime(e["end"], "%Y-%m-%d")
                if 340 <= (d2 - d1).days <= 385:
                    fy_end_dates.add(e["end"])
            except ValueError:
                pass

    if not fy_end_dates:
        # Fallback to Revenues if NetIncomeLoss not present
        rev_units = us_gaap.get("Revenues", {}).get("units", {}).get("USD", [])
        for e in rev_units:
            if e.get("form") == "10-K" and "start" in e and "end" in e:
                try:
                    d1 = datetime.strptime(e["start"], "%Y-%m-%d")
                    d2 = datetime.strptime(e["end"], "%Y-%m-%d")
                    if 340 <= (d2 - d1).days <= 385:
                        fy_end_dates.add(e["end"])
                except ValueError:
                    pass

    sorted_dates = sorted(list(fy_end_dates))
    last_5_dates = sorted_dates[-5:]

    rows = []
    used_tags = {}

    for dt in last_5_dates:
        rev_val, rev_tag = get_flow_value(
            us_gaap,
            ["RevenueFromContractWithCustomerExcludingAssessedTax", "Revenues"],
            dt
        )
        ni_val, ni_tag = get_flow_value(us_gaap, ["NetIncomeLoss"], dt)
        ocf_val, ocf_tag = get_flow_value(
            us_gaap, ["NetCashProvidedByUsedInOperatingActivities"], dt
        )
        capex_val, capex_tag = get_flow_value(
            us_gaap,
            ["PaymentsToAcquirePropertyPlantAndEquipment", "PaymentsToAcquireProductiveAssets"],
            dt
        )
        eq_val, eq_tag = get_instant_value(us_gaap, ["StockholdersEquity"], dt)

        # Record tags used
        used_tags["Revenue"] = rev_tag or "not found"
        used_tags["Net Income"] = ni_tag or "not found"
        used_tags["Operating Cash Flow"] = ocf_tag or "not found"
        used_tags["Capital Spending"] = capex_tag or "not found"
        used_tags["Equity"] = eq_tag or "not found"

        # ROE calculation: net income ÷ year-end equity
        # Rule: Equity zero or below -> ROE is "not known"
        if eq_val is None or ni_val is None:
            roe = "not known"
        elif eq_val <= 0:
            roe = "not known"
        else:
            roe = (ni_val / eq_val) * 100.0

        # Owner earnings: operating cash flow - capital spending
        if ocf_val is None or capex_val is None:
            owner_earnings = "not found"
        else:
            owner_earnings = ocf_val - capex_val

        rows.append({
            "end_date": dt,
            "revenue": rev_val,
            "net_income": ni_val,
            "operating_cash_flow": ocf_val,
            "capital_spending": capex_val,
            "equity": eq_val,
            "roe": roe,
            "owner_earnings": owner_earnings,
            "tags": {
                "revenue": rev_tag,
                "net_income": ni_tag,
                "operating_cash_flow": ocf_tag,
                "capital_spending": capex_tag,
                "equity": eq_tag
            }
        })

    # Evaluate Buffett's Three Checks in Code
    # Check 1: ROE of 15% or more every year
    roe_check = "pass"
    for r in rows:
        val = r["roe"]
        if val == "not known":
            roe_check = "not known"
            break
        elif isinstance(val, (int, float)):
            if val < 15.0:
                roe_check = "fail"
                break
        else:
            roe_check = "not known"
            break

    # Check 2: Owner earnings positive every year
    oe_positive_check = "pass"
    for r in rows:
        val = r["owner_earnings"]
        if val == "not found":
            oe_positive_check = "not known"
            break
        elif isinstance(val, (int, float)):
            if val <= 0:
                oe_positive_check = "fail"
                break
        else:
            oe_positive_check = "not known"
            break

    # Check 3: Owner earnings grew, first year to last
    oe_grew_check = "pass"
    if len(rows) < 2:
        oe_grew_check = "not known"
    else:
        first_oe = rows[0]["owner_earnings"]
        last_oe = rows[-1]["owner_earnings"]
        if first_oe == "not found" or last_oe == "not found":
            oe_grew_check = "not known"
        elif isinstance(first_oe, (int, float)) and isinstance(last_oe, (int, float)):
            if last_oe > first_oe:
                oe_grew_check = "pass"
            else:
                oe_grew_check = "fail"
        else:
            oe_grew_check = "not known"

    checks = {
        "roe_above_15_all_years": roe_check,
        "owner_earnings_positive_all_years": oe_positive_check,
        "owner_earnings_grew_first_to_last": oe_grew_check
    }

    return {
        "ticker": ticker.upper(),
        "entity_name": entity_name,
        "cik": cik,
        "rows": rows,
        "tags": used_tags,
        "checks": checks
    }


def format_table(data: dict) -> str:
    """Format the extracted 5 fiscal years into a clean ASCII table ($ Millions)."""
    rows = data["rows"]
    lines = []
    lines.append(f"{data['ticker']} ({data['entity_name']}), $ millions:")
    header = f"{'FY end':<12} | {'Revenue':<9} | {'Net income':<10} | {'Operating cash flow':<20} | {'Capital spending':<16} | {'Equity':<8} | {'ROE %':<6} | {'Owner earnings':<14}"
    sep = "-" * len(header)
    lines.append(header)
    lines.append(sep)

    for r in rows:
        def fmt(val):
            if val is None or val == "not found":
                return "not found"
            if isinstance(val, (int, float)):
                return f"{val / 1e6:,.0f}"
            return str(val)

        roe_str = f"{r['roe']:.1f}" if isinstance(r['roe'], (int, float)) else str(r['roe'])

        line = (
            f"{r['end_date']:<12} | "
            f"{fmt(r['revenue']):>9} | "
            f"{fmt(r['net_income']):>10} | "
            f"{fmt(r['operating_cash_flow']):>20} | "
            f"{fmt(r['capital_spending']):>16} | "
            f"{fmt(r['equity']):>8} | "
            f"{roe_str:>6} | "
            f"{fmt(r['owner_earnings']):>14}"
        )
        lines.append(line)

    lines.append("")
    lines.append("XBRL Tags Used:")
    for metric, tag in data["tags"].items():
        lines.append(f"  - {metric}: {tag}")

    lines.append("")
    lines.append("Buffett's Checks:")
    c = data["checks"]
    lines.append(f"  - ROE of 15% or more every year:        {c['roe_above_15_all_years']}")
    lines.append(f"  - Owner earnings positive every year:    {c['owner_earnings_positive_all_years']}")
    lines.append(f"  - Owner earnings grew, first year to last: {c['owner_earnings_grew_first_to_last']}")

    return "\n".join(lines)


def get_allowed_printed_numbers(data: dict) -> set:
    """
    Collect all numbers printed by the script to audit against hallucinations in the memo.
    Includes integer and 1-decimal versions, raw values, values in millions, dates, and check constants.
    """
    allowed = set()
    # Structural constants
    allowed.update({3, 5, 10, 15})  # 3 checks, 5 years, 10-K, 15% ROE hurdle

    for r in data["rows"]:
        # Dates: year, month, day
        try:
            parts = r["end_date"].split("-")
            for p in parts:
                allowed.add(int(p))
                allowed.add(float(p))
        except Exception:
            pass

        # Raw & millions for numeric flows
        for field in ["revenue", "net_income", "operating_cash_flow", "capital_spending", "equity", "owner_earnings"]:
            val = r[field]
            if isinstance(val, (int, float)):
                millions_int = int(round(val / 1e6))
                millions_flt = round(val / 1e6, 1)
                allowed.add(millions_int)
                allowed.add(millions_flt)
                allowed.add(int(val))

        # ROE
        roe = r["roe"]
        if isinstance(roe, (int, float)):
            allowed.add(round(roe, 1))
            allowed.add(round(roe, 2))
            allowed.add(int(round(roe)))

    return allowed


if __name__ == "__main__":
    ticker = sys.argv[1] if len(sys.argv) > 1 else "COST"
    res = extract_buffett_data(ticker)
    print(format_table(res))
