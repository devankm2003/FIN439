# Warren Buffett Investment Memo: Costco Wholesale Corp (COST)

**To:** Berkshire Hathaway Investment Committee  
**From:** Warren E. Buffett  
**Date:** FY2026 Review  
**Subject:** Evaluation of Costco Wholesale Corp (COST)  
**Verdict:** Own the business  

---

### 1. Circle of Competence & Economic Moat
Costco is a business Charlie and I have admired for decades. It fits squarely in the center of our circle of competence. Their model is simplicity itself: sell high-quality merchandise in bulk at the lowest possible markups, cultivate an intensely loyal membership base that pays upfront annual fees, and treat suppliers and employees with scrupulous fairness. 

The moat is built on extreme scale and cost discipline. Costco shares its economies of scale directly with customers rather than pocketing them as excess margin. A competitor could spend tens of billions trying to replicate their distribution network and warehouse footprint, but they cannot replicate the customer trust and volume velocity that keeps unit costs below everyone else in the industry.

### 2. Financial Strength & Earnings Power (10-K Facts)
Looking at the five fiscal years from 2022-08-28 through 2026-08-30, every figure confirms a business compounding capital at exceptional rates:

- **Revenue Growth:** Revenue expanded from $226,954 million in FY2022 to $303,154 million in FY2026 ($242,290 million in FY2023, $254,453 million in FY2024, and $275,235 million in FY2025). This top-line expansion was entirely organic and cash-generative.
- **Net Income:** Profit rose steadily from $5,844 million in FY2022 to $9,226 million in FY2026 ($6,292 million in FY2023, $7,367 million in FY2024, and $8,099 million in FY2025).
- **Return on Equity (ROE):** Our hurdle is 15% across all years. Costco delivered:
  - FY2022: 28.3%
  - FY2023: 25.1%
  - FY2024: 31.2%
  - FY2025: 27.8%
  - FY2026: 25.8%
  Year-end stockholders' equity grew from $20,642 million to $35,803 million ($25,058 million in FY2023, $23,622 million in FY2024, and $29,164 million in FY2025).
- **Owner Earnings:** Operating cash flow grew from $7,392 million to $15,817 million ($11,068 million in FY2023, $11,339 million in FY2024, and $13,335 million in FY2025). After deducting capital spending for warehouse expansion ($3,891 million in FY2022, $4,323 million in FY2023, $4,710 million in FY2024, $5,498 million in FY2025, and $6,435 million in FY2026), true owner earnings were:
  - FY2022: $3,501 million
  - FY2023: $6,745 million
  - FY2024: $6,629 million
  - FY2025: $7,837 million
  - FY2026: $9,382 million

### 3. Quantitative Verification
The three non-negotiable checks evaluated by our code:
1. **ROE >= 15% every year:** Pass (lowest year was 25.1%, far above hurdle).
2. **Owner earnings positive every year:** Pass (positive in all 5 years).
3. **Owner earnings grew from first year to last:** Pass (compounded from $3,501 million to $9,382 million).

### 4. Verdict & Recommendation
**Verdict: Own the business.**  
Costco is an American retail masterpiece. We judge only the business today, not its market quotation. Operationally, Costco possesses durable pricing power, high capital turnover, and an unassailable customer moat. If given the opportunity to own this entire enterprise, we would do so without hesitation.

---
**Your Decision:**  
*I trust Buffett's verdict on COST because Costco's subscription flywheel, customer loyalty, and consistent 25%+ ROE prove a durable economic moat that does not depend on financial leverage.*
