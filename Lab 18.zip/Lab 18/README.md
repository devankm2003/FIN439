# Lab 18 — Legend Investor as Skill

**Antigravity / VS Code Project**  
Project Location: `/Users/devankmahajan/.gemini/antigravity/scratch/lab18-legend-investor`

## Overview
This project turns Warren Buffett's investment philosophy into an executable **AI Skill** and an interactive **Streamlit application**.
- **Code computes every number** directly from SEC EDGAR 10-K filings using XBRL tags (keyless, zero estimates).
- **The model only judges** the qualitative business moat, management durability, and circle of competence.

---

## Quick Start

### 1. Run the Buffett Metrics CLI Script
```bash
cd /Users/devankmahajan/.gemini/antigravity/scratch/lab18-legend-investor

# Test Costco (COST)
python3 buffett_metrics.py COST

# Test JPMorgan Chase (JPM)
python3 buffett_metrics.py JPM
```

### 2. Launch the Streamlit App
```bash
streamlit run app.py --server.port 8502
```
Then open `http://localhost:8502` in your browser.

---

## File Structure
- `buffett_metrics.py`: Fetches SEC EDGAR 10-K company facts, extracts 5 fiscal years, computes ROE & Owner Earnings, evaluates Buffett's 3 checks, and outputs XBRL tag provenance.
- `app.py`: Streamlit dashboard showing:
  - Subtitle: `data from SEC EDGAR; built with AI help, a learning demonstration, not investment advice.`
  - 5-year trend chart of Owner Earnings and Net Income.
  - 5-year financials table with XBRL tag inspector.
  - Buffett's 3 quantitative checks.
  - Interactive Buffett Memo with **real-time number hallucination detection**.
  - One-click buttons to test the JPM probe and the 40.0% ROE probe.
- `skills/buffett-investor/SKILL.md`: The formalized AI skill with YAML frontmatter.
- `.agents/skills/buffett-investor/SKILL.md`: Workspace-discovered skill path.
- `~/.gemini/config/skills/buffett-investor/SKILL.md`: Global config skill path.
- `COST_buffett_memo.md`: Buffett investment memo for Costco (verdict: Own the business).
- `JPM_buffett_memo.md`: Buffett investment memo for JPMorgan (verdict: Watch it).
