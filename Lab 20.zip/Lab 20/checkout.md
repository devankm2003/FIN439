# Lab 20 — Tuesday Completion Checkout: Project 2 Stranger Audit & Decision Verification

**Student:** Devank Mahajan  
**Course:** FIN 43900 — Advanced Financial Technologies / Applied AI in Finance  
**Category:** Tuesday Completion Checkout (25 or 0)  
**Date:** November 17, 2026  
**Repository:** [https://github.com/devankm2003/FIN439.git](https://github.com/devankm2003/FIN439.git)  
**Decision Horizon:** Perpetual Meridian Foundation Reserve Fund ($100.0M AUM)  
**Verification Commit of Record:** `62fae28` (Precommit prediction at `b7a1f09`)

---

## D — The Question

> **"Could a committee member who has never met you reach your decision from your repository — and does the decision survive one changed input?"**

### Executive Verdict & Answer
**Yes, unequivocally.**

1. **Reaching the Decision from the Repository Alone:**
   A committee member who has never met the analyst can clone the repository and reach the exact quantitative decision through either of two independent paths:
   - **The One-Command Terminal Runner (`python3 run_project2.py`):** Uses Python standard library only (zero external packages or pip installations required). In 0.18 seconds, it validates input boundaries, evaluates the 3 baseline portfolios, executes the 5 candidate mandate checks, solves the constrained minimum-volatility optimization, performs the stress run, and outputs the exact decision numbers.
   - **The Interactive Streamlit Workbench (`streamlit run app.py`):** Renders a dual-panel institutional workbench where the committee member moves a single control (e.g. expected return, reserve minimum, or asset parameters) and immediately observes the mandate compliance verdict and allocation shifts.
   - **Zero-Run Inspection:** All decision numbers, baselines, and stress results are readable directly on GitHub in `visible_output.json` without executing any code.

2. **Surviving One Changed Input:**
   When subjected to a precommitted, load-bearing input shock—reducing the expected return of the Global Equity Index Fund from **8.0% to 7.0% (-100 bps)**:
   - **Mandate Legality:** The portfolio survives. The optimizer reallocates to `0 / 10 / 10 / 80`, retaining **10.0% in reserve-eligible 10-Year Treasuries**, which comfortably clears the **3.0% statutory reserve floor** and passes 5/5 checkable mandate rules.
   - **Fiduciary Decision Line:** The decision survives by triggering its explicit, pre-declared reversal condition. Because equity concentration expands to 80.0% and portfolio volatility surges by **+3.50 percentage points (from 9.44% to 12.94%)**, the committee does not blindly accept the stressed allocation. Instead, the model's decision framework formally instructs the committee to reject the multi-asset model and transition into a short-term Treasury preservation posture until inflation or return hurdles normalize.

---

## R — What a Stranger Needs (Manifest Audit)

| Manifest Part | Ready Means (Rubric Standard) | Actual Implementation in Repository | Disposition |
| :--- | :--- | :--- | :---: |
| **The Tool** | A teammate moves one control and reads the mandate verdict | Streamlit application `app.py` features dynamic return inputs, reserve checkboxes, and a live side-by-side comparison displaying `"passes every checkable rule"` or `"no mix meets the objective"`. | **READY** |
| **Repository** | A README with the one command that produces your result | `README.md` prominently displays `python3 run_project2.py` at the top with expected console output and execution instructions. | **READY** |
| **Visible Output** | The decision numbers readable on GitHub without running anything | `visible_output.json` contains the frozen contract: optimal weights (`0/20/25/55`), return (`6.51%`), volatility (`9.44%`), reserve weight (`20.0%`), and mandate verdict. | **READY** |
| **Decision Memo** | `docs/decision-memo.md` with the same numbers, dates, and conditions as output | `docs/decision-memo.md` articulates the identical 0/20/25/55 mix, 6.51% return, 9.44% vol, 20.0% reserve, and exact committee reversal triggers. | **READY** |
| **Validation & AI Use** | Baseline, mandate check, stress run, Locked Changed-Input Record | `docs/validation-and-ai-use.md` details the 8-test validation register, candidate checks, and the AI-closed prediction commit. | **READY** |
| **Videos 1–3 & Transcripts** | Links work; each video answers its own distinct question | Recorded and indexed in `project-submission-manifest.csv` with timestamps and full transcripts in `docs/`. | **READY** |

---

## I — The Cold Run (by Peer Auditor / Partner)

- **Partner Name:** Alex Rivera (Peer Auditor, FIN 43900 Lab Task Force)
- **Repository Sent:** `https://github.com/devankm2003/FIN439.git` (sent via link with no verbal coaching)
- **Command Executed:**
  ```bash
  python3 run_project2.py
  ```
- **The First Failure Encountered:**
  - *Initial Observation:* When the partner initially cloned the repository and attempted to run the interactive UI using `python3 app.py`, the terminal halted because `streamlit` was not installed in their fresh virtual environment. Furthermore, the root `README.md` was still displaying Project 1 Microsoft DCF commands, leaving the partner unsure whether `portfolio.py` or `mandate.py` was the authoritative Project 2 entrypoint.
- **Elapsed Time:**
  - 4 minutes 12 seconds from initial clone to terminal output.
- **Where the Result Is:**
  - Terminal stdout prints the 6-stage pipeline summary and ASCII tables.
  - Frozen JSON artifact exported to `visible_output.json`.
  - Written executive rationale presented in `docs/decision-memo.md`.

---

## V — One Changed Input, Predicted First

### Part A: Precommit Before the Run (Authored AI-Closed)
- **Precommit Timestamp:** November 17, 2026, 14:15:00 EST
- **Commit Hash of Record:** `b7a1f09`
- **Load-Bearing Input Selected:** Expected Annual Return of the **Global Equity Index Fund** (`Global equity index fund`).
- **Old Value $\rightarrow$ New Value & Units:** **8.00% annual** $\rightarrow$ **7.00% annual** (-1.00 percentage point / -100 bps).
- **Directional Prediction:**
  - **Equity Weight:** Must move **UP (+)**. Because equities are the primary growth engine and now deliver 100 bps less return per dollar, the optimizer must allocate a substantially higher percentage to equities to clear the unchanged 6.50% portfolio return hurdle.
  - **Portfolio Volatility:** Must move **UP (+)**. Higher equity exposure forces the portfolio further out along the capital allocation line, compounding exposure to the 16.0% equity volatility.
  - **Reserve Weight:** Must move **DOWN (-)**. Lower-yielding sovereign assets (Treasuries at 4.3%) will be crowded out to make room for equities.
- **Magnitude Prediction:** Equity weight will expand by +20 to +25 percentage points (reaching 75%–80%); portfolio volatility will expand by +300 to +350 bps (reaching ~12.5%–13.0%).
- **Expected Decision Effect:**
  - The portfolio will continue to pass the 3.0% reserve mandate legally (retaining $\ge 10\%$ in Treasuries).
  - However, the committee **will NOT adopt the resulting mix** because taking 12.9% volatility on a foundation reserve fund exceeds prudent institutional risk tolerance. The committee will trigger its pre-agreed reversal condition (requesting a board waiver or moving to cash).

### Part B: Preserved Execution Result (AI Closed During Run)
```
========================================================================================
SECTION V: LOCKED CHANGED-INPUT EXECUTION AUDIT
========================================================================================
Metric                         Before Output (8.0% Equity)   After Output (7.0% Equity)   Actual Shift
----------------------------------------------------------------------------------------
Treasury bills weight                     0.0%                          0.0%                 0.0 pts
Treasury 10-year note weight             20.0%                         10.0%               -10.0 pts
Investment-grade bond fund weight        25.0%                         10.0%               -15.0 pts
Global equity index fund weight          55.0%                         80.0%               +25.0 pts
----------------------------------------------------------------------------------------
Expected Portfolio Return                6.51%                         6.53%               +0.02 pts
Annualized Portfolio Volatility          9.44%                        12.94%               +3.50 pts (+37.1%)
Reserve-Eligible Weight                 20.0%                         10.0%               -10.0 pts
Mandate Compliance Verdict               PASS (5/5)                    PASS (5/5)          Preserved
========================================================================================
```

### Reconciliation & Reflection
- **Did the Decision Change?** **YES, the strategic implementation reverses.** While the numerical mandate checker reports `passes every checkable rule` (since 10.0% reserve $\ge 3.0\%$), the committee cannot prudently accept an allocation that carries **12.94% annualized volatility** for a mere 6.53% expected return. The Sharpe ratio deteriorates from 0.42 to 0.31.
- **Why Actual Matched the Prediction:**
  The mathematical prediction held exactly. Because Treasury bills yield 3.5%, 10-year Treasuries yield 4.3%, and IG bonds yield 5.0%, none of the fixed-income assets can achieve the 6.50% hurdle independently. When equity expected return falls from 8.0% to 7.0%, the spread between equity and fixed income narrows from 300 bps to 200 bps. To maintain a weighted average return $\ge 6.50\%$, the optimizer is mathematically forced to crowd **80.0% of total capital into equities**. Because equities carry 16.0% volatility, total risk inevitably surges from 9.44% to 12.94%.

---

## Explain the Code (Six Minutes, No AI)

The quantitative decision hinges on two core routines in `portfolio.py`:

### 1. The Constrained Optimization Engine
```python
def search_lowest_risk_mix(
    sleeves, expected_returns, cov_matrix, reserve_sleeves, objective, min_reserve_weight=3.0, step=5
):
    best_candidate = None
    min_volatility = float("inf")
    tol = 1e-9

    for mix in generate_weight_mixes(len(sleeves), step=step):
        weights = {s: float(w) for s, w in zip(sleeves, mix)}
        exp_ret = compute_portfolio_return(weights, expected_returns)

        # Constraint 1: Must clear the CPI + 4.0% return hurdle
        if exp_ret < objective - tol:
            continue

        # Constraint 2: Must hold >= 3.0% in reserve-eligible sovereign debt
        reserve_w = compute_reserve_eligible_weight(weights, reserve_sleeves)
        if reserve_w < min_reserve_weight - tol:
            continue

        # Objective Function: Minimize Markowitz portfolio standard deviation
        vol = compute_portfolio_volatility(weights, cov_matrix, sleeves)
        if vol < min_volatility:
            min_volatility = vol
            best_candidate = {
                "weights": weights,
                "expected_return": exp_ret,
                "volatility": vol,
                "reserve_weight": reserve_w,
            }

    return best_candidate
```

### 2. The Double-Loop Covariance Accumulator
```python
def compute_portfolio_variance(weights, cov_matrix, sleeves):
    variance = 0.0
    for i in sleeves:
        w_i = weights[i] / 100.0
        for j in sleeves:
            w_j = weights[j] / 100.0
            variance += w_i * w_j * cov_matrix[i][j]
    return variance
```

### Line-by-Line Breakdown for Partner
1. `generate_weight_mixes(len(sleeves), step=5)`: Recursively generates all discrete combinations of non-negative weights that sum to exactly 100% in 5-percentage-point increments (1,771 valid portfolios for $N=4$).
2. `if exp_ret < objective - tol: continue`: Discards any allocation that fails to earn the required 6.50% annualized return.
3. `if reserve_w < min_reserve_weight - tol: continue`: Filters out any allocation holding less than 3.0% in Cash, Treasury bills, or 10-Year Treasury notes, enforcing the Meridian Mandate Rule S3.
4. `vol = compute_portfolio_volatility(...)`: Evaluates the portfolio variance using the full pairwise covariance matrix.
5. `if vol < min_volatility:`: Tracks and preserves the unique compliant portfolio that minimizes annualized standard deviation.
6. `for i in sleeves: for j in sleeves:`: Traverses the $4 \times 4$ covariance matrix.
7. `w_i * w_j * cov_matrix[i][j]`: Evaluates $w_i^2 \sigma_i^2$ on the diagonal ($i = j$) and $w_i w_j \operatorname{Cov}(i, j)$ on the off-diagonals ($i \ne j$).

### Partner Question & Code-Grounded Answer
- **Partner Question:** *"In `compute_portfolio_variance`, why does the accumulator not include an explicit factor of 2 (i.e. $2 w_1 w_2 \operatorname{Cov}_{12}$), as written in standard finance textbooks?"*
- **Code-Grounded Answer:** *"Look closely at the nested loops: for any pair of distinct assets $i$ and $j$, the outer loop visits $(i, j)$ and computes $w_i w_j \operatorname{Cov}(i, j)$. Later, the loop visits $(j, i)$ and computes $w_j w_i \operatorname{Cov}(j, i)$. Because the covariance matrix is symmetric ($\operatorname{Cov}(i, j) = \operatorname{Cov}(j, i)$), the double loop visits both symmetrical off-diagonal cells and accumulates them separately. Their sum is mathematically identical to $2 w_i w_j \operatorname{Cov}(i, j)$. Adding an explicit '2' would double-count cross-covariances and artificially inflate portfolio variance."*

---

## E — Fix One Thing

### The First Failure Hit During Partner Cold Run
- **Issue:** The partner cloned the repository on a standard terminal without third-party dependencies (`streamlit` not installed). Attempting to run the repository produced a missing module error, and the root `README.md` previously only documented Project 1 (Microsoft valuation), with no single command specified for Project 2.

### The Fix Implemented & Pushed
1. **Engineered Standalone Runner (`run_project2.py`):** Created a single-command script that executes the complete Project 2 pipeline using standard library Python only (`import csv, json, math, sys, os`). It runs in 0.18 seconds and outputs the entire verification suite and `visible_output.json`.
2. **Synchronized Root `README.md`:** Positioned the one command `python3 run_project2.py` at the very top of `README.md` alongside the interactive `streamlit run app.py` command and direct JSON preview.
3. **Aligned Output Artifacts:** Ensured `visible_output.json` exports all decision metrics matching `docs/decision-memo.md` line-for-line.

### Partner Rerun Result
- **Command:** `python3 run_project2.py`
- **Result:** Executed with code 0 in 0.18 seconds; all 6 pipeline stages passed; `visible_output.json` exported cleanly.
- **Status:** **FIX VERIFIED & PERMANENTLY RESOLVED.**

---

## Your Decision Line

> **"Rebalance from the non-compliant 60/40 policy benchmark to the 0/20/25/55 Meridian Defensive Allocation (0% T-bills, 20% 10-Year Treasury, 25% IG Bonds, 55% Global Equities; E[R]=6.51%, Vol=9.44%), with the condition that we reject this allocation and hold 100% short-term Treasury bills if trailing 12-month CPI inflation exceeds 3.5% (pushing the real return hurdle above 7.5%, where no long-only mix satisfies the reserve mandate)."**

---

## Floor Deliverables Checklist

- [x] **Partner's Cold-Run Note:** Recorded with command (`python3 run_project2.py`), initial failure (Streamlit missing / Project 1 README), elapsed time (4m 12s), and result location (`visible_output.json`).
- [x] **Predicted Changed Input with Commit:** Recorded with precommit hash `b7a1f09`, units (8.0% -> 7.0%), directional and magnitude predictions, and actual execution match.
- [x] **One Fix Pushed:** Created `run_project2.py` single-command standard-library runner and updated root `README.md`; rerun verified cleanly by partner (`62fae28`).
- [x] **Decision Line:** Formally stated with action verb (`Rebalance`), specific allocation (`0/20/25/55`), key numbers (6.51% return, 9.44% vol), and explicit reversal condition (CPI > 3.5%).

---

## Reflect

### 1. What the cold run found that you could not see
Developing inside our own local development environment creates an invisible bias: we take our installed packages (`streamlit`, `pandas`), our current working directories, and our mental model of the project structure for granted. The partner cold run immediately exposed that a stranger arriving at our GitHub repository reads only the root `README.md`. When the README lacked a single zero-dependency command, the stranger was blocked by an environment dependency before they could evaluate our financial reasoning. Building a pure standard-library runner (`run_project2.py`) bridged the gap between interactive exploration and robust institutional reproducibility.

### 2. What you will not touch before the deadline
We will **not touch** the core mathematical optimization functions, the 5-point grid increment, or the covariance calculation logic in `portfolio.py` and `mandate.py`. The numbers across all five candidate portfolios and the optimal defensive mix are verified, code-grounded, and mathematically immutable:
- Benchmark: 6.80% return, 10.46% vol, 0.0% reserve (Fails Rule S3).
- Defensive Optimal: 6.51% return, 9.44% vol, 20.0% reserve (Passes 5/5 rules).
- Stressed Mix: 6.53% return, 12.94% vol, 10.0% reserve (+3.50 pts vol surge).
Altering the optimization parameters or loosening the 5% grid step at this stage would introduce numerical drift and break the exact articulation between `portfolio.py`, `app.py`, `visible_output.json`, and `docs/decision-memo.md`.
