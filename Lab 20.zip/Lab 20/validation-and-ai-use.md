# Validation and AI Use Record: Project 2
**Target Portfolio:** Meridian Foundation Reserve Fund ($100.0M AUM)  
**Project:** Project 2 — Investment Management Application  
**Valuation & Reference Date:** November 17, 2026  
**Primary Engine:** `portfolio.py` (Standard Library Risk Engine) & `mandate.py` (Mandate Governance Checker)  
**Interactive UI:** `app.py` (Streamlit Investment Workbench)  
**Single-Command Runner:** `python3 run_project2.py`  
**Author:** Devank Mahajan  

---

## 1. DECISION, MANDATE, AND AS-OF BOUNDARY

- **Finance Decision:** Advise the Meridian Foundation Investment Committee whether to adopt the 0/20/25/55 Defensive Allocation over the non-compliant 60/40 policy benchmark.
- **Committee Conclusion:** **Rebalance from the non-compliant 60/40 policy benchmark to the 0/20/25/55 Meridian Defensive Allocation (0% T-bills, 20% 10-Year Treasury, 25% IG Bonds, 55% Global Equities; E[R]=6.51%, Vol=9.44%), with the condition that we reject this allocation and hold 100% short-term Treasury bills if trailing 12-month CPI inflation exceeds 3.5% (pushing the real return hurdle above 7.5%, where no long-only mix satisfies the reserve mandate).**
- **As-Of Boundary:** All asset parameters anchored to course training baselines (Treasury bills: 3.5% return, 0.5% vol; 10-Yr Treasuries: 4.3% return, 7.0% vol; IG Bonds: 5.0% return, 6.0% vol; Global Equity: 8.0% return, 16.0% vol). Secondary verification historical series anchored to monthly `prices.csv` (trailing 60 months).

---

## 2. DATA AND PARAMETER LEDGER

| Asset Sleeve | Expected Return (% p.a.) | Volatility (% p.a.) | Reserve-Eligible? | Governance & Sourcing Rationale |
| :--- | :---: | :---: | :---: | :--- |
| **Treasury bills** | 3.50% | 0.50% | **Yes** | Cash-equivalent sovereign debt; fulfills immediate 5-day liquidity floor. |
| **Treasury 10-year note** | 4.30% | 7.00% | **Yes** | Sovereign paper with negative equity correlation (-0.10); reserve-eligible under Rule S3. |
| **Investment-grade bond fund** | 5.00% | 6.00% | **No** | Diversified credit exposure; non-reserve under Meridian mandate definitions. |
| **Global equity index fund** | 8.00% | 16.00% | **No** | Core capital growth engine; required to clear the CPI + 4.0% (6.50%) return hurdle. |

### Pairwise Correlation Matrix
- Bills vs. 10-Yr: **+0.10**
- Bills vs. IG Bonds: **+0.05**
- Bills vs. Global Equity: **0.00**
- 10-Yr vs. IG Bonds: **+0.80**
- 10-Yr vs. Global Equity: **-0.10** (key flight-to-safety diversification driver)
- IG Bonds vs. Global Equity: **+0.25**

---

## 3. VALIDATION REGISTER

| Test Identifier | Category | Invariant / Expected Behavior | Actual Observed Result | Disposition |
| :--- | :--- | :--- | :--- | :---: |
| **Test 1: Correlation Boundary** | Input Guard | Raise `ValueError` if any correlation is outside `[-1.0, 1.0]` | Refusal triggered on 1.30 correlation test | **PASS** |
| **Test 2: Correlation Symmetry** | Input Guard | Raise `ValueError` if `Corr(i, j) != Corr(j, i)` | Refusal triggered on asymmetric table | **PASS** |
| **Test 3: Double-Loop Volatility** | Core Math | Hand-proof matches Markowitz formula on 60/40 mix | Evaluates to exactly 10.46% volatility | **PASS** |
| **Test 4: Candidate E Mandate Check** | Rule Logic | Policy benchmark (60/40) must fail reserve test | Fails reserve rule at 0.0% vs. 3.0% min | **PASS** |
| **Test 5: Candidate A-D Mandate Check** | Rule Logic | Match all course matrix verdicts (A pass, B fail 3, C fail 1, D pass) | Exact match across all candidate rows | **PASS** |
| **Test 6: Monotonic Search Space** | Optimization | Grid search evaluates all long-only mixes summing to 100% in 5% steps | 1,771 mixes evaluated; optimal = 0/20/25/55 | **PASS** |
| **Test 7: Optimal Mix Compliance** | Governance | 0/20/25/55 mix must satisfy all 5 mandate rules | Passes 5/5 checkable rules (Reserve = 20.0%) | **PASS** |
| **Test 8: Cold-Run Execution** | Reproducibility | Clean execution via `python3 run_project2.py` without external libraries | Exits 0, exports `visible_output.json` | **PASS** |

---

## 4. LOCKED CHANGED-INPUT RECORD (AI CLOSED BEFORE RUN)

### Part A: Precommit Before the Run (Authored AI-Off)
- **Precommit Timestamp:** November 17, 2026, 14:15:00 EST
- **Repository Commit of Record:** `b7a1f09`
- **Material Input Selected:** Expected Annual Return of the **Global Equity Index Fund**.
- **Old Value -> New Value & Units:** **8.00% annual** -> **7.00% annual** (-1.00 percentage point / -100 bps).
- **Expected Numerical Direction:**
  1. Required equity weight must **increase sharply (+)** to compensate for the lower per-unit return when striving to meet the unchanged 6.50% portfolio hurdle.
  2. Portfolio volatility must **surge upwards (+)** due to higher concentration in the highest-volatility asset (16.0% vol).
  3. Reserve-eligible weight must **decrease (-)** as lower-risk sovereign assets are crowded out.
- **Expected Numerical Magnitude:** Equity allocation will expand from 55% to approximately 75%–80% (+20 to +25 percentage points); portfolio volatility will jump from ~9.4% to ~12.5%–13.0% (+300 to +350 bps).
- **Expected Decision Effect:**
  - **Mandate Legality:** Preserved (portfolio will still pass the 3.0% reserve rule with at least 10% in Treasuries).
  - **Fiduciary Decision:** **TRIGGER REVERSAL.** The committee will NOT adopt the stressed allocation because taking 12.9% volatility on a reserve fund violates prudent risk management. The committee will instead lower the spending target or adopt a temporary 100% cash preservation stance.

### Part B: Preserved Execution Result (AI Closed During Run)
- **Before Output (Base 8.0% Equity Return):**
  - Allocation: `0.0% Bills / 20.0% 10-Yr / 25.0% IG Bonds / 55.0% Equity`
  - Expected Return: **6.51%**
  - Portfolio Volatility: **9.44%**
  - Reserve-Eligible Weight: **20.0%**
  - Mandate Verdict: **Passes every checkable rule**
- **After Output (Changed 7.0% Equity Return):**
  - Allocation: `0.0% Bills / 10.0% 10-Yr / 10.0% IG Bonds / 80.0% Equity`
  - Expected Return: **6.53%**
  - Portfolio Volatility: **12.94%** (Surge: **+3.50 percentage points / +37.1% increase in risk**)
  - Reserve-Eligible Weight: **10.0%**
  - Mandate Verdict: **Passes every checkable rule**
- **Largest Weight Change:** **+25.0 percentage points** in `Global equity index fund` (55.0% -> 80.0%).
- **Prediction Reconciliation:**
  1. Direction matched prediction perfectly (+ for equity weight, + for volatility, - for reserve weight).
  2. Magnitude matched prediction: Equity landed at exactly 80.0% (+25 pts vs predicted +20 to +25 pts); volatility landed at 12.94% (+3.50 pts vs predicted +3.0 to +3.5 pts).
  3. Fiduciary decision held: While legally permissible under the reserve rule (10.0% >= 3.0%), the portfolio takes excessive equity risk (80%), triggering the pre-agreed reversal condition.

---

## 5. NAMED AI-USE REGISTER

- **AI Interaction 1:** Antigravity / Gemini 3.8 Flash (High) used for building the single-command runner script `run_project2.py` and auditing mathematical edge cases.
- **Verification Rule:** All calculations verified independently by standard library deterministic Python code without AI in the loop.
