# Investment Committee Decision Memorandum: Project 2
**Target Portfolio:** Meridian Foundation Reserve Fund ($100.0M AUM)  
**Security Sleeves:** U.S. Treasury Bills, 10-Year Treasury Notes, Investment-Grade Corporate Bonds, Global Equities  
**Reference / Vintage Date:** November 17, 2026 | **Governance Framework:** Meridian Foundation Reserve Mandate  
**Author:** Devank Mahajan, Portfolio Strategy Task Force  

---

## 1. Recommendation and Committee Action Line
> **"Rebalance from the non-compliant 60/40 policy benchmark to the 0/20/25/55 Meridian Defensive Allocation (0% T-bills, 20% 10-Year Treasury, 25% IG Bonds, 55% Global Equities; E[R]=6.51%, Vol=9.44%), with the condition that we reject this allocation and hold 100% short-term Treasury bills if trailing 12-month CPI inflation exceeds 3.5% (pushing the real return hurdle above 7.5%, where no long-only mix satisfies the reserve mandate)."**

---

## 2. Core Mandate Discrepancy & Executive Context

### The Policy Benchmark Dilemma
The Meridian Foundation Board historically designated a conventional **60/40 Policy Benchmark** (40% Investment-Grade Bonds, 60% Global Equities; Candidate E). When evaluated against the Foundation's own Investment Policy Statement (IPS), **this benchmark fails the Foundation's legal mandate**:
- **Return Objective:** Earns **6.80%**, clearing the CPI (2.50%) + 4.00% = **6.50%** real return target.
- **Reserve Mandate Rule:** Holds **0.0%** in reserve-eligible instruments (Cash, T-bills, or 10-Year Treasuries), violating the **3.0% minimum liquidity reserve** required to guarantee four quarters of distributions ($0.75M/quarter on a $100M reserve).
- **Mandate Verdict:** **`FAILS 1 RULE`**. The client's policy benchmark violates the client's own investment rules.

### The Evaluated Baseline Universe
| Portfolio Mix | Allocation (Bills / 10-Yr / IG / Equity) | Expected Return (% p.a.) | Volatility (% p.a.) | Reserve Weight (%) | Mandate Compliance Status |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **Benchmark (60/40)** | `0.0 / 0.0 / 40.0 / 60.0` | **6.80%** | **10.46%** | **0.0%** | **FAILS** (Reserve rule breach: 0.0% < 3.0%) |
| **Equal Weight (25/25/25/25)** | `25.0 / 25.0 / 25.0 / 25.0` | **5.20%** | **5.21%** | **50.0%** | **FAILS** (Return hurdle missed: 5.20% < 6.50%) |
| **Inverse Volatility Parity** | `84.3 / 6.0 / 7.0 / 2.6` | **3.77%** | **1.05%** | **90.3%** | **FAILS** (Return hurdle missed: 3.77% < 6.50%) |
| **Meridian Defensive (Optimal)** | `0.0 / 20.0 / 25.0 / 55.0` | **6.51%** | **9.44%** | **20.0%** | **PASSES EVERY CHECKABLE RULE** |

---

## 3. The Recommended Decision Portfolio: Meridian Defensive (0/20/25/55)

The constrained minimum-volatility optimization engine solves for the unique long-only allocation that achieves both the required return and the liquidity floor with lowest variance:
- **Treasury Bills:** **0.0%** ($0.0M)
- **Treasury 10-Year Notes:** **20.0%** ($20.0M)
- **Investment-Grade Corporate Bonds:** **25.0%** ($25.0M)
- **Global Equity Index Fund:** **55.0%** ($55.0M)

### Key Performance & Mandate Metrics
1. **Expected Annual Return:** **6.51%** (Clears the 6.50% hurdle with +1 basis point buffer).
2. **Annualized Portfolio Volatility:** **9.44%** (Achieves a **-102 bps volatility reduction** versus the 60/40 benchmark's 10.46% risk profile, saving 9.8% of portfolio variance).
3. **Reserve-Eligible Weight:** **20.0%** (Exceeds the 3.0% statutory floor by 6.67x, providing $20.0M of sovereign liquidity capable of funding 26 quarters of spending distributions without forced asset sales).
4. **5-Day Liquidity:** **100.0%** (Well above the 90.0% threshold).
5. **Single Corporate Issuer Exposure:** **0.0%** (Exposures are diversified funds and U.S. sovereign debt; well below the 8.0% cap).

---

## 4. Sensitivity to Changed Inputs (Stress Test & Reversal Condition)

### Load-Bearing Input: Global Equity Expected Return
- **Baseline Estimate:** **8.0%** annual return.
- **Stressed Estimate:** **7.0%** annual return (-100 bps shift).
- **Optimization Reaction:**
  - Optimal weights shift to `0.0 / 10.0 / 10.0 / 80.0`.
  - Global Equity allocation increases by **+25.0 percentage points** (from 55% to 80%) to compensate for lower per-unit returns.
  - Volatility surges from **9.44% to 12.94% (+3.50 percentage points / +37.1% increase in risk)**.
  - Reserve-eligible weight drops to **10.0%** (still compliant with $\ge 3.0\%$).

### Strategic Governance Verdict
While the 0/10/10/80 mix remains legally compliant with the 3.0% reserve rule, **it is unacceptable from a fiduciary risk-budgeting perspective**. A 12.94% volatility profile for an endowment reserve fund subjects the institution to severe equity drawdown risk.

### Formal Reversal Conditions
1. **Inflation Spike (Hurdle Ratchet):** If trailing 12-month CPI exceeds **3.5%** (raising the required return above **7.5%**), no long-only mix can achieve the target without exceeding 70% equity exposure. Under this condition, the committee must reject the multi-asset model and place the fund into a **100% short-term Treasury preservation stance** until inflation normalizes.
2. **Equity Return Degradation:** If forward equity capital market assumptions drop below **7.5%**, the CIO must request a formal board waiver to lower the endowment's 4.0% real payout hurdle rather than levering up equity risk to 80%.
