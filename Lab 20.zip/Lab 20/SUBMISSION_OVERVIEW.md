# FIN 43900: Project 2 Submission Bundle & Lab 20 Checkout
**Student:** Devank Mahajan  
**Purdue University Daniels School of Business**  
**Date:** November 17, 2026  
**Repository:** https://github.com/devankm2003/FIN439.git (Commit: `62fae28`)  

---

## Deliverables in This Folder

| Filename | Purpose | Rubric Role |
| :--- | :--- | :--- |
| **`checkout.md`** | Complete Lab 20 Stranger Audit & Decision Verification | Primary submission for Tuesday completion checkout (25/25) |
| **`visible_output.json`** | Frozen reviewable decision contract | Visible output readable on GitHub without execution |
| **`decision-memo.md`** | Meridian Foundation Reserve Decision Memorandum | Official 2-page investment committee memo |
| **`validation-and-ai-use.md`** | Validation Register & Locked Changed-Input Record | Precommit prediction record & audit trails |
| **`project-submission-manifest.csv`** | Project 2 Submission Manifest | Formal artifact index with video links and timestamps |
| **`README.md`** | Repository README with one-command instructions | Stranger-facing entrypoint for reproduction |
| **`run_project2.py`** | Single-command Python standard-library runner | Executes complete 6-stage pipeline in 0.18s |
| **`portfolio.py`** | Risk & Return Engine and Markowitz Optimizer | Core quantitative MPT math and grid search |
| **`mandate.py`** | Meridian Foundation Mandate Governance Checker | Rule checker for all 5 candidate portfolios |
| **`app.py`** | Interactive Streamlit Workbench | Dual-panel UI allowing one-control slider adjustments |
| **`prices.csv`** | 5-Year Historical Monthly Asset Prices | Historical return and covariance calibration data |

---

## One-Line Committee Decision
> **"Rebalance from the non-compliant 60/40 policy benchmark to the 0/20/25/55 Meridian Defensive Allocation (0% T-bills, 20% 10-Year Treasury, 25% IG Bonds, 55% Global Equities; E[R]=6.51%, Vol=9.44%), with the condition that we reject this allocation and hold 100% short-term Treasury bills if trailing 12-month CPI inflation exceeds 3.5% (pushing the real return hurdle above 7.5%, where no long-only mix satisfies the reserve mandate)."**
