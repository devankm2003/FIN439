# FIN439: Applied Financial Decision Systems
**Devank Mahajan | Purdue University Daniels School of Business**

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![Decision: Rebalance to Defensive](https://img.shields.io/badge/decision-REBALANCE%20TO%200%2F20%2F25%2F55-green.svg)](decision-memo.md)
[![Mandate Compliance: 5/5 Passing](https://img.shields.io/badge/mandate-5%2F5%20PASSING-brightgreen.svg)](mandate.py)

---

## Project 2 — Investment Management Application
### Meridian Foundation Reserve Fund Portfolio Optimization & Mandate Checker

### The One Command to Produce the Result
To reproduce the complete quantitative decision, evaluate all candidate portfolios, execute the stress run, and export the frozen decision contract with zero third-party dependencies:
```bash
python3 run_project2.py
```

### The Interactive Streamlit Workbench (Move One Control)
To launch the interactive asset allocation UI where a committee member can move any slider/input and immediately read the mandate verdict and allocation shifts:
```bash
streamlit run app.py
```
*(If Streamlit is not installed, install it with `pip install streamlit` or use the standard-library runner above).*

---

### 1. The Committee Decision Line
> **"Rebalance from the non-compliant 60/40 policy benchmark to the 0/20/25/55 Meridian Defensive Allocation (0% T-bills, 20% 10-Year Treasury, 25% IG Bonds, 55% Global Equities; E[R]=6.51%, Vol=9.44%), with the condition that we reject this allocation and hold 100% short-term Treasury bills if trailing 12-month CPI inflation exceeds 3.5% (pushing the real return hurdle above 7.5%, where no long-only mix satisfies the reserve mandate)."**

---

### 2. Visible Result (Inspection on GitHub Without Execution)
The verified decision numbers, baseline evaluations, mandate checks, and stress results are exported to [`visible_output.json`](visible_output.json):

```json
{
  "project": "Project 2 — Investment Management Application",
  "entity": "Meridian Foundation Reserve Fund",
  "mandate_governance": {
    "reserve_size_usd_m": 100.0,
    "quarterly_distribution_usd_m": 0.75,
    "quarters_to_cover": 4,
    "reserve_minimum_floor_pct": 3.0,
    "liquidity_window_days": 5,
    "min_liquid_share_pct": 90.0,
    "single_issuer_cap_pct": 8.0,
    "return_objective_pct": 6.5
  },
  "optimal_decision_portfolio": {
    "name": "Meridian Defensive Allocation",
    "weights": {
      "Treasury bills": 0.0,
      "Treasury 10-year note": 20.0,
      "Investment-grade bond fund": 25.0,
      "Global equity index fund": 55.0
    },
    "expected_return": 6.51,
    "volatility": 9.44,
    "reserve_weight": 20.0,
    "mandate_compliance": {
      "weights_sum_to_100": true,
      "long_only": true,
      "reserve_ge_3pct": true,
      "liquid_5days_ge_90pct": true,
      "single_company_le_8pct": true,
      "verdict": "passes every checkable rule"
    }
  },
  "locked_changed_input_record": {
    "parameter": "Global equity index fund expected return",
    "old_value": "8.0% annual",
    "new_value": "7.0% annual",
    "largest_weight_change": {
      "asset": "Global equity index fund",
      "old_weight": 55.0,
      "new_weight": 80.0,
      "delta_points": 25.0
    },
    "volatility_surge": 3.5,
    "mandate_status_preserved": true
  }
}
```

---

### 3. Baseline Portfolio and Mandate Summary
| Portfolio Candidate | Allocation (Bills / 10-Yr / IG / Equity) | Return (% p.a.) | Volatility (% p.a.) | Reserve Weight (%) | Mandate Compliance Verdict |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **Benchmark (Candidate E)** | `0.0 / 0.0 / 40.0 / 60.0` | **6.80%** | **10.46%** | **0.0%** | **FAILS 1 RULE** (Reserve rule breach: 0.0% < 3.0%) |
| **Equal Weight (25/25/25/25)** | `25.0 / 25.0 / 25.0 / 25.0` | **5.20%** | **5.21%** | **50.0%** | **FAILS** (Return hurdle missed: 5.20% < 6.50%) |
| **Inverse Volatility Parity** | `84.3 / 6.0 / 7.0 / 2.6` | **3.77%** | **1.05%** | **90.3%** | **FAILS** (Return hurdle missed: 3.77% < 6.50%) |
| **Meridian Defensive (Optimal)** | `0.0 / 20.0 / 25.0 / 55.0` | **6.51%** | **9.44%** | **20.0%** | **PASSES EVERY CHECKABLE RULE** |

---

### 4. Key Documentation Links
- **Decision Memorandum:** [`decision-memo.md`](decision-memo.md)
- **Validation & AI Use Record:** [`validation-and-ai-use.md`](validation-and-ai-use.md)
- **Mandate Governance Engine:** [`mandate.py`](mandate.py)
- **Portfolio Risk & Return Engine:** [`portfolio.py`](portfolio.py)
- **Streamlit Interactive UI:** [`app.py`](app.py)
- **Single-Command Verification Runner:** [`run_project2.py`](run_project2.py)
- **Stranger Audit & Lab 20 Checkout:** [`checkout.md`](checkout.md)
