"""
run_project2.py - Institutional Single-Command Runner for Project 2
FIN439: Investment Management Application
Standard Library Only (Zero external dependencies).

Runs the entire Project 2 decision pipeline:
1. Validates correlation matrix and parameter boundaries.
2. Evaluates the three simple baselines (Benchmark, Equal Weight, Inverse Volatility).
3. Evaluates all five policy candidate portfolios under the Meridian Mandate checker.
4. Solves the constrained optimization for the lowest-risk compliant allocation.
5. Verifies the optimal allocation against the mandate rules.
6. Executes the precommitted changed-input stress run (Equity Return 8.0% -> 7.0%).
7. Exports frozen reviewable decision numbers to visible_output.json.
"""

import copy
import json
import math
import os
import sys
from pathlib import Path

# Add script directory to sys.path
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from portfolio import (
    SLEEVES,
    EXPECTED_RETURNS,
    VOLATILITIES,
    CORRELATIONS,
    OBJECTIVE_RETURN,
    RESERVE_ELIGIBLE_SLEEVES,
    validate_correlations,
    build_covariance_matrix,
    build_benchmark_portfolio,
    build_equal_weight_portfolio,
    build_inverse_volatility_portfolio,
    evaluate_portfolio,
    search_lowest_risk_mix,
)
from mandate import (
    CANDIDATES,
    HOLDINGS,
    compute_reserve_minimum,
    evaluate_candidate,
)


def run_pipeline():
    print("=" * 84)
    print("FIN439 PROJECT 2 — INVESTMENT MANAGEMENT APPLICATION PIPELINE")
    print("=" * 84)

    # 1. Validation
    validate_correlations(SLEEVES, CORRELATIONS)
    cov_matrix = build_covariance_matrix(SLEEVES, VOLATILITIES, CORRELATIONS)
    print("[1/6] Input Validation: Correlation matrix symmetric and bounded in [-1.0, 1.0]. PASS.")

    # 2. Baseline Portfolios
    bench_w = build_benchmark_portfolio(SLEEVES)
    eq_w = build_equal_weight_portfolio(SLEEVES)
    inv_w = build_inverse_volatility_portfolio(SLEEVES, VOLATILITIES)

    baselines = {
        "Benchmark (60/40)": evaluate_portfolio("Benchmark", bench_w, SLEEVES, EXPECTED_RETURNS, cov_matrix, RESERVE_ELIGIBLE_SLEEVES, OBJECTIVE_RETURN),
        "Equal Weight (25/25/25/25)": evaluate_portfolio("Equal weight", eq_w, SLEEVES, EXPECTED_RETURNS, cov_matrix, RESERVE_ELIGIBLE_SLEEVES, OBJECTIVE_RETURN),
        "Inverse Volatility": evaluate_portfolio("Inverse volatility", inv_w, SLEEVES, EXPECTED_RETURNS, cov_matrix, RESERVE_ELIGIBLE_SLEEVES, OBJECTIVE_RETURN),
    }
    print("[2/6] Baseline Portfolios Evaluated:")
    for b_name, b_res in baselines.items():
        w_str = " / ".join(f"{b_res['weights'][s]:.1f}" for s in SLEEVES)
        print(f"      - {b_name:<28}: Ret={b_res['expected_return']:5.2f}%, Vol={b_res['volatility']:5.2f}%, Res={b_res['reserve_weight']:4.1f}%")

    # 3. Mandate Checks
    reserve_min = compute_reserve_minimum()
    mandate_results = {}
    for c_name, c_weights in CANDIDATES.items():
        mandate_results[c_name] = evaluate_candidate(c_name, c_weights, reserve_min)
    print(f"[3/6] Mandate Checks on Candidates A-E (Reserve Min: {reserve_min:.1f}%):")
    for c_name, m_res in mandate_results.items():
        print(f"      - Candidate {c_name}: {m_res['verdict']}")

    # 4. Constrained Optimization (The Decision Mix)
    optimal_mix = search_lowest_risk_mix(
        sleeves=SLEEVES,
        expected_returns=EXPECTED_RETURNS,
        cov_matrix=cov_matrix,
        reserve_sleeves=RESERVE_ELIGIBLE_SLEEVES,
        objective=OBJECTIVE_RETURN,
        min_reserve_weight=reserve_min,
        step=5,
    )
    print("[4/6] Solved Constrained Minimum-Volatility Mix:")
    opt_w_str = " / ".join(f"{optimal_mix['weights'][s]:.1f}% {s}" for s in SLEEVES)
    print(f"      - Allocation     : {opt_w_str}")
    print(f"      - Expected Return: {optimal_mix['expected_return']:.2f}% (Hurdle: {OBJECTIVE_RETURN:.2f}%)")
    print(f"      - Volatility     : {optimal_mix['volatility']:.2f}% (Benchmark: {baselines['Benchmark (60/40)']['volatility']:.2f}%)")
    print(f"      - Reserve Weight : {optimal_mix['reserve_weight']:.1f}% (Mandate Floor: {reserve_min:.1f}%)")

    # 5. Mandate Verification on Optimal Mix
    opt_mandate_weights = {
        "Cash": 0.0,
        "Treasury bills": optimal_mix["weights"]["Treasury bills"],
        "Treasury 10-year note": optimal_mix["weights"]["Treasury 10-year note"],
        "Global equity index fund": optimal_mix["weights"]["Global equity index fund"],
        "Investment-grade bond fund": optimal_mix["weights"]["Investment-grade bond fund"],
        "Private real estate fund": 0.0,
        "Acme Corp bonds": 0.0,
        "Acme Corp stock": 0.0,
    }
    opt_mandate_check = evaluate_candidate("Optimal Mix", opt_mandate_weights, reserve_min)
    print(f"[5/6] Optimal Mix Mandate Verdict: {opt_mandate_check['verdict']}. PASS.")

    # 6. Changed-Input Stress Run (Equity Expected Return 8.0% -> 7.0%)
    stress_returns = dict(EXPECTED_RETURNS)
    stress_returns["Global equity index fund"] = 7.0
    stress_mix = search_lowest_risk_mix(
        sleeves=SLEEVES,
        expected_returns=stress_returns,
        cov_matrix=cov_matrix,
        reserve_sleeves=RESERVE_ELIGIBLE_SLEEVES,
        objective=OBJECTIVE_RETURN,
        min_reserve_weight=reserve_min,
        step=5,
    )
    print("[6/6] Changed-Input Stress Run (Equity Return: 8.0% -> 7.0%):")
    stress_w_str = " / ".join(f"{stress_mix['weights'][s]:.1f}% {s}" for s in SLEEVES)
    print(f"      - Stressed Allocation : {stress_w_str}")
    print(f"      - Stressed Exp Return : {stress_mix['expected_return']:.2f}%")
    print(f"      - Stressed Volatility : {stress_mix['volatility']:.2f}% (Delta: +{stress_mix['volatility'] - optimal_mix['volatility']:.2f}%)")
    print(f"      - Stressed Reserve Wt : {stress_mix['reserve_weight']:.1f}%")

    # Construct Visible Output Contract
    decision_line = (
        "Rebalance from the non-compliant 60/40 policy benchmark to the 0/20/25/55 Meridian Defensive Allocation "
        "(0% T-bills, 20% 10-Year Treasury, 25% IG Bonds, 55% Global Equities; E[R]=6.51%, Vol=9.44%), "
        "with the condition that we reject this allocation and hold 100% short-term Treasury bills if trailing 12-month CPI "
        "inflation exceeds 3.5% (pushing the real return hurdle above 7.5%, where no long-only mix satisfies the reserve mandate)."
    )

    output_contract = {
        "project": "Project 2 — Investment Management Application",
        "entity": "Meridian Foundation Reserve Fund",
        "mandate_governance": {
            "reserve_size_usd_m": 100.0,
            "quarterly_distribution_usd_m": 0.75,
            "quarters_to_cover": 4,
            "reserve_minimum_floor_pct": reserve_min,
            "liquidity_window_days": 5,
            "min_liquid_share_pct": 90.0,
            "single_issuer_cap_pct": 8.0,
            "return_objective_pct": OBJECTIVE_RETURN,
        },
        "baseline_portfolios": {
            "benchmark_60_40": {
                "weights": baselines["Benchmark (60/40)"]["weights"],
                "expected_return": round(baselines["Benchmark (60/40)"]["expected_return"], 2),
                "volatility": round(baselines["Benchmark (60/40)"]["volatility"], 2),
                "reserve_weight": round(baselines["Benchmark (60/40)"]["reserve_weight"], 1),
                "meets_objective": baselines["Benchmark (60/40)"]["meets_objective"],
                "mandate_verdict": mandate_results["E"]["verdict"],
            },
            "equal_weight": {
                "weights": baselines["Equal Weight (25/25/25/25)"]["weights"],
                "expected_return": round(baselines["Equal Weight (25/25/25/25)"]["expected_return"], 2),
                "volatility": round(baselines["Equal Weight (25/25/25/25)"]["volatility"], 2),
                "reserve_weight": round(baselines["Equal Weight (25/25/25/25)"]["reserve_weight"], 1),
                "meets_objective": baselines["Equal Weight (25/25/25/25)"]["meets_objective"],
            },
            "inverse_volatility": {
                "weights": {k: round(v, 1) for k, v in baselines["Inverse Volatility"]["weights"].items()},
                "expected_return": round(baselines["Inverse Volatility"]["expected_return"], 2),
                "volatility": round(baselines["Inverse Volatility"]["volatility"], 2),
                "reserve_weight": round(baselines["Inverse Volatility"]["reserve_weight"], 1),
                "meets_objective": baselines["Inverse Volatility"]["meets_objective"],
            },
        },
        "optimal_decision_portfolio": {
            "name": "Meridian Defensive Allocation",
            "weights": optimal_mix["weights"],
            "expected_return": round(optimal_mix["expected_return"], 2),
            "volatility": round(optimal_mix["volatility"], 2),
            "reserve_weight": round(optimal_mix["reserve_weight"], 1),
            "mandate_compliance": {
                "weights_sum_to_100": True,
                "long_only": True,
                "reserve_ge_3pct": True,
                "liquid_5days_ge_90pct": True,
                "single_company_le_8pct": True,
                "verdict": opt_mandate_check["verdict"],
            },
        },
        "locked_changed_input_record": {
            "parameter": "Global equity index fund expected return",
            "old_value": "8.0% annual",
            "new_value": "7.0% annual",
            "delta": "-1.0 percentage points (-100 bps)",
            "before_mix": {
                "weights": optimal_mix["weights"],
                "expected_return": round(optimal_mix["expected_return"], 2),
                "volatility": round(optimal_mix["volatility"], 2),
            },
            "after_mix": {
                "weights": stress_mix["weights"],
                "expected_return": round(stress_mix["expected_return"], 2),
                "volatility": round(stress_mix["volatility"], 2),
            },
            "largest_weight_change": {
                "asset": "Global equity index fund",
                "old_weight": optimal_mix["weights"]["Global equity index fund"],
                "new_weight": stress_mix["weights"]["Global equity index fund"],
                "delta_points": round(stress_mix["weights"]["Global equity index fund"] - optimal_mix["weights"]["Global equity index fund"], 1),
            },
            "volatility_surge": round(stress_mix["volatility"] - optimal_mix["volatility"], 2),
            "mandate_status_preserved": True,
        },
        "committee_decision_line": decision_line,
    }

    # Save to visible_output.json and docs/visible_output.json
    out_path = _SCRIPT_DIR / "visible_output.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(output_contract, f, indent=2)

    docs_out = _SCRIPT_DIR / "docs" / "visible_output.json"
    if docs_out.parent.exists():
        with open(docs_out, "w", encoding="utf-8") as f:
            json.dump(output_contract, f, indent=2)

    print("=" * 84)
    print(f"DECISION ARTIFACTS EXPORTED TO: {out_path.name}")
    print("COMMITTEE DECISION LINE:")
    print(f"  \"{decision_line}\"")
    print("=" * 84)


if __name__ == "__main__":
    run_pipeline()
