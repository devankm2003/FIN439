# Validation and AI Use Record
Target Entity: Microsoft Corporation (NASDAQ: MSFT, CIK: 0000789019)
Project: Project 1 - Corporate Finance Application
Valuation / Reference Date: September 23, 2026 (Market Close: $500.59)
Primary Filing of Record: Form 10-K for Fiscal Year Ended June 30, 2025 (SEC Accession: 0000950170-25-100235)
Repository State: Frozen at commit v1.0.0-project1-frozen | Cold-Run Verification: python3 run_tests.py (12/12 passing)
Author: Equity Research Analyst

================================================================================
1. DECISION, VERSION, AND AS-OF BOUNDARY
================================================================================

- Finance Decision: Advise Buy-Side Investment Committee whether to initiate an initial position in Microsoft Corporation.
- Committee Conclusion: WATCH / DEFER at $500.59 (Intrinsic DCF range: $246.96 to $449.22; Base: $317.10).
- Point-in-Time Boundary & Why FY2025 10-K is the Base: All market and peer prices frozen as of September 23, 2026, 16:00 EDT. Although FY2026 ended June 30, 2026 (Q4 FY26 earnings release issued July 29, 2026), all fundamental accounting balances remain anchored strictly to Microsoft's audited FY2025 Form 10-K (SEC Accession: 0000950170-25-100235, filed July 30, 2025) so every balance sheet line item and footnote (Notes 4, 7, 8, 10, 12, 18) reconciles identically without mixing unaudited press-release data with audited footnotes. Rolling the base to FY2026 Form 10-K footnotes is scheduled as the next update cycle.

================================================================================
2. DATA AND FINANCIAL CONVENTION LEDGER
================================================================================

Item: Base Revenue
- Audited Source: FY2025 Form 10-K, Item 8, p. 59
- As-Of Date: 2025-06-30
- Accounting Definition & Units: Total GAAP Revenue ($281,724.0M)
- Transformation / Exclusion Treatment: None (Audited Fact). Organic constant-currency growth was +15.0%.
- Financial Risk / Modeling Rationale: Anchor for forward top-line projections.

Item: Gross Margin Percentage
- Audited Source: FY2025 Form 10-K, Item 8, p. 59
- As-Of Date: 2025-06-30
- Accounting Definition & Units: Gross Profit / Revenue (68.8234%)
- Transformation / Exclusion Treatment: Modeled at 68.50% base (32 bps compression).
- Financial Risk / Modeling Rationale: Captures AI datacenter electricity and server depreciation costs.

Item: Cash OpEx (SG&A) Ratio
- Audited Source: FY2025 Form 10-K, Item 8, p. 59
- As-Of Date: 2025-06-30
- Accounting Definition & Units: (R&D + S&M + G&A - Depr) / Gross Profit (22.37%)
- Transformation / Exclusion Treatment: Tapered from 22.5% in FY26 to 21.0% in FY30.
- Financial Risk / Modeling Rationale: Models software operating leverage as revenues scale against fixed OpEx.

Item: Depreciation Ratio
- Audited Source: FY2025 Form 10-K, Note 7, p. 77
- As-Of Date: 2025-06-30
- Accounting Definition & Units: Note 7 PP&E Depr ($22,000M) / Opening Net PP&E ($204,966M) = 10.7335%
- Transformation / Exclusion Treatment: Applied strictly to opening net PP&E each year.
- Financial Risk / Modeling Rationale: Aligns non-cash depreciation to actual physical server and datacenter useful lives.

Item: Annual Cash CapEx
- Audited Source: FY2025 Form 10-K, Item 8, p. 62 & FY26 Guidance
- As-Of Date: 2025-06-30
- Accounting Definition & Units: Additions to property and equipment ($64,551M in FY25)
- Transformation / Exclusion Treatment: Modeled flat at $65,000.0M / yr across FY26E to FY30E.
- Financial Risk / Modeling Rationale: Key load-bearing cash drain; reflects ongoing GPU cluster and datacenter expansion.

Item: Effective Tax Rate
- Audited Source: FY2025 Form 10-K, Note 12, p. 86
- As-Of Date: 2025-06-30
- Accounting Definition & Units: Income taxes ($18,580M) / Pre-tax Income ($110,412M) = 16.83%
- Transformation / Exclusion Treatment: Normalized to 18.00% perpetual rate.
- Financial Risk / Modeling Rationale: Reflects corporate statutory adjustments and global minimum tax standards.

Item: Unearned Revenue Ratio
- Audited Source: FY2025 Form 10-K, Item 8, p. 61
- As-Of Date: 2025-06-30
- Accounting Definition & Units: Short-term unearned revenue ($64,555M) / Revenue ($281,724M) = 22.9143%
- Transformation / Exclusion Treatment: Fixed percentage of forward revenue.
- Financial Risk / Modeling Rationale: Microsoft's enterprise customer float; generates +$8.4B to +$13.7B annual cash inflow.

Item: Operating Cash Floor
- Audited Source: Audited Policy & Working Capital Study
- As-Of Date: 2026-09-23
- Accounting Definition & Units: Minimum liquidity retained for daily operations ($15,000.0M)
- Transformation / Exclusion Treatment: Deducted from total cash ($94,565M) in excess cash bridge ($79,565M).
- Financial Risk / Modeling Rationale: Prevents overstating non-operating liquidity available to equity holders.

Item: Operating Leases (ASC 842)
- Audited Source: FY2025 Form 10-K, Note 8, p. 79
- As-Of Date: 2025-06-30
- Accounting Definition & Units: Operating lease liabilities ($18,485.0M disclosed)
- Transformation / Exclusion Treatment: $0.0M deducted in Enterprise-to-Equity bridge (not subtracted again).
- Financial Risk / Modeling Rationale: Because ASC 842 single operating lease expense is already deducted in EBIT and FCFF, subtracting the $18,485M lease liability in the EV-to-Equity bridge would double-count the obligation.

Item: Total Debt Principal
- Audited Source: FY2025 Form 10-K, Note 10, p. 82
- As-Of Date: 2025-06-30
- Accounting Definition & Units: Current debt ($2,999M) + Long-term debt ($40,152M) = $43,151.0M
- Transformation / Exclusion Treatment: Carrying value matches contractual principal closely; Note 10 fair value is $42.8B.
- Financial Risk / Modeling Rationale: Deducted in bridge; scheduled debt repayment modeled at $3,000M/year.

Item: Diluted Common Shares
- Audited Source: FY2025 Form 10-K, Note 18, p. 94
- As-Of Date: 2025-06-30
- Accounting Definition & Units: Diluted weighted-average common shares (7,465.0M shares)
- Transformation / Exclusion Treatment: Diluted basis strictly used (7,433M basic + 32M dilutive options/awards).
- Financial Risk / Modeling Rationale: Primary denominator for all per-share valuation figures. Cover count (7,434M) excluded.

Item: Cost of Capital (WACC) & Peer Multiples Sourcing
- Audited Source: FRED DGS10 (10-Yr Treasury Yield), S&P Capital IQ / Yahoo Finance (5-Yr Monthly OLS Beta), Damodaran Implied ERP (Sept 2026), and Peer Form 10-Ks (GOOGL FY24 Note 11, ORCL FY25 Note 13, AMZN FY24 Note 10)
- As-Of Date: 2026-09-23 (Market close)
- Accounting Definition & Units: CAPM Ke = 9.50% (Rf 4.25% FRED DGS10 on 2026-09-23 + 1.05 beta on 2026-09-23 x 5.00% Damodaran ERP Sept 2026); Kd after-tax = 3.69%; Peer P/Es: GOOGL 41.09x ($330.39 / $8.04), ORCL 35.24x ($152.94 / $4.34), AMZN 39.91x ($186.40 / $4.67)
- Transformation / Exclusion Treatment: WACC = 9.50% (98.8% equity weight, AAA balance sheet); Peer Median P/E = 39.91x ($544.48/sh).
- Financial Risk / Modeling Rationale: Discount rate for explicit 5-year FCFF projections and dated relative valuation triangulation.

Item: Terminal Growth Rate (g)
- Audited Source: Long-Run Macroeconomic Benchmark
- As-Of Date: 2026-09-23
- Accounting Definition & Units: Nominal GDP long-run growth anchor (3.00%)
- Transformation / Exclusion Treatment: Capped at 3.00% (course rule: company cannot outgrow economy forever).
- Financial Risk / Modeling Rationale: Terminal value Gordon Growth multiplier: (1+g) / (WACC - g).

================================================================================
3. VALIDATION REGISTER
================================================================================

Test: Synthetic Bridge
- Potential Failure Mode: Formula error in EV-to-Equity bridge
- Invariant / Description: Test against known course fixture ($1,000 EV, $100 Cash, $250 Debt, $20 MI, $10 Pension = $8.20/sh)
- Actual Result: Equity = $820.0M, Per-Share = $8.20 | Disposition: PASS | Location: run_tests.py (test_synthetic_bridge_reconciliation)

Test: Training DCF Engine
- Potential Failure Mode: Discounting or terminal value calculation error
- Invariant / Description: Test against known course training DCF ($100 FCFF, 10% WACC, 3% g, 50 shares = $27.50/sh)
- Actual Result: Value per share = $27.50 | Disposition: PASS | Location: run_tests.py (test_training_case_dcf_reconciliation)

Test: Base Year Integrity
- Potential Failure Mode: Typo or discrepancy with audited SEC filing
- Invariant / Description: Reconcile base year balance sheet and income statement line-for-line to Form 10-K
- Actual Result: Base assets = $619,003M, Liab+Eq = $619,003M, Gap = $0.0000M | Disposition: PASS | Location: run_tests.py (test_base_year_reconciliation)

Test: Statement Articulation
- Potential Failure Mode: Balance sheet fails to balance or cash flow does not tie
- Invariant / Description: 5-year roll-forward invariant: Assets = Liab + Equity and Ending Cash = Beginning Cash + Net CF
- Actual Result: Max gap = $0.0000M, Max CF diff = $0.0000M | Disposition: PASS | Location: run_tests.py (test_proforma_statement_articulation)

Test: DCF WACC Monotonicity
- Potential Failure Mode: Discount rate calculation inverted
- Invariant / Description: Verify value per share decreases monotonically as WACC increases (8.5% -> 9.5% -> 10.5%)
- Actual Result: $377.67 -> $317.10 -> $272.78 (Strictly decreasing) | Disposition: PASS | Location: run_tests.py (test_dcf_monotonicity_wacc)

Test: DCF Growth Monotonicity
- Potential Failure Mode: Growth formula inverted
- Invariant / Description: Verify value per share increases monotonically as terminal growth rises (2.0% -> 3.0% -> 4.0%)
- Actual Result: $282.08 -> $317.10 -> $364.85 (Strictly increasing) | Disposition: PASS | Location: run_tests.py (test_dcf_monotonicity_growth)

Test: EV-to-Equity Bridge
- Potential Failure Mode: Omitting $15,000M cash floor or double-counting ASC 842 leases already in EBIT
- Invariant / Description: Line-by-line reconciliation: EV ($2,330,739.8M) + Gross Cash ($94,565.0M) - Operating Floor ($15,000.0M) - Debt ($43,151.0M) - Leases ($0.0M) = Equity ($2,367,153.8M)
- Actual Result: Equity = $2,367,153.8M; Value/Share = $317.10 | Disposition: PASS | Location: run_tests.py (test_enterprise_to_equity_bridge)

Test: Comps Peer Consistency
- Potential Failure Mode: Peer selection bias or multiple distortion
- Invariant / Description: Apply pre-declared peer policy; calculate leave-one-out sensitivity across GOOGL, ORCL, AMZN
- Actual Result: Median P/E = 39.91x; Leave-one-out change <= $35.00/sh | Disposition: PASS | Location: run_tests.py (test_comparable_companies_consistency)

Test: Extreme Solvency Failure
- Potential Failure Mode: Model fails silently when g >= WACC
- Invariant / Description: Pass invalid input g = 8.0% >= WACC = 8.0% to DCF engine
- Actual Result: Engine refuses calculation, raises explicit error message | Disposition: PASS | Location: run_tests.py (test_extreme_solvency_failure)

Test: Distress / Revolver Draw
- Potential Failure Mode: Pro-forma breaks under severe operational distress
- Invariant / Description: Stress test: -5% revenue growth, 60% gross margin, $85B CapEx surge
- Actual Result: Balance sheet balances perfectly; draws $4.5B on revolver | Disposition: PASS | Location: run_tests.py (test_recession_and_revolver_draw)

Test: Cold-Run Integrity
- Potential Failure Mode: Missing dependencies or broken environment
- Invariant / Description: Execute clean run in fresh process without cached memory
- Actual Result: Full analysis completes, exports visible_output.json | Disposition: PASS | Location: run_tests.py (test_cold_run_execution)

================================================================================
4. LOCKED CHANGED-INPUT RECORD - FCFF HEADLINE DECISION-BOUNDARY TEST
================================================================================

Part A: Precommit Prediction Before Execution
- Commit / Tag Reference: v1.1.0-project1-reconciled (author-recorded precommit prediction before running the updated FCFF locked test)
- Material Input Selected: Organic Revenue Growth Rate across all five forecast years (FY2026E to FY2030E), evaluated directly on the headline FCFF DCF Valuation per Diluted Share.
- Old Value -> New Value & Units: 13.00% / yr -> 22.00% / yr (+9.00 percentage points / +900 bps per year, exceeding the 21.58% Reverse-DCF market hurdle).
- Expected Output Direction: Positive (+). Sustained acceleration past the Reverse-DCF hurdle compounds 5-year EBIT, FCFF, and Terminal Value above the current market price.
- Expected Numerical Magnitude: FCFF intrinsic value per share will rise by roughly +$185.00 to +$205.00 per share (from $317.10/sh to ~$505-$520/sh).
- Expected Decision Effect: FLIPS RECOMMENDATION from WATCH / DEFER to INITIATE BUY because intrinsic FCFF value per share crosses above the $500.59 market price.

Part B: Preserved Execution Result
- Before Output (Base 13.00% Growth): Intrinsic FCFF Value per Share = $317.10 (Equity = $2,367,153.8M; Decision = WATCH / DEFER).
- After Output (Changed 22.00% Growth): Intrinsic FCFF Value per Share = $510.92 (Decision = INITIATE BUY).
- Actual Numerical Change: +$193.82 per share (+61.1%) on the headline FCFF valuation ($510.92 - $317.10 = +$193.82 exactly).
- Actual Decision Effect: Recommendation FLIPS from WATCH / DEFER to INITIATE BUY (+$10.33/sh, or +2.1% above the $500.59 market price).
- Prediction Reconciliation:
  1. Direction was strictly positive (+).
  2. Numerical increase (+$193.82/sh) fell squarely within the precommitted prediction band (+$185 to +$205/sh) and reconciles identically ($510.92 - $317.10 = +$193.82).
  3. Decision flip confirmed: crossing the 21.58% Reverse-DCF hurdle flips the committee call from WATCH / DEFER to INITIATE BUY.
- Evidence Verification Path: run_tests.py, method test_locked_changed_input_record, and visible_output.json["locked_changed_input"].

================================================================================
5. NAMED AI-USE REGISTER
================================================================================

AI Interaction 1: Claude 3.5 Sonnet / Codex
- Date: 2026-09-15 | Material Task: Scaffolding 3-statement pro-forma balance sheet roll-forward logic.
- AI Claim Considered: Suggested adapting an auto dealership model using "Floor Plan Debt" as the core working capital line.
- Human Audit Check: Checked Microsoft Form 10-K Item 8 Balance Sheet; discovered Microsoft carries $0 floor plan debt, but carries $64,555M in Short-Term Unearned Revenue.
- Disposition: REJECTED floor plan debt; REPLACED with Microsoft-specific Unearned Revenue Float engine (22.9143% of rev).
- Decision Effect: Crucial: unlocked +$8.4B to +$13.7B in annual positive cash inflows that fund AI CapEx.

AI Interaction 2: OpenAI GPT-4o
- Date: 2026-09-17 | Material Task: Comparable company peer candidates for relative valuation.
- AI Claim Considered: Proposed Nvidia (NVDA), Apple (AAPL), and Alphabet (GOOGL).
- Human Audit Check: Audited against pre-declared Peer Policy requiring enterprise commercial cloud (IaaS/PaaS) and enterprise SaaS recurring revenue.
- Disposition: REJECTED Nvidia (pure semiconductor hardware) and Apple (consumer hardware OEM); QUALIFIED Alphabet and Oracle; added Amazon (AWS).
- Decision Effect: Prevented multiple distortion from hardware margins; stabilized peer median P/E at 39.91x.

AI Interaction 3: Gemini 1.5 Pro
- Date: 2026-09-20 | Material Task: Bisection search algorithm for Reverse DCF solving target price.
- AI Claim Considered: Provided Python bisection search function with default search bracket [-5.0%, +10.0%].
- Human Audit Check: Executed script against $500.59 market price; model returned no solution because +10% bracket maxed out at $326.11/share.
- Disposition: MODIFIED search bracket to [-10.0%, +35.0%], allowing convergence at +8.58 percentage points (21.58% growth).
- Decision Effect: Proved market price demands unprecedented 21.58% compound organic growth through 2030.

AI Interaction 4: Codex / Streamlit CLI
- Date: 2026-09-22 | Material Task: Frontend layout for interactive driver panel.
- AI Claim Considered: Generated bare linear sliders with unbounded ranges (-50% to +100%).
- Human Audit Check: Audited against 10-year historical SEC filings: Microsoft has never grown constant-currency revenue above 18% at this scale.
- Disposition: QUALIFIED and bounded sliders (Growth capped at 18.0%, Margin capped at 72.0%, CapEx bounded at $45B-$80B).
- Decision Effect: Created semi-adjustable workbench meeting Requirement 10; prevented unmade decisions.

================================================================================
6. LIMITATIONS, MONITORING, AND ESCALATION RULES
================================================================================

Analytical Limitations:
1. Deterministic One-at-a-Time (OAT) Sensitivity: OAT analysis changes one driver while holding others constant; it does not model joint correlations (such as a severe enterprise tech spending slowdown simultaneously depressing cloud growth and gross margins).
2. Terminal Value Share: Terminal value accounts for 79.1% of Enterprise Value, reflecting the reality of a 5-year forecast horizon on a mature megacap platform. A 10-year pro-forma would reduce terminal share to ~60%, but introduces speculative long-term forecasting errors.

Monitoring Triggers & Governance Cadence:
I will audit Microsoft's quarterly SEC Form 10-Q filings against three explicit operational benchmarks:
- Trigger 1 (Cloud Gross Margin): Benchmark = 68.5%. If Cloud gross margin compresses below 67.0% for two consecutive quarters, downgrade outlook from Watch/Defer to Negative/Do Not Initiate.
- Trigger 2 (Cash CapEx Run-Rate): Benchmark <= $65.0B / year. If quarterly additions to PP&E exceed $20.0B (annualized >$80.0B) without matching Azure revenue acceleration, escalate to committee as capital return destruction.
- Trigger 3 (Azure Constant-Currency Growth): Benchmark >= 30.0%. If Azure growth decelerates below 20.0%, intrinsic DCF cash floor drops below $250.00/share.
