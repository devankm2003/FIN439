# Project 1 — Corporate Finance Application: Microsoft Corporation (NASDAQ: MSFT)
**Buy-Side Valuation & Semi-Adjustable Pro-Forma Workbench**

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![Tests Passing](https://img.shields.io/badge/tests-12%2F12%20passing-brightgreen.svg)](file:///Users/devankmahajan/.gemini/antigravity/scratch/FIN439/run_tests.py)
[![Recommendation: Watch / Defer](https://img.shields.io/badge/recommendation-WATCH%20%2F%20DEFER-yellow.svg)](file:///Users/devankmahajan/.gemini/antigravity/scratch/FIN439/Decision-Memo.md)

---

## 1. Finance Decision and Intended User

- **Intended User:** Buy-Side Investment Committee (Fund holds **no current position** in Microsoft Corporation).
- **Decision Horizon:** Five-Year fundamental operating forecast (FY2026E–FY2030E) evaluated to long-run steady-state exit.
- **Security Analyzed:** Microsoft Corporation (`MSFT`), NASDAQ, Common Equity.
- **Valuation Date / Point-in-Time Boundary:** **September 23, 2026** (Market Close: **$500.59**).
- **Primary Audited Baseline:** Form 10-K for the fiscal year ended **June 30, 2025** (SEC Accession: `0000950170-25-100235`).
- **Committee Action:** **`WATCH / DEFER`**. Defer initiating capital commitments at $500.59. Intrinsic DCF value is **$317.10 per share** (Corner range: **$246.96 to $449.22**), indicating that current market pricing trades at an unjustifiable **+57.9% premium** over cash-backed operating value and prices in aggressive P/E multiple expansion while ignoring Microsoft's **$65.0B annual cash CapEx reinvestment drag**.

---

## 2. Visible Result (Inspection Without Execution)

The verified financial results, statement rows, sensitivity grids, and committee triggers are exported to the frozen reviewable contract [`visible_output.json`](visible_output.json):

```json
{
  "committee_decision": "WATCH / DEFER",
  "market_price": 500.59,
  "diluted_shares": 7465.0,
  "valuation_summary": {
    "fcff_base_value_per_share": 317.10,
    "fcfe_base_value_per_share": 303.85,
    "fcff_enterprise_value": 2330739.8,
    "fcff_equity_value": 2367153.8,
    "terminal_value_share_of_ev": 79.12,
    "intrinsic_valuation_range": "$246.96 – $449.22",
    "proforma_oat_range": "$255.77 – $365.92",
    "peer_median_pe_price": 544.48,
    "reverse_dcf_implied_growth": "21.58% / yr (+8.58 percentage points shift)"
  },
  "articulation_checks": {
    "balance_sheet_balances": true,
    "max_balance_gap": 0.0000,
    "cash_flow_ties_to_cash": true
  }
}
```

---

## 3. Setup and Run Instructions

This repository is designed to run out-of-the-box with **zero mandatory external dependencies** using standard Python 3.10+:

### Step 1: Run the Financial Analysis Engine & Export Contract
```bash
python3 analysis.py
```
*Computes the complete 5-year integrated 3-statement pro-forma, FCFF DCF, WACC-Growth grid, comps triangulation, OAT sensitivities, and exports `visible_output.json`.*

### Step 2: Run the Comprehensive Validation Suite
```bash
python3 run_tests.py
```
*Executes all 12 formal tests in `run_tests.py` covering known-answer synthetic fixtures, base-year audit, 3-statement articulation invariants, monotonicity, and the precommitted Locked Changed-Input test.*

### Step 3: Launch the Interactive Pro-Forma Workbench
You can launch the semi-adjustable workbench via either route:
- **Zero-Dependency Native Python Server:**
  ```bash
  python3 app.py
  ```
  *(Opens local web application on `http://localhost:8501` featuring bounded sliders, base reset, live 5-year statements, and loud checks panel).*
- **Streamlit Runner (if Streamlit installed):**
  ```bash
  streamlit run app.py
  ```

---

## 4. Repository Map and Evidence Flow

```
FIN439_Project1_MSFT/
├── analysis.py                    # Core 3-statement pro-forma engine & DCF valuation models
├── app.py                         # Interactive Semi-Adjustable Pro-Forma Workbench (Native + Streamlit)
├── workbench.html                 # Self-contained HTML workbench
├── visible_output.json            # Frozen interface contract of inputs, outputs, and checks
├── run_tests.py                   # 13-test validation suite covering all Rubric Criterion 5 checks
├── cold_run_log.txt               # Fresh-environment cold-run execution & test log
├── requirements.txt               # Environment dependencies
├── project-submission-manifest.csv# 12-row submission manifest with links, durations, and timestamps
│
├── Research-Evolution.md          # Edition A baseline, Addendum, Edition B, and A-to-B change table (.pdf / .docx)
├── Decision-Memo.md               # Two-page institutional investment committee memorandum (.pdf / .docx)
├── Validation-and-AI-Use.md       # Data ledger, validation register, Locked FCFF Record, AI register (.pdf / .docx)
│
├── transcript-video-1.txt         # Corrected transcript: Video 1 (Research Evolution & AI Check)
├── transcript-video-2.txt         # Corrected transcript: Video 2 (Codebase Walkthrough & Test)
├── transcript-video-3.txt         # Corrected transcript: Video 3 (Committee Defense & Live Demo)
│
└── docs/                          # Content-equivalent repository backup records
    ├── research-evolution.md      # (.pdf / .docx)
    ├── decision-memo.md           # (.pdf / .docx)
    ├── validation-and-ai-use.md   # (.pdf / .docx)
    ├── transcript-video-1.txt
    ├── transcript-video-2.txt
    └── transcript-video-3.txt
```

### Required Analysis-to-Interface Flow
1. **Audited Evidence:** Sourced directly from Microsoft's Form 10-K (Item 8 Financial Statements and Notes 4, 7, 8, 10, 18).
2. **Analysis Engine (`analysis.py`):** Computes every material line item dynamically; no hard-coded valuations in the interface.
3. **Validation (`run_tests.py`):** Enforces strict mathematical and accounting checks before export.
4. **Frozen Contract (`visible_output.json`):** Serves as an immutable bridge between the finance engine and presentation surfaces.
5. **Interactive Workbench (`app.py`):** Renders the semi-adjustable workbench with bounded sliders and loud checks that turn red upon violation.

---

## 5. Financial Conventions and Assumptions

| Driver / Assumption | Base Value | Financial Basis | Bounds & Challenge Defense |
| :--- | :--- | :--- | :--- |
| **Organic Revenue Growth** | **13.00% / yr** | Intelligent Cloud & Azure scaling against $281.7B base | **Bounded [8.0%–18.0%]**: Capped at 18.0% because Microsoft has never grown constant-currency revenue above 18% in the past decade. |
| **Gross Margin %** | **68.50%** | FY25 reported was 68.82%; 32 bps modeled compression | **Bounded [65.0%–72.0%]**: Captures AI datacenter electricity and GPU server depreciation drag. |
| **Annual Cash CapEx** | **$65,000M / yr** | Reflects FY25 cash additions ($64,551M) & FY26 guidance | **Bounded [$45.0B–$80.0B]**: Physical PP&E doubles from $95.6B in FY23 to $310B+ by FY30. |
| **Unearned Revenue Float** | **22.9143% of rev** | FY25 Short-term unearned revenue ($64,555M) | **Locked**: Enterprise customers prepay software licenses at 0% interest, providing +$8.4B–$13.7B annual cash inflow. |
| **PP&E Depreciation** | **10.7335% of PP&E** | Note 7 PP&E depreciation schedule ($22,000M) | **Locked**: Non-cash depreciation scales with opening net physical assets, reaching $37.7B by FY30. |
| **WACC Discount Rate** | **9.50%** | CAPM Ke = 9.50% (Rf 4.25% FRED DGS10 2026-09-23 + 1.05 beta x 5.00% Damodaran ERP) | **Bounded [8.0%–11.5%]**: 98.8% equity weight, AAA balance sheet credit rating. |
| **Terminal Growth Rate (g)** | **3.00%** | Course macro anchor (Long-run sustainable nominal GDP) | **Bounded [2.0%–4.0%]**: Bounded strictly below WACC; company cannot outgrow the macroeconomy indefinitely. |

---

## 6. Validation and Locked Changed-Input Record

All automated tests in `run_tests.py` pass (logged in [`cold_run_log.txt`](cold_run_log.txt)):
- **Synthetic Known-Answer Reconciliation:** Class synthetic bridge reproduces **$8.20/share**; training DCF reproduces **$27.50/share**.
- **Three-Statement Articulation:** Maximum Balance Sheet gap across all 5 forecast years is **$0.0000M**; Cash Flow ties to cash change with **0.0000 difference**.
- **Bridge & Lease Consistency:** Enterprise Value (`$2,330,739.8M`) + Gross Cash (`$94,565.0M`) - Operating Cash Floor (`$15,000.0M`) - Total Debt (`$43,151.0M`) - ASC 842 Leases (`$0.0M`, already expensed in EBIT/FCFF) = **$2,367,153.8M** (`$317.10/sh`).
- **Locked Changed-Input Record (FCFF Headline Decision-Flip Test, `v1.1.0-project1-reconciled`):**
  - *Input Shift:* Organic Revenue Growth shifted from 13.00% to 22.00% / yr (+900 bps across FY26E–FY30E, crossing the 21.58% Reverse-DCF hurdle).
  - *Precommitted Prediction:* FCFF value per share will rise by +$185 to +$205/share and **flip the recommendation** from `WATCH / DEFER` to `INITIATE BUY`.
  - *Actual Run Result:* Headline FCFF value per share rose **+$193.82 (+61.1%)** from **$317.10** to **$510.92**, exceeding $500.59 and flipping the call to **`INITIATE BUY`**.

---

## 7. Known Limitations, Monitoring, and Reversal Triggers

### Limitations
1. **Terminal Value Weight:** Terminal value accounts for **79.1% of Enterprise Value**, reflecting the reality of a 5-year forecast horizon on a mature megacap platform.
2. **One-at-a-Time Determinism:** OAT sensitivity tests drivers independently and does not model joint tail-event correlations.

### Explicit Reversal Triggers
- **`INITIATE BUY` if:**
  1. Share price retraces below **$310.00** (aligning with intrinsic DCF base range and providing 20%+ margin of safety to comps); **OR**
  2. Subsequent Form 10-Q filings demonstrate Microsoft Cloud gross margin expands above **72.0%** while annual CapEx growth moderates below 15% (confirming AI software adoption has outrun infrastructure costs).
- **`REJECT INITIATION` if:**
  Annual CapEx accelerates past **$75.0B** while Azure growth slips below **15.0%** and cloud gross margins drop below **67.0%** (confirming structural capital return destruction on GPU assets).

