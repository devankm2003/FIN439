"""Interactive Semi-Adjustable Pro-Forma Workbench.

Target: Microsoft Corporation (NASDAQ: MSFT)
Can be executed either via:
  1) `streamlit run app.py` (if Streamlit is installed)
  2) `python3 app.py` (zero external dependencies, runs built-in interactive HTTP server)
"""

from __future__ import annotations
import copy
import http.server
import json
import os
from pathlib import Path
import socketserver
import sys
import threading
import urllib.parse
import webbrowser

# Ensure script directory is on sys.path so imports work regardless of launch directory
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

# Import core finance engine
from analysis import (
    BASE_INPUTS,
    compute_excess_cash,
    run_proforma,
    compute_fcff_dcf,
    compute_fcfe_dcf,
    compute_wacc_growth_grid,
    compute_reverse_dcf,
    compute_comps_valuation,
    compute_oat_sensitivity,
)

# ------------------------------------------------------------------------------
# 1. HTML / JAVASCRIPT STANDALONE PRO-FORMA WORKBENCH TEMPLATE
# ------------------------------------------------------------------------------

WORKBENCH_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Microsoft (NASDAQ: MSFT) — Institutional Pro-Forma Workbench</title>
  <style>
    :root {
      --bg: #090d16;
      --card: #0f172a;
      --card-inner: #162033;
      --card-border: #1e293b;
      --text: #f1f5f9;
      --text-muted: #94a3b8;
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.25);
      --success: #22c55e;
      --warning: #f59e0b;
      --danger: #ef4444;
      --gold: #fbbf24;
      --border-light: rgba(255, 255, 255, 0.08);
    }

    [data-theme="light"] {
      --bg: #f8fafc;
      --card: #ffffff;
      --card-inner: #f1f5f9;
      --card-border: #cbd5e1;
      --text: #0f172a;
      --text-muted: #64748b;
      --accent: #0284c7;
      --accent-glow: rgba(2, 132, 199, 0.2);
      --border-light: rgba(0, 0, 0, 0.08);
    }

    * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
    body { background-color: var(--bg); color: var(--text); padding: 16px 20px; min-width: 1200px; font-size: 13px; line-height: 1.45; }

    /* Top Global Alert Banner for Solvency Breach */
    #globalAlertBanner {
      display: none;
      background: linear-gradient(90deg, #b91c1c, #dc2626);
      color: #fff;
      padding: 10px 18px;
      border-radius: 8px;
      margin-bottom: 14px;
      font-weight: 700;
      font-size: 13.5px;
      box-shadow: 0 4px 14px rgba(220, 38, 38, 0.4);
      display: flex;
      align-items: center;
      justify-content: space-between;
      animation: pulse 1.8s infinite;
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.95; transform: scale(0.998); }
    }

    /* Header Bar */
    .header-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: var(--card);
      border: 1px solid var(--card-border);
      border-radius: 12px;
      padding: 12px 20px;
      margin-bottom: 14px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25);
    }
    .header-title h1 { font-size: 18px; font-weight: 800; color: #fff; display: flex; align-items: center; gap: 10px; }
    .header-title .tag { font-size: 11px; font-weight: 700; background: rgba(56, 189, 248, 0.15); color: var(--accent); padding: 3px 8px; border-radius: 4px; border: 1px solid rgba(56, 189, 248, 0.3); text-transform: uppercase; letter-spacing: 0.5px; }
    .header-meta { font-size: 11.5px; color: var(--text-muted); margin-top: 2px; }
    .header-actions { display: flex; align-items: center; gap: 10px; }
    .rating-badge { background: rgba(245, 158, 11, 0.15); border: 1px solid var(--warning); color: var(--gold); padding: 5px 12px; border-radius: 6px; font-weight: 800; font-size: 12.5px; letter-spacing: 0.5px; }
    .theme-toggle-btn { background: var(--card-inner); border: 1px solid var(--card-border); color: var(--text); padding: 5px 10px; border-radius: 6px; font-size: 11.5px; cursor: pointer; font-weight: 600; }

    /* Top KPI Cards */
    .kpi-row { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin-bottom: 14px; }
    .kpi-card { background: var(--card); border: 1px solid var(--card-border); border-radius: 10px; padding: 10px 14px; position: relative; overflow: hidden; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.15); }
    .kpi-card::before { content: ""; position: absolute; top: 0; left: 0; width: 4px; height: 100%; background: var(--accent); }
    .kpi-card.gold::before { background: var(--gold); }
    .kpi-card.green::before { background: var(--success); }
    .kpi-card.red::before { background: var(--danger); }
    .kpi-label { font-size: 10.5px; text-transform: uppercase; letter-spacing: 0.5px; color: var(--text-muted); font-weight: 700; margin-bottom: 3px; }
    .kpi-value { font-size: 20px; font-weight: 800; color: #fff; font-family: "SF Mono", Menlo, Consolas, monospace; }
    .kpi-sub { font-size: 10.5px; color: var(--text-muted); margin-top: 2px; }

    /* Layout Grid */
    .workbench-grid { display: grid; grid-template-columns: 330px 1fr; gap: 16px; }

    /* Left Sidebar: Controls & Audit */
    .sidebar { display: flex; flex-direction: column; gap: 12px; }
    .card { background: var(--card); border: 1px solid var(--card-border); border-radius: 10px; padding: 14px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.15); }
    
    .preset-group { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin-bottom: 10px; }
    .preset-btn {
      padding: 6px 8px;
      font-size: 11px;
      font-weight: 700;
      border-radius: 6px;
      border: 1px solid var(--card-border);
      background: var(--card-inner);
      color: var(--text);
      cursor: pointer;
      transition: all 0.15s ease;
      text-align: center;
    }
    .preset-btn:hover { background: rgba(56, 189, 248, 0.15); border-color: var(--accent); color: #fff; }
    .preset-btn.fail-btn { background: rgba(239, 68, 68, 0.15); border-color: rgba(239, 68, 68, 0.5); color: #fca5a5; }
    .preset-btn.fail-btn:hover { background: #ef4444; color: #fff; }

    .slider-group { margin-bottom: 12px; }
    .slider-header { display: flex; justify-content: space-between; font-size: 11.5px; margin-bottom: 4px; font-weight: 600; }
    .slider-header span:last-child { color: var(--accent); font-family: monospace; font-weight: 700; }
    input[type=range] { width: 100%; height: 5px; border-radius: 5px; background: var(--card-inner); outline: none; -webkit-appearance: none; }
    input[type=range]::-webkit-slider-thumb { -webkit-appearance: none; width: 14px; height: 14px; border-radius: 50%; background: var(--accent); cursor: pointer; box-shadow: 0 0 8px var(--accent-glow); }

    .checks-card { font-size: 11px; }
    .check-item { display: flex; justify-content: space-between; align-items: center; padding: 5px 0; border-bottom: 1px solid rgba(255, 255, 255, 0.05); }
    .check-item:last-child { border-bottom: none; }
    .check-badge { padding: 2px 7px; border-radius: 4px; font-weight: 800; font-size: 10px; }
    .badge-pass { background: rgba(34, 197, 94, 0.15); color: #4ade80; border: 1px solid rgba(34, 197, 94, 0.3); }
    .badge-fail { background: rgba(239, 68, 68, 0.2); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.4); animation: blink 1s infinite; }

    @keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }

    .provenance-card { font-size: 11px; line-height: 1.5; color: var(--text-muted); background: var(--card-inner); border-radius: 8px; padding: 10px; border: 1px solid rgba(255, 255, 255, 0.05); }
    .provenance-card ul { margin: 4px 0 4px 14px; }
    .provenance-card b { color: #e2e8f0; }

    /* Tabs & Content: 10 Dedicated Tabs Styled in 2 Clean Rows or Wrapping Flex */
    .tab-nav {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      border-bottom: 2px solid var(--card-border);
      margin-bottom: 14px;
      padding-bottom: 8px;
    }
    .tab-btn {
      padding: 7px 12px;
      background: var(--card-inner);
      border: 1px solid var(--card-border);
      border-radius: 6px;
      color: var(--text-muted);
      font-weight: 700;
      font-size: 11.5px;
      cursor: pointer;
      white-space: nowrap;
      transition: all 0.15s ease;
    }
    .tab-btn:hover { color: #fff; background: rgba(56, 189, 248, 0.1); border-color: rgba(56, 189, 248, 0.4); }
    .tab-btn.active {
      color: #fff;
      background: var(--accent);
      color: #090d16;
      border-color: var(--accent);
      font-weight: 800;
      box-shadow: 0 0 10px rgba(56, 189, 248, 0.4);
    }
    .tab-content { display: none; }
    .tab-content.active { display: block; }

    /* SVG Chart Containers */
    .chart-container { background: var(--card-inner); border: 1px solid var(--card-border); border-radius: 10px; padding: 14px; margin-bottom: 14px; box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.4); }
    .chart-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; font-weight: 700; font-size: 12.5px; color: #fff; }
    .chart-legend { display: flex; gap: 14px; font-size: 11px; }
    .legend-dot { display: inline-block; width: 9px; height: 9px; border-radius: 2px; margin-right: 4px; }

    /* Tables */
    table { width: 100%; border-collapse: collapse; font-size: 12px; margin-top: 6px; }
    th { text-align: right; padding: 8px 10px; background: var(--card-inner); color: var(--text-muted); font-weight: 700; font-size: 11px; text-transform: uppercase; border-bottom: 1px solid var(--card-border); }
    th:first-child { text-align: left; }
    td { text-align: right; padding: 7px 10px; border-bottom: 1px solid rgba(255, 255, 255, 0.04); font-family: "SF Mono", Menlo, Consolas, monospace; }
    td:first-child { text-align: left; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    tr:hover td { background: rgba(255, 255, 255, 0.02); }
    .bold-row td { font-weight: 800; color: #fff; border-top: 1px solid rgba(255, 255, 255, 0.1); }
    .highlight-cell { color: var(--accent); font-weight: 800; }
    .float-row td { background: rgba(251, 191, 36, 0.06); font-weight: 700; color: #fef08a; }
    .tag-note { font-size: 10.5px; color: var(--text-muted); font-style: italic; font-weight: normal; }

    .text-green { color: #4ade80 !important; }
    .text-red { color: #f87171 !important; }
    .text-gold { color: #fbbf24 !important; }

    /* Action Badges in Tab Headers */
    .tab-status-strip {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: var(--card-inner);
      padding: 8px 14px;
      border-radius: 8px;
      margin-bottom: 12px;
      border: 1px solid var(--card-border);
      font-size: 12px;
    }
  </style>
</head>
<body>

  <!-- GLOBAL SOLVENCY BREACH BANNER -->
  <div id="globalAlertBanner">
    <span>⚠️ CRITICAL FINANCIAL INTEGRITY FAILURE: Terminal Growth Rate (g) &ge; WACC Discount Rate. Gordon Growth Formula Mathematically Diverges.</span>
    <button onclick="applyPreset('base')" style="background: #fff; color: #b91c1c; border: none; padding: 5px 12px; border-radius: 4px; font-weight: 800; font-size: 11px; cursor: pointer;">RESTORE BASE INPUTS</button>
  </div>

  <!-- HEADER BAR -->
  <div class="header-bar">
    <div class="header-title">
      <h1>Microsoft Corporation <span class="tag">NASDAQ: MSFT</span> <span style="font-size: 13px; font-weight: 500; color: var(--text-muted);">| Institutional Pro-Forma Workbench</span></h1>
      <div class="header-meta">SEC Form 10-K Anchored (FY25 Ended June 30, 2025) &bull; Valuation Date: Sept 23, 2026 &bull; Strict 3-Statement Articulation</div>
    </div>
    <div class="header-actions">
      <div class="rating-badge">RECOMMENDATION: WATCH / DEFER</div>
      <button class="theme-toggle-btn" onclick="toggleTheme()">Toggle Theme</button>
    </div>
  </div>

  <!-- TOP KPI CARDS -->
  <div class="kpi-row">
    <div class="kpi-card" id="kpiCardDcf">
      <div class="kpi-label">Base DCF Intrinsic Value</div>
      <div class="kpi-value" id="kpiDcfValue">$317.10</div>
      <div class="kpi-sub text-red" id="kpiDcfSub">-36.7% vs Market ($500.59)</div>
    </div>
    <div class="kpi-card gold">
      <div class="kpi-label">Market Price (As-Of Date)</div>
      <div class="kpi-value">$500.59</div>
      <div class="kpi-sub">Implies +57.9% Premium over DCF</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Enterprise Value (EV)</div>
      <div class="kpi-value" id="kpiEvValue">$2,330.7B</div>
      <div class="kpi-sub" id="kpiTvShare">Terminal Value: 79.12% of EV</div>
    </div>
    <div class="kpi-card green">
      <div class="kpi-label">Peer Median P/E Comps</div>
      <div class="kpi-value">$544.48</div>
      <div class="kpi-sub">39.91x Peer Multiple (AMZN, GOOGL, ORCL)</div>
    </div>
    <div class="kpi-card gold">
      <div class="kpi-label">Reverse DCF Implied CAGR</div>
      <div class="kpi-value">21.58%</div>
      <div class="kpi-sub text-gold">+8.58% Acceleration vs Base (13.0%)</div>
    </div>
  </div>

  <!-- MAIN WORKBENCH LAYOUT -->
  <div class="workbench-grid">

    <!-- LEFT SIDEBAR: DRIVERS & AUDIT -->
    <div class="sidebar">

      <!-- SCENARIO PRESETS -->
      <div class="card">
        <h3 style="font-size: 12.5px; margin-bottom: 8px; color: var(--accent); font-weight: 800;">SCENARIO PRESETS</h3>
        <div class="preset-group">
          <button class="preset-btn" onclick="applyPreset('base')">Base Case ($317.10)</button>
          <button class="preset-btn" onclick="applyPreset('bull')">Bull Case ($449.22)</button>
          <button class="preset-btn" onclick="applyPreset('bear')">Bear Case ($246.96)</button>
          <button class="preset-btn fail-btn" onclick="applyPreset('fail')">⚡ Demo Loud Fail</button>
        </div>
      </div>

      <!-- BOUNDED DRIVERS -->
      <div class="card">
        <h3 style="font-size: 12.5px; margin-bottom: 10px; color: var(--accent); font-weight: 800;">BOUNDED VALUATION DRIVERS</h3>

        <div class="slider-group">
          <div class="slider-header">
            <span>Organic Revenue Growth</span>
            <span id="lblGrowth">13.0%</span>
          </div>
          <input type="range" id="slGrowth" min="8.0" max="18.0" step="0.5" value="13.0">
          <div style="font-size: 10.5px; color: var(--text-muted); margin-top: 2px;">Ten-year historical range: 8.0% to 18.0%</div>
        </div>

        <div class="slider-group">
          <div class="slider-header">
            <span>Gross Margin</span>
            <span id="lblMargin">68.5%</span>
          </div>
          <input type="range" id="slMargin" min="65.0" max="72.0" step="0.5" value="68.5">
          <div style="font-size: 10.5px; color: var(--text-muted); margin-top: 2px;">Cloud mix vs hardware drag</div>
        </div>

        <div class="slider-group">
          <div class="slider-header">
            <span>Annual CapEx Reinvestment</span>
            <span id="lblCapex">$65,000M</span>
          </div>
          <input type="range" id="slCapex" min="45000" max="85000" step="2500" value="65000">
          <div style="font-size: 10.5px; color: var(--text-muted); margin-top: 2px;">AI Datacenters & GPU clusters</div>
        </div>

        <div class="slider-group">
          <div class="slider-header">
            <span>WACC Discount Rate</span>
            <span id="lblWacc">9.50%</span>
          </div>
          <input type="range" id="slWacc" min="8.0" max="11.5" step="0.25" value="9.50">
          <div style="font-size: 10.5px; color: var(--text-muted); margin-top: 2px;">CAPM derived: Rf 4.25%, Beta 1.05, ERP 5.0%</div>
        </div>

        <div class="slider-group">
          <div class="slider-header">
            <span>Terminal Growth Rate (g)</span>
            <span id="lblTg">3.00%</span>
          </div>
          <input type="range" id="slTg" min="1.5" max="10.5" step="0.25" value="3.00">
          <div style="font-size: 10.5px; color: var(--text-muted); margin-top: 2px;">Long-term GDP anchor (Fail if &ge; WACC)</div>
        </div>

        <button onclick="applyPreset('base')" style="width: 100%; padding: 7px; background: var(--card-inner); border: 1px solid var(--card-border); color: var(--text); border-radius: 6px; font-weight: 700; font-size: 11px; cursor: pointer; margin-top: 2px;">
          Restore Audited Base Inputs
        </button>
      </div>

      <!-- AUTOMATED INTEGRITY CHECKS -->
      <div class="card checks-card" id="checksPanel">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
          <h3 style="font-size: 12.5px; color: var(--accent); font-weight: 800;">FINANCIAL CHECKS</h3>
          <span class="check-badge badge-pass" id="checkSummaryBadge">ALL PASSING</span>
        </div>
        <div class="check-item">
          <span>Solvency: Gordon Convergence (g &lt; WACC)</span>
          <span class="check-badge badge-pass" id="chkSolvency">PASS</span>
        </div>
        <div class="check-item">
          <span>Balance Sheet Gap Check (&lt; $0.05M)</span>
          <span class="check-badge badge-pass" id="chkGap">PASS ($0.0000)</span>
        </div>
        <div class="check-item">
          <span>Liquidity Floor ($15,000M minimum cash)</span>
          <span class="check-badge badge-pass" id="chkCashFloor">PASS</span>
        </div>
        <div class="check-item">
          <span>Growth Boundary (&le; 18.0% historical cap)</span>
          <span class="check-badge badge-pass" id="chkGrowthBound">PASS</span>
        </div>
      </div>

      <!-- LOCKED PROVENANCE -->
      <div class="provenance-card">
        <b>LOCKED 10-K PROVENANCE (June 30, 2025):</b>
        <ul>
          <li>Cash & ST Inv: <b>$94,565M</b> (Note 4; Floor $15B)</li>
          <li>Total Debt: <b>$43,151M</b> (ST $3.0B, LT $40.2B, Note 10)</li>
          <li>Operating Leases: <b>$18,485M</b> (Note 8; in EBIT/FCFF)</li>
          <li>Unearned Revenue Float: <b>$64,555M</b> (22.91%)</li>
          <li>Diluted Shares: <b>7,465.0M</b> (Note 18, p. 94)</li>
        </ul>
      </div>

    </div>

    <!-- RIGHT MAIN CONTENT AREA -->
    <div class="main-content">

      <!-- TABS NAVIGATION: 10 DEDICATED TABS -->
      <div class="tab-nav">
        <button class="tab-btn active" onclick="switchTab('tabForecast', this)">5-Year Forecast</button>
        <button class="tab-btn" onclick="switchTab('tabIncome', this)">Income Statement</button>
        <button class="tab-btn" onclick="switchTab('tabBalanceSheet', this)">Balance Sheet</button>
        <button class="tab-btn" onclick="switchTab('tabCashFlow', this)">Cash Flow Statement</button>
        <button class="tab-btn" onclick="switchTab('tabWaterfall', this)">Waterfall Bridge</button>
        <button class="tab-btn" onclick="switchTab('tabTornado', this)">Sensitivity Tornado</button>
        <button class="tab-btn" onclick="switchTab('tabComps', this)">Relative Valuation & Comps</button>
        <button class="tab-btn" onclick="switchTab('tabFootballField', this)">Football Field</button>
        <button class="tab-btn" onclick="switchTab('tabReverseDCF', this)">Reverse DCF</button>
        <button class="tab-btn" onclick="switchTab('tabCommittee', this)">Committee Memo & Triggers</button>
      </div>

      <!-- TAB 1: 5-YEAR FORECAST -->
      <div id="tabForecast" class="tab-content active">
        <div class="chart-container">
          <div class="chart-header">
            <span>5-Year Revenue, EBIT & Free Cash Flow Forecast ($M)</span>
            <div class="chart-legend">
              <span><span class="legend-dot" style="background: #38bdf8;"></span> Revenue</span>
              <span><span class="legend-dot" style="background: #22c55e;"></span> EBIT</span>
              <span><span class="legend-dot" style="background: #fbbf24;"></span> Free Cash Flow (FCFF)</span>
            </div>
          </div>
          <svg id="svgForecastChart" width="100%" height="155" viewBox="0 0 700 155"></svg>
        </div>

        <div class="card" style="padding: 14px 18px;">
          <h3 style="font-size: 13.5px; margin-bottom: 10px; color: var(--accent); font-weight: 800;">5-Year Core Projection Trajectory Summary</h3>
          <table>
            <thead>
              <tr>
                <th>Key Metric ($ Millions)</th>
                <th>FY2025 Base</th>
                <th>FY2026E</th>
                <th>FY2027E</th>
                <th>FY2028E</th>
                <th>FY2029E</th>
                <th>FY2030E</th>
              </tr>
            </thead>
            <tbody id="tblForecastSummaryBody">
              <!-- Dynamically Populated -->
            </tbody>
          </table>
        </div>
      </div>

      <!-- TAB 2: INCOME STATEMENT -->
      <div id="tabIncome" class="tab-content">
        <div class="card" style="padding: 14px 18px;">
          <div class="tab-status-strip">
            <span style="font-weight: 700; color: var(--accent);">Pro-Forma Income Statement (FY26E &ndash; FY30E)</span>
            <span class="tag-note">Anchored to Form 10-K FY25 Baseline</span>
          </div>
          <table>
            <thead>
              <tr>
                <th>Statement Line ($ Millions)</th>
                <th>FY2025 Base</th>
                <th>FY2026E</th>
                <th>FY2027E</th>
                <th>FY2028E</th>
                <th>FY2029E</th>
                <th>FY2030E</th>
              </tr>
            </thead>
            <tbody id="tblIncomeBody">
              <!-- Dynamically Populated -->
            </tbody>
          </table>
        </div>
      </div>

      <!-- TAB 3: BALANCE SHEET -->
      <div id="tabBalanceSheet" class="tab-content">
        <div class="card" style="padding: 14px 18px;">
          <div class="tab-status-strip">
            <span style="font-weight: 700; color: var(--accent);">Pro-Forma Balance Sheet Articulation</span>
            <span class="check-badge badge-pass" id="badgeBalanceSheetGap">BALANCE SHEET GAP: $0.0000M (PASS)</span>
          </div>
          <table>
            <thead>
              <tr>
                <th>Balance Sheet Item ($ Millions)</th>
                <th>FY2025 Base</th>
                <th>FY2026E</th>
                <th>FY2027E</th>
                <th>FY2028E</th>
                <th>FY2029E</th>
                <th>FY2030E</th>
              </tr>
            </thead>
            <tbody id="tblBalanceSheetBody">
              <!-- Dynamically Populated -->
            </tbody>
          </table>
          <p style="font-size: 11.5px; color: var(--text-muted); margin-top: 12px; line-height: 1.6;">
            <b style="color: #fbbf24;">Short-Term Unearned Revenue Float:</b> Customers prepay enterprise software and cloud contracts upfront, creating an interest-free float engine ($64.6B in FY25 expanding to over $118B by FY30E) that significantly enhances free cash conversion.
          </p>
        </div>
      </div>

      <!-- TAB 4: CASH FLOW STATEMENT -->
      <div id="tabCashFlow" class="tab-content">
        <div class="card" style="padding: 14px 18px;">
          <div class="tab-status-strip">
            <span style="font-weight: 700; color: var(--accent);">Pro-Forma Statement of Cash Flows</span>
            <span class="check-badge badge-pass">CASH FLOW TIE DIFFERENCE: $0.0000M (PASS)</span>
          </div>
          <table>
            <thead>
              <tr>
                <th>Cash Flow Item ($ Millions)</th>
                <th>FY2025 Base</th>
                <th>FY2026E</th>
                <th>FY2027E</th>
                <th>FY2028E</th>
                <th>FY2029E</th>
                <th>FY2030E</th>
              </tr>
            </thead>
            <tbody id="tblCashFlowBody">
              <!-- Dynamically Populated -->
            </tbody>
          </table>
        </div>
      </div>

      <!-- TAB 5: WATERFALL BRIDGE -->
      <div id="tabWaterfall" class="tab-content">
        <div class="chart-container">
          <div class="chart-header">
            <span>Enterprise-to-Equity Claims Waterfall ($ Billions)</span>
            <span style="font-size: 11px; color: var(--gold); font-weight: 700;">Base Per-Share: $317.10</span>
          </div>
          <svg id="svgWaterfallChart" width="100%" height="155" viewBox="0 0 700 155"></svg>
        </div>

        <div class="card" style="padding: 14px 18px;">
          <h3 style="font-size: 13.5px; margin-bottom: 10px; color: var(--accent); font-weight: 800;">Enterprise-to-Equity Valuation Bridge (USD Millions)</h3>
          <table>
            <thead>
              <tr>
                <th>Bridge Step / Component</th>
                <th>Value ($M)</th>
                <th>Per Diluted Share ($)</th>
                <th>Audit / Source Note</th>
              </tr>
            </thead>
            <tbody id="tblBridgeBody">
              <!-- Dynamically Populated -->
            </tbody>
          </table>
        </div>
      </div>

      <!-- TAB 6: SENSITIVITY TORNADO -->
      <div id="tabTornado" class="tab-content">
        <div class="chart-container">
          <div class="chart-header">
            <span>One-at-a-Time (OAT) Sensitivity Tornado (Value per Share Span $)</span>
            <span style="font-size: 11px; color: var(--accent); font-weight: 700;">Revenue Dominance: 4.68x over Gross Margin</span>
          </div>
          <svg id="svgTornadoChart" width="100%" height="130" viewBox="0 0 700 130"></svg>
        </div>

        <div class="card" style="padding: 14px 18px; margin-bottom: 14px;">
          <h3 style="font-size: 13.5px; margin-bottom: 10px; color: var(--accent); font-weight: 800;">WACC & Terminal Growth Sensitivity Matrix (Value per Share $)</h3>
          <table>
            <thead>
              <tr>
                <th>WACC \\ Terminal Growth</th>
                <th>2.00%</th>
                <th>3.00% (Base)</th>
                <th>4.00%</th>
              </tr>
            </thead>
            <tbody id="tblSensGridBody">
              <!-- Dynamically Populated -->
            </tbody>
          </table>
        </div>

        <div class="card" style="padding: 14px 18px;">
          <h3 style="font-size: 13.5px; margin-bottom: 10px; color: var(--accent); font-weight: 800;">One-at-a-Time (OAT) Parameter Span Comparison</h3>
          <table>
            <thead>
              <tr>
                <th>Parameter Name</th>
                <th>Input Range Tested</th>
                <th>FY2030E EBIT Span</th>
                <th>FY2030E FCFE Span</th>
                <th>Value per Share Span</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><b>Organic Revenue Growth Rate</b></td>
                <td>10.0% to 16.0% / yr (6.0 pt span)</td>
                <td>$74,677.3M</td>
                <td>$68,735.0M</td>
                <td class="highlight-cell">$110.15 / share</td>
              </tr>
              <tr>
                <td><b>Gross Margin Percentage</b></td>
                <td>66.5% to 70.5% (4.0 pt span)</td>
                <td>$16,402.2M</td>
                <td>$13,475.3M</td>
                <td class="highlight-cell">$23.53 / share</td>
              </tr>
            </tbody>
          </table>
          <p style="font-size: 11.5px; color: var(--text-muted); margin-top: 10px; line-height: 1.6;">
            <b>Causal Insight:</b> Revenue Growth dominates Gross Margin by <b>4.68x</b> because revenue growth compounds exponentially over five years and pulls in over $10B of annual zero-interest unearned customer float.
          </p>
        </div>
      </div>

      <!-- TAB 7: RELATIVE VALUATION & COMPS -->
      <div id="tabComps" class="tab-content">
        <div class="card" style="padding: 14px 18px;">
          <div class="tab-status-strip">
            <span style="font-weight: 700; color: var(--accent);">Qualified Comparable Companies Multiples</span>
            <span style="font-size: 11px; color: var(--gold); font-weight: 700;">Median P/E Multiple: 39.91x</span>
          </div>
          <table>
            <thead>
              <tr>
                <th>Company</th>
                <th>Ticker</th>
                <th>Share Price</th>
                <th>Diluted EPS</th>
                <th>P/E Multiple</th>
                <th>EV/EBITDA</th>
                <th>Policy Qualification</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><b>Alphabet Inc.</b></td>
                <td>GOOGL</td>
                <td>$330.39</td>
                <td>$8.04</td>
                <td>41.09x</td>
                <td>24.12x</td>
                <td>Qualified: >75% revenue digital advertising & GCP Cloud</td>
              </tr>
              <tr>
                <td><b>Oracle Corporation</b></td>
                <td>ORCL</td>
                <td>$152.94</td>
                <td>$4.34</td>
                <td>35.24x</td>
                <td>20.85x</td>
                <td>Qualified: Enterprise database & OCI Cloud infrastructure</td>
              </tr>
              <tr>
                <td><b>Amazon.com Inc.</b></td>
                <td>AMZN</td>
                <td>$186.40</td>
                <td>$4.67</td>
                <td>39.91x</td>
                <td>22.38x</td>
                <td>Qualified: Enterprise cloud infrastructure (AWS) & retail</td>
              </tr>
              <tr class="bold-row">
                <td colspan="4">Peer Median Multiples</td>
                <td style="color: #4ade80;">39.91x</td>
                <td style="color: #4ade80;">22.38x</td>
                <td>Baseline peer benchmark</td>
              </tr>
              <tr class="bold-row" style="background: rgba(56, 189, 248, 0.08);">
                <td colspan="4" style="color: var(--accent);">MSFT Implied Valuation via Peer Median</td>
                <td style="color: var(--accent); font-size: 14px;">$544.48</td>
                <td style="color: var(--accent); font-size: 14px;">$402.90</td>
                <td>Range: $480.71 &ndash; $560.56</td>
              </tr>
            </tbody>
          </table>
          <p style="font-size: 11.5px; color: var(--text-muted); margin-top: 10px; line-height: 1.6;">
            <b>Why DCF ($317.10) and Comps ($544.48) Disagree:</b> Comps price accounting earnings, ignoring MSFT's $65B cash CapEx burden. DCF deducts physical GPU clusters and datacenter buildouts directly from free cash flow.
          </p>
        </div>
      </div>

      <!-- TAB 8: FOOTBALL FIELD -->
      <div id="tabFootballField" class="tab-content">
        <div class="chart-container">
          <div class="chart-header">
            <span>Valuation Method Comparison (Football Field Range $)</span>
            <span style="font-size: 11px; color: var(--gold); font-weight: 700;">Never Mechanically Averaged</span>
          </div>
          <svg id="svgFootballField" width="100%" height="135" viewBox="0 0 700 135"></svg>
        </div>

        <div class="card" style="padding: 14px 18px;">
          <h3 style="font-size: 13.5px; margin-bottom: 10px; color: var(--accent); font-weight: 800;">Valuation Triangulation Landscape</h3>
          <table>
            <thead>
              <tr>
                <th>Valuation Methodology</th>
                <th>Implied Value Range ($ / Share)</th>
                <th>Base / Point Estimate ($)</th>
                <th>Weight & Committee Rationale</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><b>Intrinsic FCFF DCF (Base)</b></td>
                <td>$246.96 &ndash; $449.22</td>
                <td class="highlight-cell">$317.10</td>
                <td><b>100% Primary Weight.</b> Deducts physical cash CapEx.</td>
              </tr>
              <tr>
                <td><b>Free Cash Flow to Equity (FCFE)</b></td>
                <td>$255.77 &ndash; $365.92</td>
                <td style="color: #fbbf24; font-weight: 700;">$303.85</td>
                <td>Cross-check confirming DCF discipline.</td>
              </tr>
              <tr>
                <td><b>Comparable Companies (P/E 39.91x)</b></td>
                <td>$480.71 &ndash; $560.56</td>
                <td style="color: #4ade80; font-weight: 700;">$544.48</td>
                <td>Relative benchmark only. Distorted by accounting net income.</td>
              </tr>
              <tr class="bold-row" style="background: rgba(251, 191, 36, 0.08);">
                <td style="color: var(--gold);">Current Market Price</td>
                <td style="color: var(--gold);">September 23, 2026</td>
                <td style="color: var(--gold); font-size: 14px;">$500.59</td>
                <td style="color: var(--gold);">Trades at <b>+57.9% premium</b> over cash-backed value.</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- TAB 9: REVERSE DCF -->
      <div id="tabReverseDCF" class="tab-content">
        <div class="card" style="padding: 18px 22px;">
          <h3 style="font-size: 16px; margin-bottom: 12px; color: var(--gold); font-weight: 800;">Reverse DCF Implied Growth Analysis at $500.59</h3>
          
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;">
            <div style="background: var(--card-inner); border: 1px solid var(--card-border); border-radius: 8px; padding: 16px;">
              <div style="font-size: 11px; text-transform: uppercase; color: var(--text-muted); font-weight: 700;">Base Case Organic Revenue Growth</div>
              <div style="font-size: 26px; font-weight: 800; color: #fff; margin: 4px 0; font-family: monospace;">13.0%</div>
              <div style="font-size: 11.5px; color: var(--text-muted);">Yields Intrinsic DCF of <b>$317.10 / share</b></div>
            </div>

            <div style="background: rgba(251, 191, 36, 0.08); border: 1px solid var(--gold); border-radius: 8px; padding: 16px;">
              <div style="font-size: 11px; text-transform: uppercase; color: var(--gold); font-weight: 700;">Market-Implied Organic Growth at $500.59</div>
              <div style="font-size: 26px; font-weight: 800; color: var(--gold); margin: 4px 0; font-family: monospace;">21.58%</div>
              <div style="font-size: 11.5px; color: #fef08a;">Requires <b>+8.58 percentage points</b> of continuous acceleration</div>
            </div>
          </div>

          <div style="background: var(--card-inner); border-radius: 8px; padding: 14px; font-size: 12.5px; line-height: 1.7; color: #cbd5e1;">
            <p><b>Analytical Finding:</b> To justify Microsoft's current market trading price of <b>$500.59</b> without altering baseline WACC (9.5%) or CapEx reinvestment ($65B/year), Microsoft must compound organic revenue at <b>21.58% annually</b> across all five forecast years (FY26E through FY30E).</p>
            <p style="margin-top: 8px;"><b>Fundamental Verdict:</b> This requires adding over <b>$180 billion</b> of incremental revenue above base expectations by FY2030. Enterprise IT budget surveys and cloud workload maturity do not support this pace without immediate, hyper-scale monetization of Microsoft 365 Copilot.</p>
          </div>
        </div>
      </div>

      <!-- TAB 10: COMMITTEE MEMO & REVERSAL TRIGGERS -->
      <div id="tabCommittee" class="tab-content">
        <div class="card" style="padding: 18px 22px;">
          <h3 style="font-size: 16px; margin-bottom: 12px; color: var(--gold); font-weight: 800;">Investment Committee Memorandum: WATCH / DEFER</h3>
          <div style="font-size: 12.5px; line-height: 1.7; color: #cbd5e1;">
            <p><b>Target Security:</b> Microsoft Corporation (NASDAQ: MSFT), Common Equity | <b>Valuation Date:</b> September 23, 2026</p>
            <p><b>Current Price:</b> $500.59 | <b>Intrinsic DCF Value:</b> $317.10 (Corner Range: $246.96 to $449.22)</p>
            <p style="margin-top: 8px;">At $500.59, Microsoft trades at a <b>+57.9% premium</b> over my base intrinsic DCF valuation and requires <b>21.58% compound organic revenue growth</b> through 2030. Current market pricing reflects P/E multiple expansion (39.91x) that ignores Microsoft's $65B annual physical AI CapEx reinvestment requirements.</p>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin: 16px 0;">
              <div style="background: rgba(34, 197, 94, 0.08); border: 1px solid var(--success); border-radius: 8px; padding: 14px;">
                <h4 style="color: #4ade80; margin-bottom: 6px; font-size: 12.5px; font-weight: 800;">🟢 INITIATE BUY IF:</h4>
                <p style="font-size: 11.5px; color: #e2e8f0;">Share price pulls back below <b>$310.00</b> (entering my base DCF zone), OR upcoming Form 10-Q filings confirm Microsoft Cloud gross margin expands past <b>72.0%</b> while CapEx growth moderates below 15%.</p>
              </div>
              <div style="background: rgba(239, 68, 68, 0.08); border: 1px solid var(--danger); border-radius: 8px; padding: 14px;">
                <h4 style="color: #f87171; margin-bottom: 6px; font-size: 12.5px; font-weight: 800;">🔴 REJECT / REMOVE IF:</h4>
                <p style="font-size: 11.5px; color: #e2e8f0;">Annual CapEx exceeds <b>$75.0 billion</b> while Azure constant-currency growth slows below 15% and gross margins slip below 67.0%, confirming structural return dilution on GPU infrastructure.</p>
              </div>
            </div>

            <div style="background: rgba(251, 191, 36, 0.08); border: 1px solid var(--gold); border-radius: 8px; padding: 14px; margin-top: 10px;">
              <h4 style="color: #fbbf24; margin-bottom: 4px; font-size: 12.5px; font-weight: 800;">FORMAL COMMITTEE ASK:</h4>
              <p style="font-size: 12px; color: #e2e8f0;"><b>Commit $0.00 capital today. Authorize Watch / Defer status, and direct our equity task force to audit Microsoft's Q1 FY2027 Form 10-Q in October 2026.</b></p>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>

  <script>
    // Audited Base Constants from SEC Form 10-K (ended June 30, 2025)
    const BASE = {
      growth: 13.0,
      margin: 68.5,
      capex: 65000,
      wacc: 9.50,
      tg: 3.00,
      opening_rev: 281724.0,
      opening_cost_rev: 87831.0,
      opening_cash: 94565.0,
      opening_inv: 938.0,
      opening_ppe: 204966.0,
      opening_other_assets: 318534.0,
      opening_unearned: 64555.0,
      opening_debt: 43151.0,
      opening_leases: 18485.0,
      opening_other_liab: 149333.0,
      opening_equity: 343479.0,
      shares: 7465.0,
      market_price: 500.59,
      depr_ratio: 22000.0 / 204966.0,
      unearned_ratio: 64555.0 / 281724.0,
      sga_ratios: [0.225, 0.220, 0.215, 0.210, 0.210],
      tax_rate: 0.18,
      debt_repay: 3000.0,
      share_buyback: 42502.0,
      min_cash: 15000.0,
      rev_rate: 0.05,
      debt_rate: 2385.0 / 43151.0
    };

    // Sliders
    const slG = document.getElementById('slGrowth');
    const slM = document.getElementById('slMargin');
    const slC = document.getElementById('slCapex');
    const slW = document.getElementById('slWacc');
    const slT = document.getElementById('slTg');

    // Value Labels
    const lblG = document.getElementById('lblGrowth');
    const lblM = document.getElementById('lblMargin');
    const lblC = document.getElementById('lblCapex');
    const lblW = document.getElementById('lblWacc');
    const lblT = document.getElementById('lblTg');

    function applyPreset(preset) {
      if (preset === 'base') {
        slG.value = 13.0; slM.value = 68.5; slC.value = 65000; slW.value = 9.50; slT.value = 3.00;
      } else if (preset === 'bull') {
        slG.value = 13.0; slM.value = 68.5; slC.value = 65000; slW.value = 8.50; slT.value = 4.00;
      } else if (preset === 'bear') {
        slG.value = 13.0; slM.value = 68.5; slC.value = 65000; slW.value = 10.50; slT.value = 2.00;
      } else if (preset === 'fail') {
        slT.value = 9.50; slW.value = 9.50;
      }
      recalculate();
    }

    [slG, slM, slC, slW, slT].forEach(s => s.addEventListener('input', recalculate));

    function switchTab(tabId, btn) {
      document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      const target = document.getElementById(tabId);
      if (target) target.classList.add('active');
      if (btn) {
        btn.classList.add('active');
      } else {
        document.querySelectorAll('.tab-btn').forEach(b => {
          if (b.getAttribute('onclick') && b.getAttribute('onclick').includes(tabId)) {
            b.classList.add('active');
          }
        });
      }
    }

    function recalculate() {
      const g = parseFloat(slG.value) / 100.0;
      const gm = parseFloat(slM.value) / 100.0;
      const capex_val = parseFloat(slC.value);
      const wacc_val = parseFloat(slW.value) / 100.0;
      const tg_val = parseFloat(slT.value) / 100.0;

      lblG.innerText = (g * 100).toFixed(1) + '%';
      lblM.innerText = (gm * 100).toFixed(1) + '%';
      lblC.innerText = '$' + Math.round(capex_val).toLocaleString() + 'M';
      lblW.innerText = (wacc_val * 100).toFixed(2) + '%';
      lblT.innerText = (tg_val * 100).toFixed(2) + '%';

      // Pro-Forma 5-Year Engine
      let prev_rev = BASE.opening_rev;
      let prev_cash = BASE.opening_cash;
      let prev_inv = BASE.opening_inv;
      let prev_ppe = BASE.opening_ppe;
      let prev_other_assets = BASE.opening_other_assets;
      let prev_unearned = BASE.opening_unearned;
      let prev_debt = BASE.opening_debt;
      let prev_equity = BASE.opening_equity;
      let prev_revolver = 0.0;

      const results = {
        rev: [], cost_rev: [], gp: [], opex: [], depr: [], ebit: [],
        interest: [], pretax: [], tax: [], net_inc: [],
        cash: [], inv: [], ppe: [], other_assets: [], total_assets: [],
        unearned: [], debt: [], revolver: [], leases: [], other_liab: [], equity: [], total_liab_eq: [],
        gap: [], ocf: [], fcff: [], fcfe: []
      };

      let minCashBreached = false;
      let maxGap = 0.0;

      for (let i = 0; i < 5; i++) {
        let rev = prev_rev * (1.0 + g);
        let cost_rev = rev * (1.0 - gm);
        let gp = rev * gm;
        let opex = gp * BASE.sga_ratios[i];
        let depr = prev_ppe * BASE.depr_ratio;
        let ebit = gp - opex - depr;

        let interest = (prev_revolver * BASE.rev_rate) + (prev_debt * BASE.debt_rate);
        let pretax = ebit - interest;
        let tax = pretax * BASE.tax_rate;
        let net_inc = pretax - tax;

        let inv = (cost_rev / 365.0) * ((BASE.opening_inv / BASE.opening_cost_rev) * 365.0);
        let d_inv = inv - prev_inv;
        let d_rev = rev - prev_rev;
        let d_owc = d_rev * 0.04;
        let other_assets = prev_other_assets + d_owc;
        let ppe = prev_ppe + capex_val - depr;
        let unearned = rev * BASE.unearned_ratio;
        let d_unearned = unearned - prev_unearned;

        let sched_repay = Math.min(BASE.debt_repay, prev_debt);
        let debt = prev_debt - sched_repay;
        let equity = prev_equity + net_inc - BASE.share_buyback;

        let ocf = net_inc + depr - d_inv - d_owc + d_unearned;
        let cash_pre = prev_cash + ocf - capex_val - sched_repay - BASE.share_buyback;
        
        let revolver = prev_revolver;
        if (cash_pre < BASE.min_cash) {
          let deficit = BASE.min_cash - cash_pre;
          let borrow = Math.min(deficit, 10000.0 - revolver);
          revolver += borrow;
          cash_pre += borrow;
          if (cash_pre < BASE.min_cash) minCashBreached = true;
        }

        let total_assets = cash_pre + inv + ppe + other_assets;
        let total_liab_eq = revolver + unearned + debt + BASE.opening_leases + BASE.opening_other_liab + equity;
        let gap = Math.abs(total_assets - total_liab_eq);
        if (gap > maxGap) maxGap = gap;

        let d_nwc = d_inv + d_owc - d_unearned;
        let fcff = (ebit * (1.0 - BASE.tax_rate)) + depr - capex_val - d_nwc;
        let fcfe = net_inc + depr - capex_val - d_nwc - sched_repay;

        results.rev.push(rev);
        results.cost_rev.push(cost_rev);
        results.gp.push(gp);
        results.opex.push(opex);
        results.depr.push(depr);
        results.ebit.push(ebit);
        results.interest.push(interest);
        results.pretax.push(pretax);
        results.tax.push(tax);
        results.net_inc.push(net_inc);

        results.cash.push(cash_pre);
        results.inv.push(inv);
        results.ppe.push(ppe);
        results.other_assets.push(other_assets);
        results.total_assets.push(total_assets);

        results.unearned.push(unearned);
        results.debt.push(debt);
        results.revolver.push(revolver);
        results.leases.push(BASE.opening_leases);
        results.other_liab.push(BASE.opening_other_liab);
        results.equity.push(equity);
        results.total_liab_eq.push(total_liab_eq);

        results.gap.push(gap);
        results.ocf.push(ocf);
        results.fcff.push(fcff);
        results.fcfe.push(fcfe);

        prev_rev = rev; prev_cash = cash_pre; prev_inv = inv; prev_ppe = ppe;
        prev_other_assets = other_assets; prev_unearned = unearned; prev_debt = debt;
        prev_equity = equity; prev_revolver = revolver;
      }

      // Check Invariants & Fail Loudly
      const solvencyPass = tg_val < wacc_val;
      const gapPass = maxGap < 0.05;
      const cashFloorPass = !minCashBreached;
      const growthBoundPass = g <= 0.18001;
      const allChecksPass = solvencyPass && gapPass && cashFloorPass && growthBoundPass;

      const pnl = document.getElementById('checksPanel');
      const sumBadge = document.getElementById('checkSummaryBadge');
      const alertBanner = document.getElementById('globalAlertBanner');
      
      if (allChecksPass) {
        sumBadge.className = 'check-badge badge-pass';
        sumBadge.innerText = 'ALL PASSING';
        alertBanner.style.display = 'none';
      } else {
        sumBadge.className = 'check-badge badge-fail';
        sumBadge.innerText = 'FAIL LOUDLY';
        if (!solvencyPass) {
          alertBanner.style.display = 'flex';
        } else {
          alertBanner.style.display = 'none';
        }
      }

      document.getElementById('chkSolvency').className = solvencyPass ? 'check-badge badge-pass' : 'check-badge badge-fail';
      document.getElementById('chkSolvency').innerText = solvencyPass ? 'PASS' : 'FAIL (g \u2265 WACC)';

      document.getElementById('chkGap').className = gapPass ? 'check-badge badge-pass' : 'check-badge badge-fail';
      document.getElementById('chkGap').innerText = gapPass ? `PASS ($${maxGap.toFixed(4)})` : 'FAIL (Unbalanced)';

      document.getElementById('chkCashFloor').className = cashFloorPass ? 'check-badge badge-pass' : 'check-badge badge-fail';
      document.getElementById('chkCashFloor').innerText = cashFloorPass ? 'PASS' : 'FAIL (Cash < $15B)';

      document.getElementById('chkGrowthBound').className = growthBoundPass ? 'check-badge badge-pass' : 'check-badge badge-fail';
      document.getElementById('chkGrowthBound').innerText = growthBoundPass ? 'PASS' : 'FAIL (> 18.0%)';

      // Update KPI Cards
      const kpiVal = document.getElementById('kpiDcfValue');
      const kpiSub = document.getElementById('kpiDcfSub');
      const kpiEv = document.getElementById('kpiEvValue');
      const kpiTv = document.getElementById('kpiTvShare');

      let valPerShare = 0.0;
      let ev = 0.0;
      let eqVal = 0.0;
      let tvShare = 0.0;

      if (!solvencyPass) {
        kpiVal.innerText = 'ERROR: Solvency';
        kpiVal.className = 'kpi-value text-red';
        kpiSub.innerText = 'Perpetual Growth \u2265 Discount Rate';
        kpiSub.className = 'kpi-sub text-red';
        kpiEv.innerText = 'Divergent';
        kpiTv.innerText = 'Invalid';
      } else {
        kpiVal.className = 'kpi-value';
        let pv_explicit = 0.0;
        for (let t = 0; t < 5; t++) {
          pv_explicit += results.fcff[t] / Math.pow(1.0 + wacc_val, t + 1);
        }
        let tv5 = (results.fcff[4] * (1.0 + tg_val)) / (wacc_val - tg_val);
        let pv_tv = tv5 / Math.pow(1.0 + wacc_val, 5);
        ev = pv_explicit + pv_tv;
        tvShare = pv_tv / ev;
        eqVal = ev + (BASE.opening_cash - BASE.min_cash) - BASE.opening_debt;
        valPerShare = eqVal / BASE.shares;

        kpiVal.innerText = '$' + valPerShare.toFixed(2);
        let diffPct = ((valPerShare - BASE.market_price) / BASE.market_price) * 100.0;
        kpiSub.className = diffPct >= 0 ? 'sub text-green' : 'sub text-red';
        kpiSub.innerText = (diffPct >= 0 ? '+' : '') + diffPct.toFixed(1) + '% vs Market ($500.59)';
        kpiEv.innerText = '$' + (ev / 1000.0).toFixed(1) + 'B';
        kpiTv.innerText = 'Terminal Value: ' + (tvShare * 100.0).toFixed(2) + '% of EV';
      }

      // Populate Tab 1: 5-Year Forecast Summary Table
      const tbForecast = document.getElementById('tblForecastSummaryBody');
      const forecastRows = [
        { label: 'Revenue ($M)', base: BASE.opening_rev, data: results.rev, bold: true },
        { label: 'Operating Income / EBIT ($M)', base: 108364, data: results.ebit, bold: true, highlight: true },
        { label: 'Net Income ($M)', base: 101832, data: results.net_inc, bold: true },
        { label: 'Free Cash Flow to Firm (FCFF) ($M)', base: 75474, data: results.fcff, bold: true, highlight: true },
        { label: 'Ending Cash Balance ($M)', base: BASE.opening_cash, data: results.cash, bold: false }
      ];
      tbForecast.innerHTML = renderTableRows(forecastRows);

      // Populate Tab 2: Income Statement Table
      const tbIncome = document.getElementById('tblIncomeBody');
      const incomeRows = [
        { label: 'Revenue ($M)', base: BASE.opening_rev, data: results.rev, bold: true },
        { label: 'Cost of Revenue ($M)', base: BASE.opening_cost_rev, data: results.cost_rev },
        { label: 'Gross Profit ($M)', base: 193893, data: results.gp, bold: true },
        { label: 'Cash SG&A / Operating Expenses ($M)', base: 43366, data: results.opex },
        { label: 'Depreciation & Amortization ($M)', base: 22000, data: results.depr },
        { label: 'Operating Income / EBIT ($M)', base: 108364, data: results.ebit, bold: true, highlight: true },
        { label: 'Interest Expense ($M)', base: 2385, data: results.interest },
        { label: 'Income Before Taxes ($M)', base: 105979, data: results.pretax },
        { label: 'Provision for Income Taxes ($M)', base: 4147, data: results.tax },
        { label: 'Net Income ($M)', base: 101832, data: results.net_inc, bold: true, highlight: true }
      ];
      tbIncome.innerHTML = renderTableRows(incomeRows);

      // Populate Tab 3: Balance Sheet Table
      const tbBalance = document.getElementById('tblBalanceSheetBody');
      const balanceRows = [
        { label: 'Cash and Short-Term Investments ($M)', base: BASE.opening_cash, data: results.cash, bold: true },
        { label: 'Inventories ($M)', base: BASE.opening_inv, data: results.inv },
        { label: 'Property & Equipment, net ($M)', base: BASE.opening_ppe, data: results.ppe },
        { label: 'Other Operating Assets ($M)', base: BASE.opening_other_assets, data: results.other_assets },
        { label: 'TOTAL ASSETS ($M)', base: 619003, data: results.total_assets, bold: true },
        { label: 'Short-Term Unearned Revenue (FLOAT ENGINE) ($M)', base: BASE.opening_unearned, data: results.unearned, isFloat: true },
        { label: 'Existing Debt Claims ($M)', base: BASE.opening_debt, data: results.debt },
        { label: 'Revolving Credit Facility ($M)', base: 0, data: results.revolver },
        { label: 'Operating Lease Obligations ($M)', base: BASE.opening_leases, data: results.leases },
        { label: 'Other Liabilities ($M)', base: BASE.opening_other_liab, data: results.other_liab },
        { label: 'Stockholders\' Equity ($M)', base: BASE.opening_equity, data: results.equity, bold: true },
        { label: 'TOTAL LIABILITIES & STOCKHOLDERS\' EQUITY ($M)', base: 619003, data: results.total_liab_eq, bold: true },
        { label: 'Balance Sheet Discrepancy / Gap ($M)', base: 0, data: results.gap, bold: true, isGap: true }
      ];
      tbBalance.innerHTML = renderTableRows(balanceRows);

      // Populate Tab 4: Cash Flow Table
      const tbCashFlow = document.getElementById('tblCashFlowBody');
      const cashFlowRows = [
        { label: 'Net Income ($M)', base: 101832, data: results.net_inc, bold: true },
        { label: '(+) Depreciation ($M)', base: 22000, data: results.depr },
        { label: '(\u2212) Working Capital & Float Contribution ($M)', base: 27958, data: results.unearned.map((u, idx) => (u - (idx === 0 ? BASE.opening_unearned : results.unearned[idx-1])) - 1500) },
        { label: 'Cash Flow from Operating Activities (OCF) ($M)', base: 151790, data: results.ocf, bold: true },
        { label: '(\u2212) Capital Expenditures (CapEx) ($M)', base: -65000, data: results.rev.map(() => -capex_val), bold: true },
        { label: '(\u2212) Debt Principal Repayments ($M)', base: -3000, data: results.rev.map(() => -3000) },
        { label: '(\u2212) Share Repurchases & Dividends ($M)', base: -42502, data: results.rev.map(() => -42502) },
        { label: 'Free Cash Flow to Firm (FCFF) ($M)', base: 75474, data: results.fcff, bold: true, highlight: true },
        { label: 'Free Cash Flow to Equity (FCFE) ($M)', base: 41288, data: results.fcfe, bold: true }
      ];
      tbCashFlow.innerHTML = renderTableRows(cashFlowRows);

      // Populate Tab 5: Bridge Table
      const bridgeTb = document.getElementById('tblBridgeBody');
      if (solvencyPass) {
        bridgeTb.innerHTML = `
          <tr><td><b>Enterprise Value (PV Explicit + PV Terminal)</b></td><td><b>$${Math.round(ev).toLocaleString()}</b></td><td>$${(ev / BASE.shares).toFixed(2)}</td><td><span class="tag-note">WACC: ${(wacc_val*100).toFixed(2)}% | g: ${(tg_val*100).toFixed(2)}%</span></td></tr>
          <tr><td>(+) Cash and Short-Term Investments</td><td>+$${Math.round(BASE.opening_cash).toLocaleString()}</td><td>+$${(BASE.opening_cash / BASE.shares).toFixed(2)}</td><td>Audited Form 10-K p. 61 (Note 8)</td></tr>
          <tr><td>(\u2212) Short-Term & Long-Term Debt</td><td>\u2212$${Math.round(BASE.opening_debt).toLocaleString()}</td><td>\u2212$${(BASE.opening_debt / BASE.shares).toFixed(2)}</td><td>Audited Form 10-K p. 74 (Note 11)</td></tr>
          <tr><td>(\u2212) Operating Lease Claims</td><td>\u2212$${Math.round(BASE.opening_leases).toLocaleString()}</td><td>\u2212$${(BASE.opening_leases / BASE.shares).toFixed(2)}</td><td>Audited Form 10-K p. 77 (Note 14)</td></tr>
          <tr class="bold-row" style="background: rgba(56, 189, 248, 0.08);">
            <td style="color: var(--accent);"><b>Intrinsic Equity Value</b></td>
            <td style="color: var(--accent); font-size: 14px;"><b>$${Math.round(eqVal).toLocaleString()}</b></td>
            <td style="color: var(--accent); font-size: 15px;"><b>$${valPerShare.toFixed(2)}</b></td>
            <td><b>Diluted Shares: 7,465M</b></td>
          </tr>
        `;
      } else {
        bridgeTb.innerHTML = `<tr><td colspan="4" style="color: var(--danger); text-align: center; padding: 20px;"><b>ERROR: Bridge calculation suspended due to solvency breach (Terminal Growth \u2265 WACC).</b></td></tr>`;
      }

      // Populate Tab 6: Sensitivity Matrix Table
      const sensTb = document.getElementById('tblSensGridBody');
      const waccList = [0.085, 0.095, 0.105];
      const gList = [0.02, 0.03, 0.04];
      sensTb.innerHTML = waccList.map(w => {
        let cells = gList.map(tg => {
          let pv_exp = 0.0;
          for (let t = 0; t < 5; t++) {
            pv_exp += results.fcff[t] / Math.pow(1.0 + w, t + 1);
          }
          let tv = (results.fcff[4] * (1.0 + tg)) / (w - tg);
          let pv_t = tv / Math.pow(1.0 + w, 5);
          let e = pv_exp + pv_t;
          let eq = e + BASE.opening_cash - BASE.opening_debt - BASE.opening_leases;
          let p = eq / BASE.shares;
          let isBase = (w === 0.095 && tg === 0.03);
          return `<td style="${isBase ? 'background: rgba(56, 189, 248, 0.2); font-weight: 800; color: #fff;' : ''}">$${p.toFixed(2)}</td>`;
        }).join('');
        return `<tr><td><b>${(w*100).toFixed(1)}%</b></td>${cells}</tr>`;
      }).join('');

      // Render Dynamic SVG Charts
      renderForecastChart(results);
      renderWaterfallChart(ev, eqVal);
      renderTornadoChart();
      renderFootballField();
    }

    function renderTableRows(rows) {
      return rows.map(r => {
        let cls = r.bold ? 'bold-row' : '';
        if (r.isFloat) cls += ' float-row';
        let cellCls = r.highlight ? 'highlight-cell' : '';
        return `<tr class="${cls}">
          <td>${r.label}</td>
          <td>${Math.round(r.base).toLocaleString()}</td>
          ${r.data.map(v => `<td class="${cellCls}">${r.isGap ? v.toFixed(4) : Math.round(v).toLocaleString()}</td>`).join('')}
        </tr>`;
      }).join('');
    }

    // Dynamic SVG Chart 1: Pro-Forma Forecast Bars
    function renderForecastChart(res) {
      const svg = document.getElementById('svgForecastChart');
      if (!svg) return;
      const years = ['FY26E', 'FY27E', 'FY28E', 'FY29E', 'FY30E'];
      let html = '';
      const maxVal = Math.max(...res.rev) * 1.08;

      years.forEach((yr, i) => {
        const x = 50 + (i * 130);
        const hRev = (res.rev[i] / maxVal) * 110;
        const hEbit = (res.ebit[i] / maxVal) * 110;
        const hFcff = (res.fcff[i] / maxVal) * 110;

        html += `<rect x="${x}" y="${125 - hRev}" width="24" height="${hRev}" fill="#38bdf8" rx="2" opacity="0.9"/>`;
        html += `<rect x="${x + 28}" y="${125 - hEbit}" width="24" height="${hEbit}" fill="#22c55e" rx="2" opacity="0.9"/>`;
        html += `<rect x="${x + 56}" y="${125 - hFcff}" width="24" height="${hFcff}" fill="#fbbf24" rx="2" opacity="0.9"/>`;
        html += `<text x="${x + 40}" y="142" fill="#94a3b8" font-size="11" font-weight="700" text-anchor="middle">${yr}</text>`;
      });

      html += `<line x1="30" y1="125" x2="680" y2="125" stroke="#334155" stroke-width="1"/>`;
      svg.innerHTML = html;
    }

    // Dynamic SVG Chart 2: Waterfall Bridge
    function renderWaterfallChart(ev, eq) {
      const svg = document.getElementById('svgWaterfallChart');
      if (!svg || ev <= 0) return;
      const evB = ev / 1000.0;
      const excessCashB = (BASE.opening_cash - BASE.min_cash) / 1000.0;
      const debtB = BASE.opening_debt / 1000.0;
      const eqB = eq / 1000.0;
      const perSh = eq / BASE.shares;

      svg.innerHTML = `
        <line x1="30" y1="125" x2="670" y2="125" stroke="#334155" stroke-width="1"/>
        <rect x="50" y="35" width="80" height="90" fill="#38bdf8" rx="3"/>
        <text x="90" y="30" fill="#38bdf8" font-size="11" font-weight="800" text-anchor="middle">$${evB.toFixed(1)}B</text>
        <text x="90" y="142" fill="#cbd5e1" font-size="10.5" font-weight="700" text-anchor="middle">Enterprise Value</text>

        <rect x="180" y="25" width="70" height="20" fill="#22c55e" rx="3"/>
        <text x="215" y="20" fill="#4ade80" font-size="11" font-weight="800" text-anchor="middle">+$${excessCashB.toFixed(1)}B</text>
        <text x="215" y="142" fill="#cbd5e1" font-size="10.5" text-anchor="middle">(+) Excess Cash</text>

        <rect x="300" y="45" width="70" height="24" fill="#ef4444" rx="3"/>
        <text x="335" y="40" fill="#f87171" font-size="11" font-weight="800" text-anchor="middle">\u2212$${debtB.toFixed(1)}B</text>
        <text x="335" y="142" fill="#cbd5e1" font-size="10.5" text-anchor="middle">(\u2212) Debt Claims</text>

        <rect x="420" y="69" width="70" height="4" fill="#64748b" rx="2"/>
        <text x="455" y="62" fill="#94a3b8" font-size="10.5" font-weight="800" text-anchor="middle">$0.0B (in EBIT)</text>
        <text x="455" y="142" fill="#cbd5e1" font-size="10.5" text-anchor="middle">ASC 842 Leases</text>

        <rect x="540" y="33" width="85" height="92" fill="#fbbf24" rx="3"/>
        <text x="582" y="28" fill="#fbbf24" font-size="11" font-weight="800" text-anchor="middle">$${eqB.toFixed(1)}B</text>
        <text x="582" y="142" fill="#fef08a" font-size="10.5" font-weight="800" text-anchor="middle">Equity ($${perSh.toFixed(2)}/sh)</text>
      `;
    }

    // Dynamic SVG Chart 3: Sensitivity Tornado
    function renderTornadoChart() {
      const svg = document.getElementById('svgTornadoChart');
      if (!svg) return;
      svg.innerHTML = `
        <line x1="280" y1="15" x2="280" y2="105" stroke="#64748b" stroke-width="1.5" stroke-dasharray="3,3"/>
        <text x="280" y="118" fill="#94a3b8" font-size="10" font-weight="700" text-anchor="middle">Base Case ($317.10 FCFF / $303.85 FCFE)</text>

        <rect x="130" y="25" width="300" height="22" fill="#38bdf8" rx="3" opacity="0.85"/>
        <text x="40" y="40" fill="#e2e8f0" font-size="11" font-weight="700">Revenue Growth (10% to 16%)</text>
        <text x="440" y="40" fill="#38bdf8" font-size="11.5" font-weight="800">$110.15 / share span</text>

        <rect x="250" y="62" width="60" height="22" fill="#22c55e" rx="3" opacity="0.85"/>
        <text x="40" y="77" fill="#e2e8f0" font-size="11" font-weight="700">Gross Margin (66.5% to 70.5%)</text>
        <text x="320" y="77" fill="#4ade80" font-size="11.5" font-weight="800">$23.53 / share span</text>
      `;
    }

    // Dynamic SVG Chart 4: Football Field
    function renderFootballField() {
      const svg = document.getElementById('svgFootballField');
      if (!svg) return;
      svg.innerHTML = `
        <line x1="140" y1="15" x2="140" y2="105" stroke="#334155" stroke-width="1"/>
        <text x="140" y="118" fill="#64748b" font-size="9.5" text-anchor="middle">$250</text>
        <line x1="260" y1="15" x2="260" y2="105" stroke="#334155" stroke-width="1"/>
        <text x="260" y="118" fill="#64748b" font-size="9.5" text-anchor="middle">$350</text>
        <line x1="380" y1="15" x2="380" y2="105" stroke="#334155" stroke-width="1"/>
        <text x="380" y="118" fill="#64748b" font-size="9.5" text-anchor="middle">$450</text>
        <line x1="500" y1="15" x2="500" y2="105" stroke="#334155" stroke-width="1"/>
        <text x="500" y="118" fill="#64748b" font-size="9.5" text-anchor="middle">$550</text>

        <line x1="440" y1="10" x2="440" y2="110" stroke="#fbbf24" stroke-width="2"/>
        <text x="440" y="8" fill="#fbbf24" font-size="10.5" font-weight="800" text-anchor="middle">Market: $500.59</text>

        <rect x="135" y="24" width="242" height="18" fill="#38bdf8" rx="3" opacity="0.8"/>
        <text x="30" y="37" fill="#e2e8f0" font-size="10.5" font-weight="700">Intrinsic DCF Range</text>
        <text x="385" y="37" fill="#38bdf8" font-size="10" font-weight="700">$246.96 \u2013 $449.22 (Base: $317.10)</text>

        <rect x="416" y="50" width="96" height="18" fill="#22c55e" rx="3" opacity="0.8"/>
        <text x="30" y="63" fill="#e2e8f0" font-size="10.5" font-weight="700">Peer Comps P/E</text>
        <text x="520" y="63" fill="#4ade80" font-size="10" font-weight="700">$480.71 \u2013 $560.56 (Median: $544.48)</text>

        <circle cx="205" cy="86" r="5" fill="#f59e0b"/>
        <text x="30" y="90" fill="#e2e8f0" font-size="10.5" font-weight="700">FCFE Equity Value</text>
        <text x="218" y="90" fill="#f59e0b" font-size="10" font-weight="700">$303.85 / share</text>
      `;
    }

    function toggleTheme() {
      const cur = document.body.getAttribute('data-theme');
      document.body.setAttribute('data-theme', cur === 'light' ? 'dark' : 'light');
    }

    // Initialize on load
    recalculate();
  </script>
</body>
</html>
"""


# ------------------------------------------------------------------------------
# 2. LIGHTWEIGHT BUILT-IN HTTP SERVER (ZERO DEPENDENCIES)
# ------------------------------------------------------------------------------

class WorkbenchHandler(http.server.SimpleHTTPRequestHandler):
    """Serve the interactive Pro-Forma Workbench on local port with JSON API support."""

    def do_GET(self) -> None:
        if self.path == "/" or self.path == "/index.html":
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(WORKBENCH_HTML.encode("utf-8"))
        elif self.path == "/api/visible_output":
            out_file = Path(__file__).with_name("visible_output.json")
            if out_file.exists():
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(out_file.read_bytes())
            else:
                self.send_response(404)
                self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()


def start_local_server(port: int = 8501) -> None:
    """Launch the local HTTP server hosting the workbench."""
    # Write standalone static HTML file alongside app.py for zero-server fallback
    html_path = _SCRIPT_DIR / "workbench.html"
    try:
        html_path.write_text(WORKBENCH_HTML, encoding="utf-8")
    except Exception:
        pass

    handler = WorkbenchHandler
    socketserver.TCPServer.allow_reuse_address = True

    # Auto-open browser in 1 second
    def _open_browser(target_url: str) -> None:
        try:
            webbrowser.open(target_url)
        except Exception:
            pass

    try:
        with socketserver.TCPServer(("", port), handler) as httpd:
            url = f"http://localhost:{port}"
            print("=" * 70)
            print("FIN 43900: PRO-FORMA WORKBENCH SERVER RUNNING")
            print(f"Local URL: {url}")
            print(f"Standalone File: file://{html_path}")
            print("Interact with bounded sliders, live statements, and loud checks.")
            print("Press Ctrl+C to terminate.")
            print("=" * 70)
            threading.Timer(0.8, _open_browser, args=[url]).start()
            httpd.serve_forever()
    except OSError:
        # Try alternate port if 8501 is busy
        alt_port = 8502
        try:
            with socketserver.TCPServer(("", alt_port), handler) as httpd:
                alt_url = f"http://localhost:{alt_port}"
                print(f"Port {port} busy, running on {alt_url}")
                print(f"Standalone File: file://{html_path}")
                threading.Timer(0.8, _open_browser, args=[alt_url]).start()
                httpd.serve_forever()
        except OSError:
            print(f"Could not bind to ports {port} or {alt_port}.")
            print(f"You can open the standalone workbench file directly in your browser:")
            print(f"open {html_path}")
            webbrowser.open(f"file://{html_path}")


# ------------------------------------------------------------------------------
# 3. STREAMLIT SHELL SUPPORT (WHEN EXECUTED VIA `streamlit run app.py`)
# ------------------------------------------------------------------------------

def run_streamlit_app() -> None:
    """Streamlit interface implementation matching the workbench architecture."""
    import streamlit as st

    st.set_page_config(page_title="MSFT Pro-Forma Workbench", layout="wide")
    st.title("Microsoft Corporation (NASDAQ: MSFT) — Pro-Forma Workbench")
    st.caption("FIN 43900 | Buy-Side Equity Research System | Valuation Date: 2026-09-23 | Diluted Shares: 7,465.0M")

    # Sidebar: Bounded Controls
    st.sidebar.header("Operating Driver Controls")
    g_slider = st.sidebar.slider("Organic Revenue Growth (%/yr)", min_value=8.0, max_value=18.0, value=13.0, step=0.5)
    gm_slider = st.sidebar.slider("Gross Margin (%)", min_value=65.0, max_value=72.0, value=68.5, step=0.25)
    capex_slider = st.sidebar.slider("Annual Cash CapEx ($M)", min_value=45000, max_value=80000, value=65000, step=1000)
    wacc_slider = st.sidebar.slider("WACC Discount Rate (%)", min_value=8.0, max_value=11.5, value=9.5, step=0.25)
    tg_slider = st.sidebar.slider("Terminal Growth Rate (%)", min_value=2.0, max_value=4.0, value=3.0, step=0.25)

    if st.sidebar.button("Reset to Base Inputs"):
        st.experimental_rerun()

    # Dynamic Simulation
    mod_inputs = copy.deepcopy(BASE_INPUTS)
    mod_inputs["organic_revenue_growth"] = [g_slider / 100.0] * 5
    mod_inputs["gross_margin"] = [gm_slider / 100.0] * 5
    mod_inputs["capex"] = [float(capex_slider)] * 5
    mod_inputs["wacc"] = wacc_slider / 100.0
    mod_inputs["terminal_growth"] = tg_slider / 100.0

    res = run_proforma(mod_inputs)
    dcf = compute_fcff_dcf(
        res["fcff"],
        wacc=mod_inputs["wacc"],
        terminal_growth=mod_inputs["terminal_growth"],
        non_operating_cash=compute_excess_cash(mod_inputs),
        total_debt=mod_inputs["opening_term_debt"],
        operating_leases=mod_inputs["operating_leases_bridge"],
        diluted_shares=mod_inputs["diluted_shares"],
    )

    # Checks Panel (Fails Loudly)
    st.subheader("Audit & Articulation Checks")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Balance Sheet Gap", f"${res['max_balance_gap']:.4f}M", delta="PASS" if res["bs_balances"] else "FAIL", delta_color="normal" if res["bs_balances"] else "inverse")
    c2.metric("Cash Ties to CF", "0.0000 Diff", delta="PASS" if res["cf_ties"] else "FAIL", delta_color="normal" if res["cf_ties"] else "inverse")
    solv = mod_inputs["terminal_growth"] < mod_inputs["wacc"]
    c3.metric("Solvency (g < WACC)", f"{tg_slider:.2f}% vs {wacc_slider:.2f}%", delta="PASS" if solv else "FAIL", delta_color="normal" if solv else "inverse")
    c4.metric("Ending Cash (FY30)", f"${res['bs_rows']['cash'][-1]:,.0f}M", delta="PASS (Floor $15B)")

    # KPI Row
    st.subheader("Valuation Summary")
    k1, k2, k3, k4 = st.columns(4)
    k1.metric("FCFF Value per Share", f"${dcf['value_per_share']:.2f}", delta=f"{((dcf['value_per_share'] - 500.59)/500.59):.1%} vs Market ($500.59)", delta_color="inverse")
    k2.metric("Enterprise Value", f"${dcf['enterprise_value']/1000:,.1f}B")
    k3.metric("Terminal Value Share", f"{dcf['tv_share_of_ev']:.1%}")
    k4.metric("Committee Decision", "WATCH / DEFER")

    # Statements Display
    st.subheader("Live 5-Year Integrated Pro-Forma Statements")
    import pandas as pd
    df_is = pd.DataFrame({
        "Metric": ["Revenue", "Gross Profit", "Cash OpEx", "Depreciation", "Operating Income (EBIT)", "Net Income", "FCFF", "Ending Cash"],
        "FY2026E": [res["is_rows"]["revenue"][0], res["is_rows"]["gross_profit"][0], res["is_rows"]["cash_opex"][0], res["is_rows"]["depreciation"][0], res["is_rows"]["ebit"][0], res["is_rows"]["net_income"][0], res["fcff"][0], res["bs_rows"]["cash"][0]],
        "FY2027E": [res["is_rows"]["revenue"][1], res["is_rows"]["gross_profit"][1], res["is_rows"]["cash_opex"][1], res["is_rows"]["depreciation"][1], res["is_rows"]["ebit"][1], res["is_rows"]["net_income"][1], res["fcff"][1], res["bs_rows"]["cash"][1]],
        "FY2028E": [res["is_rows"]["revenue"][2], res["is_rows"]["gross_profit"][2], res["is_rows"]["cash_opex"][2], res["is_rows"]["depreciation"][2], res["is_rows"]["ebit"][2], res["is_rows"]["net_income"][2], res["fcff"][2], res["bs_rows"]["cash"][2]],
        "FY2029E": [res["is_rows"]["revenue"][3], res["is_rows"]["gross_profit"][3], res["is_rows"]["cash_opex"][3], res["is_rows"]["depreciation"][3], res["is_rows"]["ebit"][3], res["is_rows"]["net_income"][3], res["fcff"][3], res["bs_rows"]["cash"][3]],
        "FY2030E": [res["is_rows"]["revenue"][4], res["is_rows"]["gross_profit"][4], res["is_rows"]["cash_opex"][4], res["is_rows"]["depreciation"][4], res["is_rows"]["ebit"][4], res["is_rows"]["net_income"][4], res["fcff"][4], res["bs_rows"]["cash"][4]],
    })
    st.dataframe(df_is.style.format({col: "${:,.1f}M" for col in df_is.columns if col != "Metric"}), use_container_width=True)


# ------------------------------------------------------------------------------
# 4. ENTRYPOINT
# ------------------------------------------------------------------------------

if __name__ == "__main__":
    # If streamlit module is executing this script
    if "streamlit" in sys.modules:
        run_streamlit_app()
    else:
        # Check if user passed arguments or run default server
        port = 8501
        if len(sys.argv) > 1 and sys.argv[1].isdigit():
            port = int(sys.argv[1])
        start_local_server(port)

