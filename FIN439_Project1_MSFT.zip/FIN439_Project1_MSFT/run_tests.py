"""Comprehensive Validation and Verification Test Suite for Project 1.

Targets all requirements under Rubric Criterion 5 (Validation, Sensitivity, Reproducibility - 75 pts):
1. Synthetic & Known-Answer Training Case Reconciliations
2. Audited Base Year (FY2025 Form 10-K) Reconciliation
3. Three-Statement Articulation Invariant Checks (Balance Sheet Gap == 0.0, Cash Ties to CF)
4. Monotonicity & DCF Boundary Checks (WACC vs. Value, Terminal Growth vs. Value)
5. Enterprise-to-Equity Bridge Line-by-Line Reconciliation
6. Comparable Companies Policy & Multiples Consistency
7. Locked Changed-Input Test (AI-off Human Prediction vs. Execution)
8. Highest-Risk Stress / Failure Tests (Solvency Breach, Cash Floor Depletion, Extreme CapEx)
9. Cold-Run Verification
"""

from __future__ import annotations
import copy
import sys
import unittest

from analysis import (
    BASE_INPUTS,
    compute_excess_cash,
    run_proforma,
    compute_fcff_dcf,
    compute_fcfe_dcf,
    compute_wacc_growth_grid,
    compute_reverse_dcf,
    compute_comps_valuation,
    compute_oat_sensitivity,
    verify_synthetic_training_case,
)


class TestProject1Validation(unittest.TestCase):
    """Rigorous financial and technical validation test suite."""

    def setUp(self) -> None:
        self.inputs = copy.deepcopy(BASE_INPUTS)

    # --------------------------------------------------------------------------
    # 1. KNOWN-ANSWER SYNTHETIC RECONCILIATIONS
    # --------------------------------------------------------------------------
    def test_synthetic_bridge_reconciliation(self) -> None:
        """Verify the class known-answer synthetic enterprise-to-equity bridge ($8.20/sh)."""
        res = verify_synthetic_training_case()
        self.assertTrue(res["synth_bridge_passed"], "Synthetic bridge must match $8.20/share exactly.")
        self.assertEqual(res["synth_equity_value"], 820.0)
        self.assertEqual(res["synth_per_share"], 8.20)

    def test_training_case_dcf_reconciliation(self) -> None:
        """Verify the course training DCF model exactly produces $27.50/share base."""
        res = verify_synthetic_training_case()
        self.assertTrue(res["training_dcf_passed"], "Training DCF must match $27.50/share base.")
        self.assertEqual(res["training_base_share_value"], 27.50)

    # --------------------------------------------------------------------------
    # 2. BASE YEAR AUDITED FILING RECONCILIATION
    # --------------------------------------------------------------------------
    def test_base_year_reconciliation(self) -> None:
        """Reconcile opening balance sheet and income statement items to Form 10-K (June 30, 2025)."""
        # Form 10-K, Item 8, p. 59, 61, 62
        self.assertEqual(self.inputs["opening_revenue"], 281724.0)
        self.assertEqual(self.inputs["opening_cash"], 94565.0)  # Cash ($30,242) + ST Inv ($64,323)
        self.assertEqual(self.inputs["opening_ppe"], 204966.0)
        self.assertEqual(self.inputs["opening_unearned_rev"], 64555.0)
        self.assertEqual(self.inputs["opening_term_debt"], 43151.0)
        self.assertEqual(self.inputs["opening_equity"], 343479.0)
        self.assertEqual(self.inputs["diluted_shares"], 7465.0)

        # Base Year Balance Sheet Check: Assets == Liabilities + Equity
        total_assets = (
            self.inputs["opening_cash"]
            + self.inputs["opening_inventory"]
            + self.inputs["opening_ppe"]
            + self.inputs["opening_other_assets"]
        )
        total_liab_eq = (
            self.inputs["opening_revolver"]
            + self.inputs["opening_unearned_rev"]
            + self.inputs["opening_term_debt"]
            + self.inputs["opening_other_liabilities"]
            + self.inputs["opening_equity"]
        )
        self.assertEqual(round(total_assets, 1), 619003.0)
        self.assertEqual(round(total_liab_eq, 1), 619003.0)
        self.assertEqual(round(total_assets - total_liab_eq, 4), 0.0)

    # --------------------------------------------------------------------------
    # 3. THREE-STATEMENT PRO-FORMA ARTICULATION INVARIANTS
    # --------------------------------------------------------------------------
    def test_proforma_statement_articulation(self) -> None:
        """Verify balance sheet balances every year (gap=0.0) and cash flow ties to cash."""
        res = run_proforma(self.inputs)
        self.assertTrue(res["bs_balances"], f"Balance sheet must balance. Max gap was {res['max_balance_gap']}")
        self.assertTrue(res["cf_ties"], f"Cash flow must tie to balance sheet cash. Max diff was {res['max_cash_flow_diff']}")
        self.assertLess(res["max_balance_gap"], 1e-3)
        self.assertLess(res["max_cash_flow_diff"], 1e-3)

        # Check ending cash exceeds minimum cash floor of $15,000M across all 5 years
        for yr, cash in zip(res["years"], res["bs_rows"]["cash"]):
            self.assertGreaterEqual(cash, 15000.0, f"Cash in year {yr} ({cash}) fell below $15B floor")

    # --------------------------------------------------------------------------
    # 4. MONOTONICITY & BOUNDARY CHECKS
    # --------------------------------------------------------------------------
    def test_dcf_monotonicity_wacc(self) -> None:
        """Verify value per share decreases monotonically as WACC increases."""
        res = run_proforma(self.inputs)
        grid = compute_wacc_growth_grid(res["fcff"])["grid"]
        # grid[0] is WACC 8.5%, grid[1] is WACC 9.5%, grid[2] is WACC 10.5%
        for col_idx in range(3):
            val_85 = grid[0][col_idx]
            val_95 = grid[1][col_idx]
            val_105 = grid[2][col_idx]
            self.assertGreater(val_85, val_95, f"Monotonicity breach: 8.5% WACC ({val_85}) <= 9.5% WACC ({val_95})")
            self.assertGreater(val_95, val_105, f"Monotonicity breach: 9.5% WACC ({val_95}) <= 10.5% WACC ({val_105})")

    def test_dcf_monotonicity_growth(self) -> None:
        """Verify value per share increases monotonically as terminal growth increases."""
        res = run_proforma(self.inputs)
        grid = compute_wacc_growth_grid(res["fcff"])["grid"]
        # col 0 is g=2%, col 1 is g=3%, col 2 is g=4%
        for row_idx in range(3):
            val_g2 = grid[row_idx][0]
            val_g3 = grid[row_idx][1]
            val_g4 = grid[row_idx][2]
            self.assertGreater(val_g3, val_g2, f"Monotonicity breach: g=3% ({val_g3}) <= g=2% ({val_g2})")
            self.assertGreater(val_g4, val_g3, f"Monotonicity breach: g=4% ({val_g4}) <= g=3% ({val_g3})")

    # --------------------------------------------------------------------------
    # 5. ENTERPRISE-TO-EQUITY BRIDGE LINE-BY-LINE RECONCILIATION
    # --------------------------------------------------------------------------
    def test_enterprise_to_equity_bridge(self) -> None:
        """Verify enterprise-to-equity bridge arithmetic ($15B floor deducted, $0 lease double-count)."""
        res = run_proforma(self.inputs)
        excess_cash = compute_excess_cash(self.inputs)
        self.assertEqual(excess_cash, 79565.0)
        dcf = compute_fcff_dcf(
            res["fcff"],
            wacc=self.inputs["wacc"],
            terminal_growth=self.inputs["terminal_growth"],
            non_operating_cash=excess_cash,
            total_debt=self.inputs["opening_term_debt"],
            operating_leases=self.inputs["operating_leases_bridge"],
            diluted_shares=self.inputs["diluted_shares"],
        )
        ev = dcf["enterprise_value"]
        cash = dcf["non_operating_cash"]
        debt = dcf["total_debt"]
        leases = dcf["operating_leases"]
        equity = dcf["equity_value"]
        per_share = dcf["value_per_share"]

        # Mathematical bridge check (all terms explicit; ASC 842 lease cost already in EBIT/FCFF)
        self.assertEqual(leases, 0.0)
        self.assertEqual(round(equity, 2), round(ev + cash - debt - leases, 2))
        self.assertEqual(round(per_share, 2), 317.10)
        self.assertEqual(round(per_share, 4), round(equity / 7465.0, 4))
        self.assertGreater(dcf["tv_share_of_ev"], 0.70)
        self.assertLess(dcf["tv_share_of_ev"], 0.85)

    # --------------------------------------------------------------------------
    # 6. COMPARABLE COMPANIES POLICY & CONSISTENCY CHECK
    # --------------------------------------------------------------------------
    def test_comparable_companies_consistency(self) -> None:
        """Verify peer screening policy, P/E calculation, and leave-one-out stability."""
        comps = compute_comps_valuation()
        self.assertEqual(len(comps["peers"]), 3)
        self.assertGreater(comps["median_pe"], 35.0)
        self.assertLess(comps["median_pe"], 45.0)
        self.assertGreater(comps["implied_price_pe_median"], 450.0)
        self.assertLess(comps["implied_price_pe_median"], 600.0)

        # Leave-one-out sensitivity stability check
        for loo in comps["leave_one_out"]:
            self.assertLess(abs(loo["change_from_full_median"]), 40.0)

    # --------------------------------------------------------------------------
    # 7. LOCKED CHANGED-INPUT TEST (FCFF HEADLINE DECISION-BOUNDARY TEST)
    # --------------------------------------------------------------------------
    def test_locked_changed_input_record(self) -> None:
        """Verify FCFF headline changed-input test: +9.0 pct-pt growth shift flips WATCH/DEFER to INITIATE BUY.

        Precommit Details:
        - Headline Metric: FCFF Intrinsic Equity Value per Diluted Share
        - Input: Organic Revenue Growth Rate (FY2026E–FY2030E) shifted from 13.00% to 22.00% / yr
        - Prediction:
          1. Direction: Value per share must rise (+).
          2. Magnitude expectation: Value per share rises by +$185 to +$205/share (from $317.10 to ~$505-$520).
          3. Decision effect: FLIPS recommendation from WATCH / DEFER to INITIATE BUY (> $500.59 market price).
        """
        base_res = run_proforma(self.inputs)
        excess_cash = compute_excess_cash(self.inputs)
        base_fcff_val = compute_fcff_dcf(
            base_res["fcff"],
            wacc=self.inputs["wacc"],
            terminal_growth=self.inputs["terminal_growth"],
            non_operating_cash=excess_cash,
            total_debt=self.inputs["opening_term_debt"],
            operating_leases=self.inputs["operating_leases_bridge"],
            diluted_shares=self.inputs["diluted_shares"],
        )["value_per_share"]

        # Apply Changed Input (22.0% growth crossing 21.58% Reverse-DCF hurdle)
        mod_inputs = copy.deepcopy(self.inputs)
        mod_inputs["organic_revenue_growth"] = [0.220] * 5
        changed_res = run_proforma(mod_inputs)
        changed_fcff_val = compute_fcff_dcf(
            changed_res["fcff"],
            wacc=mod_inputs["wacc"],
            terminal_growth=mod_inputs["terminal_growth"],
            non_operating_cash=compute_excess_cash(mod_inputs),
            total_debt=mod_inputs["opening_term_debt"],
            operating_leases=mod_inputs["operating_leases_bridge"],
            diluted_shares=mod_inputs["diluted_shares"],
        )["value_per_share"]

        delta_val = changed_fcff_val - base_fcff_val
        self.assertGreater(delta_val, 0.0, "Output direction must be positive (+)")
        self.assertAlmostEqual(round(base_fcff_val, 2), 317.10, places=2)
        self.assertAlmostEqual(round(changed_fcff_val, 2), 510.92, places=2)
        self.assertAlmostEqual(round(delta_val, 2), 193.82, delta=0.05)
        self.assertGreater(changed_fcff_val, self.inputs["current_market_price"], "Decision must flip to INITIATE BUY above $500.59")

    # --------------------------------------------------------------------------
    # 8. HIGHEST-RISK STRESS / FAILURE TESTS
    # --------------------------------------------------------------------------
    def test_extreme_solvency_failure(self) -> None:
        """Verify model fails loudly when Terminal Growth >= WACC."""
        res = compute_fcff_dcf([100000.0] * 5, wacc=0.08, terminal_growth=0.08)
        self.assertIn("error", res, "Engine must return error when terminal growth >= WACC")

    def test_recession_and_revolver_draw(self) -> None:
        """Verify model handles severe downside shock (negative growth + CapEx surge) with revolver draw."""
        stress_inputs = copy.deepcopy(self.inputs)
        stress_inputs["organic_revenue_growth"] = [-0.05, -0.02, 0.02, 0.05, 0.08]
        stress_inputs["gross_margin"] = [0.60] * 5  # Severe margin compression
        stress_inputs["capex"] = [85000.0] * 5      # Extreme CapEx drain
        stress_res = run_proforma(stress_inputs)

        # Invariant: Balance sheet MUST still balance under extreme distress!
        self.assertTrue(stress_res["bs_balances"], "Distress scenario broke balance sheet articulation")
        self.assertLess(stress_res["max_balance_gap"], 1e-3)

    # --------------------------------------------------------------------------
    # 9. COLD-RUN INTEGRITY & LOUD CROSS-FILE RECONCILIATION
    # --------------------------------------------------------------------------
    def test_cold_run_execution(self) -> None:
        """Verify complete end-to-end execution with pristine input copy."""
        from analysis import execute_full_project_analysis
        output = execute_full_project_analysis()
        self.assertIn("valuation_summary", output)
        self.assertEqual(output["committee_decision"], "WATCH / DEFER")

    def test_cross_file_reconciliation_loud(self) -> None:
        """Fail loudly if visible_output.json, memos, README, UI, or video transcripts diverge."""
        import json
        from pathlib import Path

        root = Path(__file__).resolve().parent
        data = json.loads((root / "visible_output.json").read_text(encoding="utf-8"))
        fcff_ps = f"{data['valuation_summary']['fcff_base_value_per_share']:.2f}"
        eq_val = f"{data['valuation_summary']['fcff_equity_value']:,.1f}"
        low_c = f"{data['valuation_summary']['wacc_growth_grid']['low_corner']:.2f}"
        high_c = f"{data['valuation_summary']['wacc_growth_grid']['high_corner']:.2f}"
        rev_cagr = f"{data['valuation_summary']['reverse_dcf']['implied_growth_path'][0]:.2f}"
        locked_after = f"{data['locked_changed_input']['fcff_after_per_share']:.2f}"
        locked_delta = f"{data['locked_changed_input']['delta_per_share']:.2f}"

        checked_texts = {
            "Decision-Memo.md": (root / "Decision-Memo.md").read_text(encoding="utf-8"),
            "Research-Evolution.md": (root / "Research-Evolution.md").read_text(encoding="utf-8"),
            "Validation-and-AI-Use.md": (root / "Validation-and-AI-Use.md").read_text(encoding="utf-8"),
            "README.md": (root / "README.md").read_text(encoding="utf-8"),
            "app.py": (root / "app.py").read_text(encoding="utf-8"),
            "workbench.html": (root / "workbench.html").read_text(encoding="utf-8"),
            "transcript-video-1.txt": (root / "transcript-video-1.txt").read_text(encoding="utf-8"),
            "transcript-video-2.txt": (root / "transcript-video-2.txt").read_text(encoding="utf-8"),
            "transcript-video-3.txt": (root / "transcript-video-3.txt").read_text(encoding="utf-8"),
        }

        stale_forbidden = ["316.63", "448.76", "246.49", "2,363,668.8", "2363668.8", "9d9e449", "$307.90-$312.45", "four hundred sixty-four billion"]
        for fname, text in checked_texts.items():
            for bad in stale_forbidden:
                self.assertNotIn(bad, text, f"Stale value '{bad}' found in {fname}")

        for fname in ("Decision-Memo.md", "Research-Evolution.md", "Validation-and-AI-Use.md", "README.md", "app.py", "workbench.html"):
            t = checked_texts[fname]
            self.assertIn(fcff_ps, t, f"FCFF base ${fcff_ps} missing in {fname}")
            self.assertIn(low_c, t, f"Low corner ${low_c} missing in {fname}")
            self.assertIn(high_c, t, f"High corner ${high_c} missing in {fname}")
            self.assertIn(rev_cagr, t, f"Reverse DCF CAGR {rev_cagr}% missing in {fname}")

        self.assertIn(eq_val, checked_texts["Decision-Memo.md"])
        self.assertIn(eq_val, checked_texts["Validation-and-AI-Use.md"])
        self.assertIn(eq_val, checked_texts["README.md"])
        self.assertIn(locked_after, checked_texts["Validation-and-AI-Use.md"])
        self.assertIn(locked_delta, checked_texts["Validation-and-AI-Use.md"])

        # docs/ copies must match root files
        self.assertEqual(checked_texts["Decision-Memo.md"], (root / "docs" / "decision-memo.md").read_text(encoding="utf-8"))
        self.assertEqual(checked_texts["Research-Evolution.md"], (root / "docs" / "research-evolution.md").read_text(encoding="utf-8"))
        self.assertEqual(checked_texts["Validation-and-AI-Use.md"], (root / "docs" / "validation-and-ai-use.md").read_text(encoding="utf-8"))
        for i in (1, 2, 3):
            self.assertEqual(
                checked_texts[f"transcript-video-{i}.txt"],
                (root / "docs" / f"transcript-video-{i}.txt").read_text(encoding="utf-8"),
            )


if __name__ == "__main__":
    suite = unittest.TestLoader().loadTestsFromTestCase(TestProject1Validation)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    if not result.wasSuccessful():
        sys.exit(1)

