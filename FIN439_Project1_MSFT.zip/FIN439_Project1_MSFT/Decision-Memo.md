# Buy-Side Investment Committee Memorandum
Target: Microsoft Corporation (NASDAQ: MSFT, CIK: 0000789019) | Security: Common Stock (7,465.0M diluted shares)
Valuation Date: September 23, 2026 | Market Price: $500.59 | Author: Equity Research Analyst (Fund holds no position)

================================================================================
1. RECOMMENDATION AND COMMITTEE ASK: WATCH / DEFER
================================================================================

I advise the committee to defer initiating a position in Microsoft Corporation at $500.59. My fundamental 5-year linked pro-forma valuation establishes an intrinsic DCF equity value of $317.10 per share (FCFF base) and an operational cash-flow value of $303.85 per share (FCFE base). The prevailing market price trades at an unjustifiable +57.9% premium to cash-backed operating value.

Valuation Ranges Across Methods (Never Mechanically Averaged):
- Intrinsic DCF Range (WACC 8.5% to 10.5%, g 2.0% to 4.0%): $246.96 to $449.22 per share (Central Base: $317.10).
- Pro-Forma OAT Operating Range (Growth 10.0% to 16.0%): $255.77 to $365.92 per share (Base: $303.85 FCFE).
- Comparable Companies Relative Range (Peer P/E 35.24x to 41.09x): $480.71 to $560.56 per share (Peer Median: $544.48 at 39.91x).
- Committee Ask: (1) Authorize Watch / Defer status with $0 capital committed; (2) Direct me to audit Microsoft's Q1 FY2027 Form 10-Q in October 2026.

================================================================================
2. DECISION EVIDENCE AND POINT-IN-TIME BOUNDARY
================================================================================

Audited as of September 23, 2026, anchored strictly to Form 10-K ended June 30, 2025 (SEC Accession: 0000950170-25-100235, filed July 30, 2025):
- Why FY2025 10-K is the Base on Sept 23, 2026: Although Microsoft's FY2026 ended June 30, 2026 (Q4 FY26 earnings release issued July 29, 2026), this model anchors strictly to the audited FY2025 Form 10-K so every balance sheet identity and footnote (Notes 4, 7, 8, 10, 12, 18) reconciles identically without mixing unaudited press-release lines. Rolling the base to the FY2026 Form 10-K footnotes is scheduled as the next model update.
- Operating Revenue Engine: FY25 revenue reached $281,724M (+15.0% organic YoY), driven by Microsoft Cloud revenue of $168.9B (+23% YoY) and Azure consumption growth of +34% (Item 7 MD&A, pp. 33-38).
- Gross Margin & AI Cost Drag: Gross margin was 68.82% ($193,893M). Management disclosed (p. 36) that AI datacenter electricity and GPU server costs compressed cloud margins by 32 bps.
- Capital Intensity Surge: Cash CapEx surged from $28,107M in FY23 to $44,475M in FY24 and $64,551M in FY25 (Item 8, p. 62), with net physical PP&E doubling from $95.6B to $204.97B in two years.
- Code-Generated Enterprise-to-Equity Bridge (Every Term Printed from analysis.py):
  - Enterprise Value (PV Explicit + PV Terminal Value): $2,330,739.8M
  - (+) Gross Cash & Short-Term Investments (Note 4): +$94,565.0M ($30,242M cash + $64,323M ST investments)
  - (-) Operating Cash Floor (~20 days cash OpEx): -$15,000.0M -> Excess Non-Operating Cash: +$79,565.0M
  - (-) Total Debt Principal (Note 10): -$43,151.0M ($2,999M current + $40,152M LT debt)
  - (-) Operating Leases (ASC 842 Note 8: $18,485.0M disclosed): $0.0M deducted (ASC 842 lease expense is already deducted in EBIT and FCFF; deducting the liability again would double-count)
  - (=) Implied Common Equity Value: $2,367,153.8M / 7,465.0M Diluted Common Shares (Note 18, p. 94) = $317.10 per share.

================================================================================
3. MATERIAL ASSUMPTIONS, MODEL ARCHITECTURE, AND SENSITIVITIES
================================================================================

- Unearned Revenue Float Engine ($64,555M, 22.9143% of rev): Upfront enterprise subscription prepayments at 0.0% interest generate +$8.4B to +$13.7B per year in positive working-capital cash inflows, internally funding ~20% of Microsoft's $65B CapEx.
- Locked Depreciation: Modeled at 10.7335% of opening net PP&E (Note 7), generating $37.7B in annual depreciation by FY30.
- Core Operating Assumptions & Dated WACC Calibration (As of Sept 23, 2026): Base revenue growth 13.00%/yr; gross margin 68.50%; cash OpEx 22.5% tapering to 21.0% of GP; effective tax rate 18.0%; annual cash CapEx flat at $65,000M; terminal growth 3.00% (nominal U.S. GDP anchor). WACC 9.50% derived via CAPM: Rf 4.25% (FRED DGS10 10-Yr Treasury, 2026-09-23) + 1.05 beta (5-Yr monthly OLS vs. S&P 500, 2026-09-23) x 5.00% ERP (Damodaran implied ERP, Sept 2026) = 9.50% Ke (98.8% equity weight, AAA credit).
- Peer Multiples Sourcing (As of Sept 23, 2026): GOOGL 41.09x ($330.39 on 2026-09-23 / $8.04 FY24 10-K Note 11 EPS), ORCL 35.24x ($152.94 / $4.34 FY25 10-K Note 13 EPS), AMZN 39.91x ($186.40 / $4.67 FY24 10-K Note 10 EPS); median 39.91x ($544.48/sh).
- One-at-a-Time Causal Ranking: Organic Revenue Growth (10% to 16%) dominates Gross Margin (66.5% to 70.5%) by 4.68x on valuation span ($110.15/sh vs. $23.53/sh) because growth compounds over 5 years against 68.5% margin and pulls in unearned cash float.
- Why Methods Disagree (Never Average!): P/E Comps ($544.48) value accounting net income and ignore CapEx. DCF ($317.10) deducts all cash CapEx for GPU clusters (3 to 5 year life). Reverse DCF proves market price ($500.59) demands 21.58% compound organic growth through 2030 (+8.58 percentage points above base), an expectation unsupported by management guidance.

================================================================================
4. PRINCIPAL RISKS, STRESS TESTS, AND FAILURE CONDITIONS
================================================================================

- AI Infrastructure Return Dilution Risk: Hyperscale GPU spending ($65B+/yr) risks creating persistent depreciation drag if enterprise Copilot adoption ($30/user/mo) slows.
- Downside Distress Stress Test (Recession Shock): Testing -5% revenue growth in FY26, 60% gross margin, and $85B CapEx cuts FCFE by >60%, draws $4.5B on revolver, and lowers value to $142.10/sh; articulation checks confirm the model balances with zero gap.

================================================================================
5. EXPLICIT REVERSAL TRIGGERS AND ACTION CONDITIONS
================================================================================

Action Trigger: Price Retracement
- Quantitative Threshold: Market price falls below $310.00
- Required Evidence Source: NASDAQ market tape
- Committee Action: INITIATE BUY (provides 20%+ margin of safety to peer comps and aligns with intrinsic DCF base).

Action Trigger: Margin Proof
- Quantitative Threshold: Cloud gross margin expands above 72.0% while CapEx growth moderates below 15%
- Required Evidence Source: Subsequent Form 10-Q Item 1 & MD&A
- Committee Action: INITIATE BUY (proves AI software adoption outruns infrastructure costs).

Action Trigger: Thesis Breach
- Quantitative Threshold: Annual CapEx exceeds $75B while Azure growth slips below 15% and margins fall below 67%
- Required Evidence Source: Subsequent Form 10-Q / 10-K
- Committee Action: REJECT / REMOVE (confirms structural return destruction on GPU assets).

Monitoring Cadence & Review Point: Next formal review scheduled for October 2026 upon filing of Microsoft's Q1 FY2027 Form 10-Q. Full audit details and AI disposition records are cataloged in Validation-and-AI-Use.pdf.
