"""asof.py — Lab 15: Point-in-Time Information Filter & Signal Generation

Standard Library Only.
Demonstrates the difference between the month an index measures (reference period)
and the date it was published (knowledge date).
"""

from datetime import datetime

# ==============================================================================
# EDITABLE INPUTS
# ==============================================================================
# Decision date: a row is knowable only if published on or before this date.
DECISION_DATE = "2026-03-31"

# Training table: fictional card-spend index, three retailers
# You can edit this table directly for new series (e.g. Thursday checkout).
RAW_DATA = [
    {"row": 1,  "ticker": "AAA", "month_measured": "2026-01", "published_on": "2026-02-10", "index": 101.0},
    {"row": 2,  "ticker": "AAA", "month_measured": "2026-02", "published_on": "2026-03-10", "index": 104.0},
    {"row": 3,  "ticker": "AAA", "month_measured": "2026-03", "published_on": "2026-04-10", "index": 109.0},
    {"row": 4,  "ticker": "AAA", "month_measured": "2026-02", "published_on": "2026-03-25", "index": 103.0},
    {"row": 5,  "ticker": "BBB", "month_measured": "2026-01", "published_on": "2026-02-10", "index": 98.0},
    {"row": 6,  "ticker": "BBB", "month_measured": "2026-02", "published_on": "2026-03-10", "index": 97.0},
    {"row": 7,  "ticker": "BBB", "month_measured": "2026-02", "published_on": "2026-03-10", "index": 97.0},
    {"row": 8,  "ticker": "BBB", "month_measured": "2026-03", "published_on": "2026-04-10", "index": 92.0},
    {"row": 9,  "ticker": "CCC", "month_measured": "2026-01", "published_on": "2026-02-10", "index": 110.0},
    {"row": 10, "ticker": "CCC", "month_measured": "2026-02", "published_on": "2026-04-05", "index": 112.0},
    {"row": 11, "ticker": "",    "month_measured": "2026-02", "published_on": "2026-03-10", "index": 99.0},
    {"row": 12, "ticker": "CCC", "month_measured": "2026-02", "published_on": "2026-03-10", "index": 111.0},
]


# ==============================================================================
# PIPELINE / FILTER IMPLEMENTATION
# ==============================================================================

def run_as_of_pipeline(raw_data, decision_date):
    """
    Applies the four rules in strict order:
      Rule 1: Quarantine a row with no ticker
      Rule 2: Remove an exact duplicate
      Rule 3: Remove a row published after the decision date
      Rule 4: Where one ticker and month has two publications, keep the latest
              one published by the decision date (a revision)
    """
    # -------------------------------------------------------------------------
    # RULE 1: Quarantine a row with no ticker
    # -------------------------------------------------------------------------
    rule1_removed = []
    after_rule1 = []
    for r in raw_data:
        ticker = str(r.get("ticker", "")).strip()
        if not ticker:
            rule1_removed.append(r["row"])
        else:
            after_rule1.append(r)

    # -------------------------------------------------------------------------
    # RULE 2: Remove an exact duplicate
    # -------------------------------------------------------------------------
    rule2_removed = []
    after_rule2 = []
    seen_exact_records = set()
    for r in after_rule1:
        # Exact duplicate matches ticker, month measured, published on, and index
        record_key = (r["ticker"], r["month_measured"], r["published_on"], float(r["index"]))
        if record_key in seen_exact_records:
            rule2_removed.append(r["row"])
        else:
            seen_exact_records.add(record_key)
            after_rule2.append(r)

    # -------------------------------------------------------------------------
    # RULE 3: Remove a row published after the decision date
    # -------------------------------------------------------------------------
    rule3_removed = []
    after_rule3 = []
    for r in after_rule2:
        if r["published_on"] > decision_date:
            rule3_removed.append(r["row"])
        else:
            after_rule3.append(r)

    # -------------------------------------------------------------------------
    # RULE 4: Where one ticker and month has two publications,
    #         keep the latest one published by the decision date (a revision).
    # -------------------------------------------------------------------------
    groups = {}
    for r in after_rule3:
        key = (r["ticker"], r["month_measured"])
        groups.setdefault(key, []).append(r)

    as_of_panel = []
    rule4_removed = []

    for key, rows_for_month in groups.items():
        if len(rows_for_month) == 1:
            as_of_panel.append(rows_for_month[0])
        else:
            # Sort by publication date ascending; the latest publication date is the revision
            sorted_vintages = sorted(rows_for_month, key=lambda r: (r["published_on"], r["row"]))
            latest_vintage = sorted_vintages[-1]
            older_vintages = sorted_vintages[:-1]

            as_of_panel.append(latest_vintage)
            for r in older_vintages:
                rule4_removed.append(r["row"])

    # Sort remaining as-of panel rows by original row number
    as_of_panel.sort(key=lambda r: r["row"])

    funnel = {
        "rule1": rule1_removed,
        "rule2": rule2_removed,
        "rule3": rule3_removed,
        "rule4": rule4_removed,
        "panel": [r["row"] for r in as_of_panel],
    }

    return as_of_panel, funnel, after_rule2


def build_naive_panel(after_rule2):
    """
    Computes the naive panel: uses every row's latest publication,
    completely ignoring the publication date cutoff (Rule 3 skipped).
    """
    groups = {}
    for r in after_rule2:
        key = (r["ticker"], r["month_measured"])
        groups.setdefault(key, []).append(r)

    naive_panel = []
    for key, rows_for_month in groups.items():
        # Latest publication for that ticker and month
        sorted_vintages = sorted(rows_for_month, key=lambda r: (r["published_on"], r["row"]))
        naive_panel.append(sorted_vintages[-1])

    naive_panel.sort(key=lambda r: r["row"])
    return naive_panel


def compute_ticker_signals(panel, is_naive=False, as_of_panel=None, decision_date=DECISION_DATE):
    """
    Computes the signal for each ticker:
      Percent change from the previous month to the latest month in the panel.
      Format: +X.XX% (MonthName)
    For naive signals, if the latest month matches the as-of month but reflects
    a revision published after the decision date, annotate with '(MonthName, revised)'.
    """
    # Group panel rows by ticker
    by_ticker = {}
    for r in panel:
        by_ticker.setdefault(r["ticker"], []).append(r)

    # If naive, find the as-of latest observation per ticker to detect revisions
    as_of_latest_by_ticker = {}
    if as_of_panel is not None:
        for r in as_of_panel:
            as_of_latest_by_ticker.setdefault(r["ticker"], []).append(r)
        for t, rows in as_of_latest_by_ticker.items():
            sorted_t = sorted(rows, key=lambda r: r["month_measured"])
            as_of_latest_by_ticker[t] = sorted_t[-1]

    signals = {}
    for ticker in sorted(by_ticker.keys()):
        obs = sorted(by_ticker[ticker], key=lambda r: r["month_measured"])
        if len(obs) < 2:
            signals[ticker] = ("N/A (need >= 2 months)", "")
            continue

        prev_obs = obs[-2]
        latest_obs = obs[-1]

        pct_change = ((latest_obs["index"] - prev_obs["index"]) / prev_obs["index"]) * 100.0

        month_dt = datetime.strptime(latest_obs["month_measured"], "%Y-%m")
        month_name = month_dt.strftime("%B")

        # Check if this naive observation is a post-decision revision of the as-of month
        if is_naive and ticker in as_of_latest_by_ticker:
            asof_lat = as_of_latest_by_ticker[ticker]
            if latest_obs["month_measured"] == asof_lat["month_measured"] and latest_obs["row"] != asof_lat["row"]:
                month_name = f"{month_name}, revised"

        # Format: +1.98%, -1.02%
        signal_str = f"{pct_change:+.2f}% ({month_name})"
        signals[ticker] = signal_str

    return signals


# ==============================================================================
# MAIN DISPLAY & RUNNER
# ==============================================================================

def main():
    as_of_panel, funnel, after_rule2 = run_as_of_pipeline(RAW_DATA, DECISION_DATE)
    naive_panel = build_naive_panel(after_rule2)

    as_of_signals = compute_ticker_signals(as_of_panel, is_naive=False)
    naive_signals = compute_ticker_signals(naive_panel, is_naive=True, as_of_panel=as_of_panel, decision_date=DECISION_DATE)

    # Format date string for funnel header (e.g. 2026-03-31 -> 31 March)
    dt_dec = datetime.strptime(DECISION_DATE, "%Y-%m-%d")
    dec_day_month = f"{dt_dec.day} {dt_dec.strftime('%B')}"

    # 1. Row Funnel
    print("=" * 68)
    print("THE ROW FUNNEL")
    print("=" * 68)
    print(f"{'Funnel step':<38} {'Rows removed':<30}")
    print("-" * 68)

    r1_str = ", ".join(str(x) for x in funnel["rule1"]) if funnel["rule1"] else "None"
    r2_str = ", ".join(str(x) for x in funnel["rule2"]) if funnel["rule2"] else "None"
    r3_str = ", ".join(str(x) for x in funnel["rule3"]) if funnel["rule3"] else "None"
    r4_str = ", ".join(str(x) for x in funnel["rule4"]) if funnel["rule4"] else "None"
    panel_str = ", ".join(str(x) for x in funnel["panel"])

    print(f"{'Quarantined: no ticker':<38} {r1_str:<30}")
    print(f"{'Exact duplicate':<38} {r2_str:<30}")
    print(f"{f'Published after {dec_day_month}':<38} {r3_str:<30}")
    print(f"{'Older vintage replaced by a revision':<38} {r4_str:<30}")
    print(f"{'As-of panel':<38} {panel_str:<30}")
    print()

    # 2. As-of Panel Table
    print("=" * 68)
    print(f"AS-OF PANEL (Knowable on or before {DECISION_DATE})")
    print("=" * 68)
    print(f"{'Row':<6} {'Ticker':<8} {'Month measured':<16} {'Published on':<16} {'Index':<8}")
    print("-" * 68)
    for r in as_of_panel:
        print(f"{r['row']:<6} {r['ticker']:<8} {r['month_measured']:<16} {r['published_on']:<16} {r['index']:<8.1f}")
    print()

    # 3. Signals Table
    print("=" * 68)
    print("THE SIGNALS")
    print("=" * 68)
    print(f"{'Ticker':<10} {'As-of signal':<26} {'Naive signal':<26}")
    print("-" * 68)
    for ticker in sorted(as_of_signals.keys()):
        print(f"{ticker:<10} {as_of_signals[ticker]:<26} {naive_signals.get(ticker, ''):<26}")
    print("=" * 68)


if __name__ == "__main__":
    main()

