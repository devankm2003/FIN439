# Lab 15 — Thursday Merit Checkout: Portfolio Optimization & Estimation Risk Workbench
**Course:** FIN439 — Corporate Valuation & Investment Policy Analysis  
**Category:** Thursday Merit Checkout  
**Primary Engine:** [`portfolio.py`](file:///Users/devankmahajan/.gemini/antigravity/scratch/FIN439/portfolio.py)  
**Streamlit App:** [`app.py`](file:///Users/devankmahajan/.gemini/antigravity/scratch/FIN439/app.py)  
**Historical Price Dataset:** [`prices.csv`](file:///Users/devankmahajan/.gemini/antigravity/scratch/FIN439/prices.csv)  

---

## Executive Summary & Command to Run

### Command to Run the Streamlit Application
```bash
streamlit run app.py
```
*(If running for the first time in an environment without Streamlit installed, run `pip install streamlit` first).*

### Command to Verify the Baseline Risk Engine
```bash
python portfolio.py
```
*Expectation:* Outputs Tuesday's Lab 14 values completely unchanged.

---

## I — Engine Architecture & Mermaid Flowchart

Below is the complete architectural flowchart representing [`portfolio.py`](file:///Users/devankmahajan/.gemini/antigravity/scratch/FIN439/portfolio.py) and [`app.py`](file:///Users/devankmahajan/.gemini/antigravity/scratch/FIN439/app.py), tracing each step from input data (`prices.csv` or Meridian training baselines) to the lowest-risk optimal mix.

```mermaid
flowchart TD
    subgraph DataInput ["1. Data Input Stage"]
        A1["Raw Historical Monthly Prices (prices.csv)<br>• Date first, oldest first<br>• Columns: BIL, IEF, BND, SPY, VEA"] --> B1["estimate_from_prices_csv()<br>• Window slice: All months or Last 36"]
        A2["Meridian Baseline Inputs<br>• SLEEVES, EXPECTED_RETURNS<br>• VOLATILITIES, CORRELATIONS"] --> B2["Editable UI Overrides (app.py)<br>• Expected return boxes<br>• Reserve-eligible checkboxes"]
    end

    subgraph StatEngine ["2. Statistics & Risk Estimation Engine"]
        B1 --> C1["Monthly Returns Calculation<br>R_t = (P_t / P_t-1) - 1"]
        C1 --> C2["Annualized Parameters<br>• Mean Return: E[R] = mean(R) * 12<br>• Volatility: σ = std(R) * √12<br>• Pearson Correlations: ρ_ij"]
        C2 --> D["build_covariance_matrix()<br>Cov(i, j) = ρ_ij * σ_i * σ_j"]
        B2 --> D
    end

    subgraph Optimization ["3. Grid-Search Optimization Engine"]
        D --> E["generate_weight_mixes()<br>• Long-only (w_i ≥ 0)<br>• Step size: 5 points (0%, 5%, ..., 100%)<br>• Sum = 100% (1,771 candidate mixes for N=4)"]
        E --> F{"Constraint Check per Mix"}
        F -- "Expected Return ≥ Objective<br>(e.g. ≥ 6.5%)" --> G{"Reserve Check"}
        F -- "Expected Return < Objective" --> H["Reject Candidate Mix"]
        G -- "Reserve Weight ≥ Minimum<br>(e.g. ≥ 3.0%)" --> I["Compute Portfolio Volatility<br>σ_p = √( Σ Σ w_i * w_j * Cov(i, j) )"]
        G -- "Reserve Weight < Minimum" --> H
        I --> J["Argmin Volatility Selection<br>Keep mix with lowest σ_p"]
    end

    subgraph Output ["4. Output & Presentation Stage"]
        J --> K["Optimal Lowest-Risk Allocation<br>• Weights, Return, Volatility, Reserve %"]
        H --> L{"Were Any Mixes Permissible?"}
        L -- "No" --> M["'No mix meets the objective'"]
        L -- "Yes" --> K
        K --> N["UI Side-by-Side Presentation<br>• Baseline Loaded Mix vs. Current Mix<br>• Largest Weight Change in Points"]
        M --> N
    end
```

---

## V — Verification on Known Answers (Rubric Proof)

The engine was rigorously benchmarked against the three required Section V test scenarios:

| Run Scenario | Weights: Bills / 10-year / IG / Equity | Expected Return | Volatility | Reserve Weight | Largest Weight Change | Verification Result |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **As loaded (Meridian baseline)** | `0.0 / 20.0 / 25.0 / 55.0` | **6.51%** | **9.44%** | **20.0%** | Baseline (0 pts) | **EXACT MATCH** |
| **Equity return box: 8.0% → 7.0%** | `0.0 / 10.0 / 10.0 / 80.0` | **6.53%** | **12.94%** | **10.0%** | **25.0 points** in Equity | **EXACT MATCH** |
| **IG–equity correlation: 0.50 in `portfolio.py`** | `0.0 / 40.0 / 0.0 / 60.0` | **6.52%** | **9.73%** | **40.0%** | 25.0 points in IG | **EXACT MATCH** |

### Mathematical Hand-Proof of the Baseline Mix (`0 / 20 / 25 / 55`)
1. **Expected Return:**
   $$\mathbb{E}[R_p] = (0.00 \times 3.5\%) + (0.20 \times 4.3\%) + (0.25 \times 5.0\%) + (0.55 \times 8.0\%) = 0.000 + 0.860 + 1.250 + 4.400 = \mathbf{6.51\%} \ge 6.50\%$$
2. **Reserve-Eligible Weight:**
   $$w_{\text{reserve}} = w_{\text{Bills}} + w_{\text{10-yr}} = 0.0\% + 20.0\% = \mathbf{20.0\%} \ge 3.0\%$$
3. **Volatility:**
   With $\operatorname{Cov}(i, j) = \rho_{ij} \sigma_i \sigma_j$:
   $$\sigma_p^2 = \sum_{i} \sum_{j} w_i w_j \operatorname{Cov}(i, j) = 89.176 \implies \sigma_p = \sqrt{89.176} = \mathbf{9.44\%}$$

---

## Your Universe: Horizon Endowment Mandate

### Fund Sleeves & Data Source
- **Mandate Entity:** Horizon University Endowment Fund ($250M AUM)
- **Objective:** $\text{Target Return} = \text{HEPI (2.5%)} + 5.0\% = \mathbf{7.5\%}$ (or conservative operating threshold $\mathbf{7.0\%}$)
- **Reserve Rule:** Hold $\ge 18$ months of operating distributions ($4.5\% \times 1.5 = \mathbf{6.8\%}$) in reserve-eligible sovereign assets (`BIL`, `IEF`).
- **File:** [`prices.csv`](file:///Users/devankmahajan/.gemini/antigravity/scratch/FIN439/prices.csv) (61 monthly Adjusted Close observations, October 2019 – October 2024; download source: Yahoo Finance historical archives).

### Asset Universe Historical Estimates
| Ticker | Asset Sleeve Description | Reserve-Eligible? | 5-Year Return (All 60 Mos) | 5-Year Vol (All 60 Mos) | 3-Year Return (Last 36 Mos) | 3-Year Vol (Last 36 Mos) |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: |
| **`BIL`** | SPDR 1-3 Month T-Bill ETF | **Yes** | **2.40%** | **0.66%** | **3.75%** | **0.57%** |
| **`IEF`** | iShares 7-10 Year Treasury Bond ETF | **Yes** | **-1.23%** | **7.21%** | **-3.60%** | **8.46%** |
| **`BND`** | Vanguard Total Bond Market ETF | No | **-0.52%** | **6.53%** | **-2.14%** | **7.94%** |
| **`SPY`** | SPDR S&P 500 ETF Trust | No | **15.49%** | **18.13%** | **9.04%** | **17.11%** |
| **`VEA`** | Vanguard FTSE Developed Markets ETF | No | **7.18%** | **18.63%** | **3.25%** | **18.05%** |

### Optimizer Results on Universe (Objective = 7.0%, Reserve Minimum = 6.8%)
| Slicing Regime | Optimal Allocation: `BIL / IEF / BND / SPY / VEA` | Expected Return | Volatility | Reserve Weight | Largest Weight Change |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **All Months (5-Year Full History)** | `60.0% / 0.0% / 0.0% / 35.0% / 5.0%` | **7.22%** | **7.21%** | **60.0%** | Baseline |
| **Last 36 Months (Rate Hikes Regime)** | `35.0% / 0.0% / 0.0% / 65.0% / 0.0%` | **7.19%** | **11.18%** | **35.0%** | **30.0 points** in `SPY` (35% → 65%) |

> **Key Finding:** Slicing to the trailing 36 months triggers a **30-point reallocation directly into equities (`SPY`)** and elevates portfolio volatility by **3.97 percentage points** (from 7.21% to 11.18%). Because fixed-income returns were negative during the 2022–2023 Fed hiking cycle, the optimizer was forced to abandon bonds and heavily concentrate in equities to reach the 7.0% return target.

---

## Explain the Code: Line-by-Line Breakdown of `search_lowest_risk_mix`

```python
def search_lowest_risk_mix(
    sleeves, expected_returns, cov_matrix, reserve_sleeves, objective, min_reserve_weight=3.0, step=5
):
    best_candidate = None
    min_volatility = float("inf")
    tol = 1e-9

    for mix in generate_weight_mixes(len(sleeves), step=step):
        weights = {s: float(w) for s, w in zip(sleeves, mix)}
        exp_ret = compute_portfolio_return(weights, expected_returns)

        if exp_ret < objective - tol:
            continue

        reserve_w = compute_reserve_eligible_weight(weights, reserve_sleeves)
        if reserve_w < min_reserve_weight - tol:
            continue

        vol = compute_portfolio_volatility(weights, cov_matrix, sleeves)
        if vol < min_volatility:
            min_volatility = vol
            best_candidate = {
                "weights": weights,
                "expected_return": exp_ret,
                "volatility": vol,
                "reserve_weight": reserve_w,
            }

    return best_candidate
```

### Verbal Line-by-Line Explanation for Partner
1. **Lines 4–6 (`best_candidate`, `min_volatility`, `tol`):** Initializes the tracking variable to `None` (so if no mix satisfies the constraints, the function explicitly returns `None`), sets the initial lowest volatility to infinity, and establishes a tiny numerical tolerance (`1e-9`) to avoid rejecting mixes due to floating-point rounding.
2. **Line 8 (`for mix in generate_weight_mixes(...)`):** Loops over every long-only portfolio whose asset weights sum to 100% in 5-point steps (for 4 assets, exactly 1,771 candidate mixes).
3. **Line 9 (`weights = {s: float(w) ...}`):** Packages the integer grid weights into a dictionary keyed by sleeve name.
4. **Lines 10–13 (`compute_portfolio_return` & hurdle check):** Computes the expected portfolio return ($\sum w_i \mu_i$) and immediately skips any portfolio earning less than the required objective ($6.5\%$).
5. **Lines 15–18 (`compute_reserve_eligible_weight` & reserve check):** Sums the weights of reserve-eligible assets (Bills + 10-year note) and immediately skips any portfolio holding less than the mandated reserve floor ($3.0\%$).
6. **Lines 20–28 (`compute_portfolio_volatility` & argmin update):** For candidate portfolios passing both hurdle constraints, evaluates full portfolio volatility $\sqrt{w^T \Sigma w}$. If this portfolio's volatility is lower than the best seen so far, it saves this mix as the new champion.
7. **Line 30 (`return best_candidate`):** Returns the lowest-risk portfolio dictionary, or `None` if zero candidate mixes met the objective.

---

## Partner Attack

### Question & Two-Sentence Response
**Partner Action:** Partner opens the app, moves the Global Equity expected return estimate from **8.0% to 7.0%**, and reads the resulting allocation aloud: `0 / 10 / 10 / 80` at 12.94% volatility.

**Two-Sentence Response:**  
> *"Lowering the equity expected return estimate by just 1.0 percentage point causes the optimizer to aggressively expand equity weighting from 55% to 80% (+25 points) while slashing bonds, because equity remains the only asset capable of bridging the required 6.5% return hurdle. This demonstrates that mean-variance optimizers act as 'error maximizers'—they disproportionately overweight assets whose return estimates are stretched relative to their risk, converting subtle estimation uncertainty into extreme allocation bets."*

---

## Your Call · Estimation Risk — Learn on Your Own

### Decision Recommendation
**"Pilot, not adopt: A one-point lower equity return estimate moves 25 points into equities, and shifting from 5-year to 3-year history shifts 30 points into SPY. We should pilot this allocation under strict ±10% policy bands and adopt only once the Investment Committee formalizes forward-looking Black-Litterman return priors and clarifies drawdown tolerance under Statement S9."**

### Michaud's Error Maximization: Why Do Optimizers Amplify Small Errors?
1. **Mathematical Asymmetry:** In quadratic portfolio optimization, expected return appears **linearly** in the constraint ($\sum w_i \mu_i \ge R_{\text{obj}}$), while risk appears **quadratically** in the objective ($w^T \Sigma w$). When the return hurdle is binding, a minuscule change in $\mu_i$ forces a massive reallocation along the efficient frontier.
2. **Noise Treated as Truth:** Historical sample averages carry standard errors:
   $$\operatorname{SE}(\bar{R}) = \frac{\sigma}{\sqrt{T}} \approx \frac{16\%}{\sqrt{5}} \approx 7.15\%$$
   The optimizer treats a point estimate of $8.0\%$ as mathematical certainty, completely blind to the fact that the true parameter could easily be $6.0\%$ or $10.0\%$.
3. **Systematic Over-Allocation to Outliers:** The algorithm systematically seeks out assets that appear to offer high return per unit of variance. Assets whose historical sample means happen to be noisy upward fluctuations are given the largest weights, while assets whose means were depressed by temporary headwinds are penalized. The optimizer literally maximizes estimation error.

