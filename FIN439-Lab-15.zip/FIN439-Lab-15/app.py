"""
app.py - Portfolio Risk & Allocation Streamlit Workbench
FIN439: Corporate Valuation and Investment Policy Analysis (Lab 15)

Imports core math and baseline data directly from portfolio.py.
Never duplicates the optimization or covariance math.
"""

from pathlib import Path
import sys

# Ensure current and parent directory is on sys.path for robust imports
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

try:
    import streamlit as st
except ImportError:
    print("\n" + "=" * 70)
    print("FIN439 LAB 15 — STREAMLIT APPLICATION")
    print("=" * 70)
    print("Streamlit is required to launch the interactive UI.")
    print("Install it with:")
    print("    pip install streamlit")
    print("\nThen run:")
    print("    streamlit run app.py")
    print("=" * 70 + "\n")
    sys.exit(0)

# Import engine functions and Meridian training inputs from portfolio.py
from portfolio import (
    SLEEVES,
    EXPECTED_RETURNS,
    VOLATILITIES,
    CORRELATIONS,
    OBJECTIVE_RETURN,
    RESERVE_ELIGIBLE_SLEEVES,
    build_covariance_matrix,
    search_lowest_risk_mix,
    estimate_from_prices_csv,
)

# ------------------------------------------------------------------------------
# PAGE CONFIGURATION & HEADER
# ------------------------------------------------------------------------------

st.set_page_config(
    page_title="Portfolio Optimization Workbench | FIN439",
    page_icon="📈",
    layout="wide",
)

st.title("Portfolio Optimization Workbench")
st.markdown("*built with AI help, a learning demonstration, not investment advice.*")

# ------------------------------------------------------------------------------
# SIDEBAR CONTROLS
# ------------------------------------------------------------------------------

st.sidebar.header("Mandate & Optimization Settings")

sidebar_objective = st.sidebar.number_input(
    "Objective Expected Return (% p.a.)",
    min_value=0.0,
    max_value=30.0,
    value=float(OBJECTIVE_RETURN),
    step=0.1,
    format="%.2f",
    help="Minimum required annualized portfolio return.",
)

sidebar_reserve_min = st.sidebar.number_input(
    "Reserve Minimum Weight (%)",
    min_value=0.0,
    max_value=100.0,
    value=3.0,
    step=0.5,
    format="%.2f",
    help="Minimum allocation required in reserve-eligible assets.",
)

uploaded_file = st.sidebar.file_uploader(
    "Upload prices.csv",
    type=["csv"],
    help="Five years of monthly Adj Close, date first, oldest first, one column per ticker.",
)

last_36_switch = st.sidebar.toggle(
    "Use Last 36 Months Only",
    value=False,
    help="Slice price history to evaluate only the trailing 36 monthly returns.",
)

# ------------------------------------------------------------------------------
# DATA RESOLUTION: MERIDIAN BASELINE VS. UPLOADED CSV
# ------------------------------------------------------------------------------

if uploaded_file is not None:
    try:
        # 1. Base estimates on ALL months (for "inputs as loaded")
        uploaded_file.seek(0)
        base_csv_estimates = estimate_from_prices_csv(uploaded_file, last_36=False)

        # 2. Current active estimates (subject to last_36 switch)
        uploaded_file.seek(0)
        active_estimates = estimate_from_prices_csv(uploaded_file, last_36=last_36_switch)

        active_sleeves = active_estimates["tickers"]
        loaded_returns = dict(active_estimates["expected_returns"])
        active_vols = dict(active_estimates["volatilities"])
        active_cov = active_estimates["cov_matrix"]

        # Default reserve-eligible rule for uploaded funds:
        # BIL, IEF, cash, or treasury equivalents default to ticked
        def is_default_reserve(ticker: str) -> bool:
            t = ticker.upper()
            return t in {"BIL", "IEF", "SHV", "GOVT", "VGSH"} or "TREASURY" in t or "BILL" in t

        default_reserve_set = {t for t in active_sleeves if is_default_reserve(t)}
        mode_label = f"Uploaded CSV ({active_estimates['used_months']} months used)"

        # Loaded baseline mix: CSV on all months, initial objective & reserve floor
        loaded_baseline_mix = search_lowest_risk_mix(
            sleeves=base_csv_estimates["tickers"],
            expected_returns=base_csv_estimates["expected_returns"],
            cov_matrix=base_csv_estimates["cov_matrix"],
            reserve_sleeves=default_reserve_set,
            objective=sidebar_objective,
            min_reserve_weight=sidebar_reserve_min,
            step=5,
        )

    except Exception as exc:
        st.error(f"Error parsing uploaded CSV: {exc}")
        st.stop()

else:
    # Meridian Training Defaults from portfolio.py
    active_sleeves = list(SLEEVES)
    loaded_returns = dict(EXPECTED_RETURNS)
    active_vols = dict(VOLATILITIES)
    active_cov = build_covariance_matrix(SLEEVES, VOLATILITIES, CORRELATIONS)
    default_reserve_set = set(RESERVE_ELIGIBLE_SLEEVES)
    mode_label = "Meridian Mandate (Lab 14 Training Inputs)"

    # Loaded baseline mix: Meridian training defaults
    loaded_baseline_mix = search_lowest_risk_mix(
        sleeves=SLEEVES,
        expected_returns=EXPECTED_RETURNS,
        cov_matrix=active_cov,
        reserve_sleeves=RESERVE_ELIGIBLE_SLEEVES,
        objective=float(OBJECTIVE_RETURN),
        min_reserve_weight=3.0,
        step=5,
    )

st.caption(f"**Active Mode:** {mode_label}")

# ------------------------------------------------------------------------------
# PAGE INPUTS: EDITABLE EXPECTED RETURNS & RESERVE-ELIGIBLE CHECKBOXES
# ------------------------------------------------------------------------------

st.subheader("Asset Universe & Return Assumptions")
st.write(
    "Edit expected returns directly in the boxes below. "
    "Tick the boxes to designate assets as reserve-eligible."
)

col_count = len(active_sleeves)
cols = st.columns(col_count)

edited_returns = {}
selected_reserve_sleeves = set()

for idx, sleeve in enumerate(active_sleeves):
    with cols[idx]:
        st.markdown(f"**{sleeve}**")
        st.caption(f"Vol: {active_vols.get(sleeve, 0.0):.2f}% p.a.")

        init_ret = float(loaded_returns[sleeve])
        ret_val = st.number_input(
            "Expected Return (%)",
            value=init_ret,
            step=0.1,
            format="%.2f",
            key=f"ret_box_{sleeve}",
        )
        edited_returns[sleeve] = ret_val

        default_checked = sleeve in default_reserve_set
        is_reserve = st.checkbox(
            "Reserve-eligible",
            value=default_checked,
            key=f"res_check_{sleeve}",
        )
        if is_reserve:
            selected_reserve_sleeves.add(sleeve)

st.divider()

# ------------------------------------------------------------------------------
# ENGINE RUN: COMPUTE CURRENT LOWEST-RISK MIX
# ------------------------------------------------------------------------------

current_optimal_mix = search_lowest_risk_mix(
    sleeves=active_sleeves,
    expected_returns=edited_returns,
    cov_matrix=active_cov,
    reserve_sleeves=selected_reserve_sleeves,
    objective=sidebar_objective,
    min_reserve_weight=sidebar_reserve_min,
    step=5,
)

# ------------------------------------------------------------------------------
# SIDE-BY-SIDE PRESENTATION
# ------------------------------------------------------------------------------

st.subheader("Optimization Results: Lowest-Risk Allocation")

col_loaded, col_current = st.columns(2)

# Helper function to render a portfolio summary table/card
def render_portfolio_panel(panel_col, title, mix, sleeves_list, badge_text=""):
    with panel_col:
        st.markdown(f"### {title} {badge_text}")
        if mix is None:
            st.error("⚠️ **no mix meets the objective**")
            st.write(
                "No long-only combination of the active assets satisfies both the "
                "expected return threshold and the reserve-eligible floor."
            )
            return

        w = mix["weights"]
        summary_rows = [
            {"Asset": s, "Allocation (%)": f"{w[s]:.2f}%"} for s in sleeves_list
        ]
        st.table(summary_rows)

        m1, m2, m3 = st.columns(3)
        m1.metric("Expected Return", f"{mix['expected_return']:.2f}%")
        m2.metric("Portfolio Volatility", f"{mix['volatility']:.2f}%")
        m3.metric("Reserve-Eligible Weight", f"{mix['reserve_weight']:.2f}%")


# 1. Left Panel: Inputs as Loaded (Baseline)
render_portfolio_panel(
    panel_col=col_loaded,
    title="Inputs as Loaded",
    mix=loaded_baseline_mix,
    sleeves_list=active_sleeves,
    badge_text="(Baseline)",
)

# 2. Right Panel: Current Lowest-Risk Mix (Optimized)
render_portfolio_panel(
    panel_col=col_current,
    title="Current Mix",
    mix=current_optimal_mix,
    sleeves_list=active_sleeves,
    badge_text="(Optimized)",
)

# ------------------------------------------------------------------------------
# LARGEST WEIGHT CHANGE COMPARISON
# ------------------------------------------------------------------------------

st.divider()

if loaded_baseline_mix is not None and current_optimal_mix is not None:
    shifts = {}
    for s in active_sleeves:
        w_loaded = loaded_baseline_mix["weights"].get(s, 0.0)
        w_current = current_optimal_mix["weights"].get(s, 0.0)
        shifts[s] = abs(w_current - w_loaded)

    max_shift_asset = max(shifts, key=shifts.get)
    max_shift_points = shifts[max_shift_asset]

    st.subheader("Estimation Sensitivity & Allocation Shift")
    metric_col, desc_col = st.columns([1, 2])

    with metric_col:
        st.metric(
            label="Largest Weight Change",
            value=f"{max_shift_points:.1f} points",
            delta=f"{current_optimal_mix['weights'][max_shift_asset] - loaded_baseline_mix['weights'][max_shift_asset]:+.1f} pts in {max_shift_asset}",
        )

    with desc_col:
        st.markdown(
            f"**Asset:** `{max_shift_asset}`  \n"
            f"- **Loaded Baseline Weight:** `{loaded_baseline_mix['weights'][max_shift_asset]:.1f}%`  \n"
            f"- **Current Optimized Weight:** `{current_optimal_mix['weights'][max_shift_asset]:.1f}%`  \n"
            f"- **Absolute Reallocation:** **{max_shift_points:.1f} percentage points**"
        )
        if max_shift_points > 0:
            st.info(
                f"**Sensitivity takeaway:** A change in return expectations or constraints moved "
                f"**{max_shift_points:.0f} points** of the total portfolio into or out of `{max_shift_asset}`."
            )
        else:
            st.success("Current parameters yield the exact same allocation as loaded.")

elif current_optimal_mix is None:
    st.warning("Cannot compute weight change because no mix meets the current objective.")

# ------------------------------------------------------------------------------
# VERIFICATION BENCHMARKS (RUBRIC HELPER)
# ------------------------------------------------------------------------------

with st.expander("Section V Verification Benchmarks (Course Rubric)"):
    st.markdown(
        """
        | Scenario | Bills / 10-year / IG / Equity | Return | Volatility | Notes |
        | :--- | :---: | :---: | :---: | :--- |
        | **As Loaded** | `0 / 20 / 25 / 55` | **6.51%** | **9.44%** | Baseline Meridian mix |
        | **Equity 8.0 → 7.0** | `0 / 10 / 10 / 80` | **6.53%** | **12.94%** | Largest change: 25 points |
        | **IG-Equity Corr 0.50** | `0 / 40 / 0 / 60` | **6.52%** | **9.73%** | Proves engine recalculates live |
        """
    )

